import { lazy, Suspense, useEffect, useState } from "react";
import { Link, NavLink, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { ROLE_LABEL } from "./api";
import { ORG } from "./org";
import { useAuth } from "./auth";
import NoticeCenter from "./components/NoticeCenter";

// 첫 화면에 필요 없는 페이지는 방문할 때 내려받는다 (초기 번들 축소)
const Search = lazy(() => import("./pages/Search"));
const AdminPanel = lazy(() => import("./pages/AdminPanel"));
const SchoolAdmin = lazy(() => import("./pages/SchoolAdmin"));
const TeacherPanel = lazy(() => import("./pages/TeacherPanel"));
const Quiz = lazy(() => import("./pages/Quiz"));
// 일지 작성 기능은 diary.ggm.kr 로 분리했다. 이 경로는 안내 후 넘겨주기만 한다.
const JournalMoved = lazy(() => import("./pages/JournalMoved"));
const JournalShare = lazy(() => import("./pages/JournalShare"));
const Events = lazy(() => import("./pages/Events"));
const Favorites = lazy(() => import("./pages/Favorites"));
const Account = lazy(() => import("./pages/Account"));
const ChangePassword = lazy(() => import("./pages/ChangePassword"));
const ChangePhone = lazy(() => import("./pages/ChangePhone"));
const DeleteAccount = lazy(() => import("./pages/DeleteAccount"));
const GuardianConsent = lazy(() => import("./pages/GuardianConsent"));
const FindAccount = lazy(() => import("./pages/FindAccount"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Terms = lazy(() => import("./pages/Terms"));
const Refund = lazy(() => import("./pages/Refund"));
const Signup = lazy(() => import("./pages/Signup"));

import FloatingButton from "./components/FloatingButton";
import FamilySites from "./components/FamilySites";
import PhoneSetupNotice from "./components/PhoneSetupNotice";
import Login from "./pages/Login";
import SchoolPage from "./pages/SchoolPage";
import Home from "./pages/Home";

function Guard({ role, children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="wrap" style={{ padding: 60 }}><div className="empty"><p>확인 중…</p></div></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  return children;
}

function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const location = useLocation();

  // 페이지가 바뀌면 모바일 메뉴를 닫는다
  useEffect(() => { setOpen(false); }, [location.pathname]);

  const close = () => setOpen(false);

  return (
    <header className="header">
      <div className="wrap header-inner">
        <Link to="/" className="brand" onClick={close}>
          <span className="brand-mark">ㅇㅈ</span>
          우리동네 직업계고
        </Link>

        <div className="header-right">
        <button
          className="nav-toggle"
          aria-label="메뉴 열기"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? "✕" : "☰"}
        </button>

        <nav className={`nav ${open ? "open" : ""}`}>
          <NavLink to="/" end onClick={close}>홈</NavLink>
          <NavLink to="/search" onClick={close}>학교 검색</NavLink>
          <NavLink to="/events" onClick={close}>학교 일정</NavLink>
          <NavLink to="/quiz" onClick={close}>진로 테스트</NavLink>

          {user?.role === "student" && <NavLink to="/favorites" onClick={close}>내 즐겨찾기</NavLink>}
          {user?.role === "school" && <NavLink to="/my-school" onClick={close}>학교 관리</NavLink>}
          {user?.role === "teacher" && <NavLink to="/teacher" onClick={close}>선생님</NavLink>}
          {user?.role === "admin" && <NavLink to="/admin" onClick={close}>관리자</NavLink>}

          {user ? (
            <>
              <NavLink to="/account" className="who" title="마이페이지" onClick={close}>
                {user.name} · {ROLE_LABEL[user.role]}
              </NavLink>
              <button onClick={() => { close(); logout(); navigate("/"); }}>로그아웃</button>
            </>
          ) : (
            <>
              <NavLink to="/login" onClick={close}>로그인</NavLink>
              <NavLink to="/signup" style={{ color: "var(--signal-deep)", fontWeight: 700 }} onClick={close}>회원가입</NavLink>
            </>
          )}
        </nav>
        <NoticeCenter />
        </div>
      </div>
      {open && <div className="nav-backdrop" onClick={close} />}
    </header>
  );
}

export default function App() {
  return (
    <div className="shell">
      <Header />

      <PhoneSetupNotice />

      <main id="main">
      <Suspense fallback={<div className="wrap" style={{ padding: "60px 0" }}>
        <div className="empty"><p>불러오는 중…</p></div>
      </div>}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/search" element={<Search />} />
        <Route path="/quiz" element={<Quiz />} />
        <Route path="/events" element={<Events />} />
        <Route path="/journal" element={<JournalMoved />} />
        <Route path="/teacher" element={<Guard role="teacher"><TeacherPanel /></Guard>} />
        <Route path="/journal-share/:token" element={<JournalShare />} />
        <Route path="/schools/:id" element={<SchoolPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/change-phone" element={<ChangePhone />} />
        <Route path="/guardian-consent/:token" element={<GuardianConsent />} />
        <Route path="/find-account" element={<FindAccount />} />
        <Route path="/account" element={<Guard><Account /></Guard>} />
        <Route path="/account/password" element={<Guard><ChangePassword /></Guard>} />
        <Route path="/account/delete" element={<Guard><DeleteAccount /></Guard>} />
        <Route path="/favorites" element={<Guard role="student"><Favorites /></Guard>} />
        <Route path="/my-school" element={<Guard role="school"><SchoolAdmin /></Guard>} />
        <Route path="/admin" element={<Guard role="admin"><AdminPanel /></Guard>} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/refund" element={<Refund />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </Suspense>
      </main>

      <FloatingButton />

      <footer style={{ marginTop: "auto", borderTop: "1px solid var(--line)", padding: "24px 0", background: "var(--surface)" }}>
        <div className="wrap" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
            <span className="label" style={{ fontWeight: 700, color: "var(--ink)" }}>{ORG.operator}</span>
            <div style={{ display: "flex", gap: 16 }}>
              <Link to="/terms" className="label" style={{ color: "var(--steel)", fontWeight: 600, textDecoration: "none" }}>
                이용약관
              </Link>
              <Link to="/refund" className="label" style={{ color: "var(--steel)", fontWeight: 600, textDecoration: "none" }}>
                환불 규정
              </Link>
              <Link to="/privacy" className="label" style={{ color: "var(--signal-deep)", fontWeight: 700, textDecoration: "none" }}>
                개인정보처리방침
              </Link>
            </div>
          </div>
          <div style={{ fontSize: 12, color: "var(--steel-light)", lineHeight: 1.7 }}>
            대표 {ORG.representative} · 사업자등록번호 {ORG.businessNumber}
            {ORG.mailOrderNumber && <> · 통신판매업 신고 {ORG.mailOrderNumber}</>}<br />
            {ORG.address}<br />
            {ORG.contactPhone} · {ORG.contactEmail}<br />
            호스팅 제공 {ORG.hostingProvider}
          </div>

          {/* 패밀리 사이트. 링크를 늘어놓으면 푸터가 길어져 드롭다운으로 둔다. */}
          <div style={{ paddingTop: 14, marginTop: 4, borderTop: "1px solid var(--line)" }}>
            <FamilySites current="udj" />
          </div>

          <div className="label" style={{ color: "var(--steel-light)" }}>
            학교 정보 출처 · 나이스 교육정보 개방 포털 · 지도 OpenStreetMap · 기사 특성화고신문 제공
          </div>
          <div className="label" style={{ color: "var(--steel-light)", marginTop: 2 }}>
            © {new Date().getFullYear()} {ORG.operator}. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
