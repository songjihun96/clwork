import { useState } from "react";
import { api } from "../api";
import { Empty, Modal, Note, Pager, fmtDateTime, useList } from "../components/ui";

export default function Reviews() {
  const [status, setStatus] = useState("held");
  const [hiding, setHiding] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(0);

  const list = useList(({ limit, offset }) => api.reviews({ status, limit, offset }), [status]);

  const unhide = async (id) => {
    setBusy(id);
    setError("");
    try {
      await api.unhideReview(id);
      list.reload();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(0);
    }
  };

  return (
    <>
      <div className="page-head">
        <h1>후기</h1>
        <p>후기는 지우지 않고 숨깁니다. 사유는 작성자에게 그대로 안내됩니다.</p>
      </div>

      <div className="toolbar">
        {[
          ["held", "검토 필요"],
          ["hidden", "숨김"],
          ["visible", "공개"],
          ["", "전체"],
        ].map(([v, label]) => (
          <button
            key={v}
            className={`btn ${status === v ? "primary" : ""}`}
            onClick={() => setStatus(v)}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="card">
        <Note kind="bad">{error || list.error}</Note>
        {list.loading ? (
          <Empty>불러오는 중…</Empty>
        ) : list.items.length === 0 ? (
          <Empty>
            {status === "held" ? "검토가 필요한 후기가 없습니다." : "해당하는 후기가 없습니다."}
          </Empty>
        ) : (
          <>
            <table>
              <thead>
                <tr>
                  <th>학교</th>
                  <th>작성자</th>
                  <th>평점</th>
                  <th>내용</th>
                  <th>상태</th>
                  <th>작성일</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {list.items.map((r) => (
                  <tr key={r.id}>
                    <td>{r.school_name}</td>
                    <td>{r.writer}</td>
                    <td>{"★".repeat(r.rating)}</td>
                    <td style={{ maxWidth: 300, whiteSpace: "pre-wrap" }}>
                      {r.content}
                      {r.hold_reason && (
                        <div className="tiny" style={{ color: "var(--warn)", marginTop: 4 }}>
                          자동 보류: {r.hold_reason}
                        </div>
                      )}
                      {r.hidden_reason && (
                        <div className="tiny" style={{ color: "var(--danger)", marginTop: 4 }}>
                          숨김 사유: {r.hidden_reason}
                        </div>
                      )}
                    </td>
                    <td>
                      {r.is_hidden ? (
                        <span className="badge stop">숨김</span>
                      ) : r.status === "held" ? (
                        <span className="badge hold">보류</span>
                      ) : (
                        <span className="badge done">공개</span>
                      )}
                    </td>
                    <td className="tiny muted">{fmtDateTime(r.created_at)}</td>
                    <td>
                      {r.is_hidden ? (
                        <button className="btn sm" disabled={busy === r.id} onClick={() => unhide(r.id)}>
                          다시 공개
                        </button>
                      ) : (
                        <button className="btn sm danger" onClick={() => setHiding(r)}>
                          숨기기
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Pager {...list} onMove={list.move} />
          </>
        )}
      </div>

      {hiding && (
        <HideDialog
          review={hiding}
          onClose={() => setHiding(null)}
          onDone={() => {
            setHiding(null);
            list.reload();
          }}
        />
      )}
    </>
  );
}

function HideDialog({ review, onClose, onDone }) {
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!reason.trim()) {
      setError("사유를 적어주세요. 작성자에게 그대로 안내됩니다.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await api.hideReview(review.id, reason.trim());
      onDone();
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  };

  return (
    <Modal
      title="후기 숨기기"
      sub={`${review.school_name} · ${review.writer}`}
      onClose={onClose}
      foot={
        <>
          <button className="btn" onClick={onClose}>그만두기</button>
          <button className="btn danger" onClick={submit} disabled={busy}>
            {busy ? "처리 중…" : "숨기기"}
          </button>
        </>
      }
    >
      <Note kind="bad">{error}</Note>
      <div
        style={{
          background: "var(--raised)",
          border: "1px solid var(--line)",
          borderRadius: 6,
          padding: "10px 12px",
          whiteSpace: "pre-wrap",
          fontSize: 13.5,
          marginBottom: 14,
        }}
      >
        {review.content}
      </div>
      <div className="field">
        <label>숨김 사유</label>
        <input
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="예: 욕설이 포함되어 있습니다"
          onKeyDown={(e) => e.key === "Enter" && submit()}
        />
      </div>
    </Modal>
  );
}
