from datetime import date, datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, EmailStr, Field, field_validator

from .models import Coed, DeliveryStatus, InquiryStatus, OrderStatus, Plan, Role


# ---------- 인증 ----------
class SignupIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    name: str = Field(min_length=1, max_length=60)
    # 본인확인·계정찾기에 쓰는 휴대폰번호(필수). SMS 인증을 마쳐야 한다.
    phone: str = Field(min_length=10, max_length=30)
    phone_verification_token: str = Field(min_length=1)
    # 연령 확인용(필수). 만 14세 미만이면 법정대리인 동의 절차로 넘어간다.
    birth_date: date
    # 만 14세 미만일 때만 필요한 법정대리인 이메일.
    guardian_email: Optional[EmailStr] = None
    # 개인정보 수집·이용 동의(필수). True 여야 가입된다.
    privacy_consent: bool = False
    # 이용약관 동의(필수).
    terms_consent: bool = False

    @field_validator("privacy_consent")
    @classmethod
    def must_consent(cls, v: bool) -> bool:
        if not v:
            raise ValueError("개인정보 수집·이용에 동의해야 가입할 수 있습니다.")
        return v

    @field_validator("terms_consent")
    @classmethod
    def must_agree_terms(cls, v: bool) -> bool:
        if not v:
            raise ValueError("이용약관에 동의해야 가입할 수 있습니다.")
        return v


class LoginIn(BaseModel):
    email: EmailStr
    password: str


# ---------- 아이디/비밀번호 찾기·변경 ----------
class PhoneCodeIn(BaseModel):
    phone: str = Field(min_length=10, max_length=30)
    purpose: Literal["signup", "find_id", "reset_pw", "change_pw", "change_phone"]
    # 인증 채널이 이메일일 때 인증번호를 받을 주소(가입·재설정 단계에서 필요).
    email: Optional[EmailStr] = None


class PhoneVerifyIn(PhoneCodeIn):
    code: str = Field(min_length=6, max_length=6)


class FindIdIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    phone: str = Field(min_length=1, max_length=30)  # 동명이인 구분을 위한 2차 식별
    # 문자 채널일 때만 필수. 메일 채널에서는 아이디 찾기 인증이 불가능하다.
    phone_verification_token: Optional[str] = None


class ForgotPasswordIn(BaseModel):
    email: EmailStr


class ResetPasswordIn(BaseModel):
    email: EmailStr
    code: str = Field(min_length=6, max_length=6)
    new_password: str = Field(min_length=8, max_length=200)


class ResetPasswordByPhoneIn(BaseModel):
    """휴대폰 인증으로 비밀번호를 재설정한다(메일을 못 쓰는 경우)."""
    email: EmailStr
    phone: str = Field(min_length=10, max_length=30)
    phone_verification_token: str = Field(min_length=1)
    new_password: str = Field(min_length=8, max_length=200)


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=200)
    # 휴대폰번호가 등록된 계정만 필수. 미등록 계정은 비밀번호 확인만으로 변경한다.
    phone_verification_token: Optional[str] = None


class DeleteAccountIn(BaseModel):
    password: str  # 본인 확인용 현재 비밀번호


class AdminResetPasswordIn(BaseModel):
    new_password: str = Field(min_length=8, max_length=200)


class UserOut(BaseModel):
    id: int
    email: EmailStr
    name: str
    role: Role
    school_id: Optional[int] = None
    school_name: Optional[str] = None
    phone: str = ""   # 미등록 안내를 띄우기 위해 함께 내려준다

    class Config:
        from_attributes = True


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- 학교 ----------
class SchoolBase(BaseModel):
    name: str
    category: str
    region: str
    address: str
    coed: Coed
    dormitory: Optional[bool] = None
    foundation: str = ""
    phone: str = ""
    website: str = ""
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class SchoolCreate(SchoolBase):
    pass


class SchoolAdminUpdate(BaseModel):
    """관리자만 바꿀 수 있는 항목."""

    name: Optional[str] = None
    category: Optional[str] = None
    region: Optional[str] = None
    address: Optional[str] = None
    coed: Optional[Coed] = None
    dormitory: Optional[bool] = None
    foundation: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    plan: Optional[Plan] = None
    plan_expires_at: Optional[date] = None


class SchoolProfileUpdate(BaseModel):
    """학교 계정이 스스로 채우는 상세 정보."""

    slogan: Optional[str] = None
    intro: Optional[str] = None
    departments: Optional[str] = None
    facilities: Optional[str] = None
    admission_info: Optional[str] = None
    employment_rate: Optional[float] = None
    student_count: Optional[int] = None
    established_year: Optional[int] = None
    hero_image: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    dormitory: Optional[bool] = None

    @field_validator("hero_image", "website")
    @classmethod
    def safe_url(cls, v: Optional[str]) -> Optional[str]:
        """javascript:, data: 같은 위험한 스킴을 막고 http/https만 허용한다(XSS 방어)."""
        if not v:
            return v
        v = v.strip()
        if not v:
            return v
        low = v.lower()
        if low.startswith("http://") or low.startswith("https://"):
            return v
        raise ValueError("이미지·웹사이트 주소는 http:// 또는 https:// 로 시작해야 합니다.")


class SchoolListItem(BaseModel):
    """검색 결과 목록에 기본으로 노출되는 정보."""

    id: int
    name: str
    category: str
    region: str
    address: str
    coed: Coed
    dormitory: Optional[bool]
    foundation: str
    phone: str
    website: str
    latitude: Optional[float]
    longitude: Optional[float]
    slogan: str
    hero_image: str
    plan: Plan
    actual_plan: Optional[Plan] = None
    plan_paused: bool = False
    is_visible: bool = True
    rating_avg: float
    review_count: int
    is_favorite: bool = False
    # 학교 계정 + SMTP 등록이 되어 '빠른 문의'(이메일 답변)가 가능한 상태인지.
    can_quick_inquiry: bool = False

    class Config:
        from_attributes = True


class SchoolListOut(BaseModel):
    total: int
    page: int
    size: int
    items: List[SchoolListItem]


class EventOut(BaseModel):
    id: int
    kind: str = "admission"  # "admission"=입시 일정, "briefing"=학교 설명회
    title: str
    start_date: date
    end_date: Optional[date]
    description: str
    d_day: int  # 오늘 기준 남은 일수(음수면 지남)

    class Config:
        from_attributes = True


class ReviewOut(BaseModel):
    id: int
    rating: int
    content: str
    author: str
    created_at: datetime
    mine: bool = False

    class Config:
        from_attributes = True


class SchoolDetailOut(SchoolListItem):
    """상세 페이지. 기본 정보 + 학교 계정이 추가한 정보."""

    intro: str
    departments: List[str]
    facilities: str
    admission_info: str
    employment_rate: Optional[float]
    student_count: Optional[int]
    established_year: Optional[int]
    view_count: int
    # 로그인한 학생의 재학생 인증 상태: none/pending/approved/rejected
    my_verification: str = "none"
    events: List[EventOut] = []
    reviews: List[ReviewOut] = []


class VerifyRequestIn(BaseModel):
    note: str = ""  # 학번/학년 등 학교가 확인할 수 있는 소개


# ---------- 즐겨찾기 ----------
class FavoriteIn(BaseModel):
    school_id: int
    memo: str = ""


class FavoriteOut(BaseModel):
    school: SchoolListItem
    memo: str
    created_at: datetime


# ---------- 리뷰 ----------
class ReviewIn(BaseModel):
    rating: int = Field(ge=1, le=5)
    content: str = Field(max_length=1000)


# ---------- 학교 일정(입시 일정 · 학교 설명회) ----------
class EventIn(BaseModel):
    kind: Literal["admission", "briefing"] = "admission"
    title: str
    start_date: date
    end_date: Optional[date] = None
    description: str = ""


# ---------- 플랜 ----------
class PlanInfo(BaseModel):
    plan: Plan
    label: str
    price_per_month: int
    rank: int
    perks: List[str]


class OrderIn(BaseModel):
    tax_email: str = ""      # 세금계산서 받을 이메일
    tax_manager: str = ""    # 담당자명
    plan: Plan
    months: int = Field(ge=1, le=36)
    note: str = ""


class OrderOut(BaseModel):
    id: int
    school_id: int
    school_name: str
    plan: Plan
    months: int
    amount: int
    status: OrderStatus
    status_label: str = ""
    note: str
    deposit_code: str = ""
    tax_email: str = ""
    tax_manager: str = ""
    created_at: datetime
    due_at: Optional[datetime] = None
    paid_at: Optional[datetime] = None
    handled_at: Optional[datetime]

    class Config:
        from_attributes = True


# ---------- 학교 문의 (Q&A) ----------
class InquiryCreate(BaseModel):
    """방문자가 학교에 남기는 질문. 로그인 없이도 남길 수 있다."""

    asker_name: str = Field(default="", max_length=60)
    contact_email: EmailStr  # 답변을 받을 이메일(필수)
    # 메일이 반송되거나 주소를 잘못 적는 일이 잦아, 학교가 연락할 길을
    # 하나 더 받아 둔다.
    contact_phone: str = Field(min_length=9, max_length=30)
    question: str = Field(min_length=5, max_length=2000)
    # 개인정보 수집·이용 동의. 반드시 True 여야 접수된다.
    privacy_consent: bool

    @field_validator("privacy_consent")
    @classmethod
    def must_consent(cls, v: bool) -> bool:
        if not v:
            raise ValueError("개인정보 수집·이용에 동의해야 문의를 남길 수 있습니다.")
        return v


class InquiryOut(BaseModel):
    """학교 계정이 보는 문의 상세. 답변하려면 연락처가 보여야 한다."""

    id: int
    asker_name: str
    contact_email: EmailStr
    contact_phone: str
    question: str
    status: InquiryStatus
    answer: str
    answered_at: Optional[datetime]
    delivery_status: DeliveryStatus
    delivery_error: str
    created_at: datetime

    class Config:
        from_attributes = True


class InquiryAnswer(BaseModel):
    answer: str = Field(min_length=1, max_length=4000)


# ---------- 학교 메일 계정(SMTP) 설정 ----------
class MailConfigIn(BaseModel):
    mail_host: str = Field(max_length=120)
    mail_port: int = Field(default=587, ge=1, le=65535)
    mail_username: str = Field(default="", max_length=120)
    mail_from: EmailStr  # 보내는 주소(필수)
    mail_ssl: bool = False
    # 비밀번호는 저장할 때만 보낸다. 빈 값이면 기존 비밀번호를 유지한다.
    mail_password: Optional[str] = Field(default=None, max_length=200)


class MailConfigOut(BaseModel):
    """비밀번호는 절대 내려주지 않는다. 저장 여부만 알려준다."""

    mail_host: str
    mail_port: int
    mail_username: str
    mail_from: str
    mail_ssl: bool
    has_password: bool
    configured: bool  # 발송에 필요한 값이 모두 채워졌는지


class MailTestIn(BaseModel):
    to: Optional[EmailStr] = None  # 비우면 보내는 주소 자신에게 테스트 발송


# ---------- 학교 계정 생성(관리자 전용) ----------
class SchoolAccountIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    name: str
    school_id: int


# ---------- 통계 ----------
class DailyPoint(BaseModel):
    day: str
    count: int


class SchoolStatsOut(BaseModel):
    view_count: int
    favorite_count: int
    review_count: int
    rating_avg: float
    plan: Plan
    plan_expires_at: Optional[date]
    search_rank_hint: int
    daily_views: List[DailyPoint]


class AdminStatsOut(BaseModel):
    school_count: int
    student_count: int
    school_account_count: int
    pending_orders: int
    monthly_revenue: int
    plan_distribution: dict
    region_distribution: dict
    top_viewed: List[dict]
    quiz_stats: dict = {}


# ---------- 진로 적성 테스트 ----------
class GeocodeOut(BaseModel):
    lat: float
    lng: float
    address: str


class QuizSubmit(BaseModel):
    answers: List[str] = Field(description="문항별 1~5 점 척도 문자열")
    # 어떤 문항을 보고 답했는지. 회차마다 문항이 달라지므로 이 값으로
    # 학생이 본 문항을 되살려 채점한다. 없으면 예전 고정 문항으로 본다.
    seed: Optional[int] = None
    lat: Optional[float] = None
    lng: Optional[float] = None
    location_label: str = ""
    commute_time: str = Field(description="TIME_OPTIONS의 key (30m/1h/1h30/2h/any)")


class QuizDeptOut(BaseModel):
    label: str
    axis: str
    axis_label: str
    desc: str
    jobs: List[str]


class QuizSchoolOut(BaseModel):
    id: int
    name: str
    region: str
    address: str
    category: str
    coed: str
    dormitory: Optional[bool]
    plan: str
    matched_departments: List[str]
    distance_km: Optional[float]
    distance_approx: bool


class QuizResultOut(BaseModel):
    scores: dict
    sub_scores: dict
    top_axes: List[str]
    quality: dict
    confidence: str
    axis_labels: dict
    departments: List[QuizDeptOut]
    schools: List[QuizSchoolOut]
    location_label: str
    has_location: bool
    shows_distance: bool
    commute_label: str
    matched_count: int


# ---------- 기사 ----------
class ArticleOut(BaseModel):
    id: int
    url: str
    title: str
    summary: str
    thumbnail: str
    published_at: Optional[date]
    school_id: Optional[int]
    school_name: Optional[str] = None
    source: str

    class Config:
        from_attributes = True


class ArticleManualCreate(BaseModel):
    url: str = Field(min_length=8)
    title: str = Field(min_length=2, max_length=300)
    summary: str = ""
    thumbnail: str = ""
    school_id: Optional[int] = None


# ---------- 학교생활 일지 / 수업 일지 ----------
class JournalIn(BaseModel):
    kind: Literal["lesson", "diary"] = "diary"
    entry_date: Optional[date] = None
    subject: str = ""
    teacher_name: str = ""
    content: dict = {}
    resume_tags: List[str] = []


class ResumeRequest(BaseModel):
    template: str = "school_life"


class JournalSend(BaseModel):
    teacher_email: EmailStr


# ---------- 선생님 계정 ----------
class TeacherGrant(BaseModel):
    """이미 가입한 계정에 선생님 권한을 부여한다."""
    user_id: int
    class_name: str = ""


class TeacherUpdate(BaseModel):
    class_name: Optional[str] = None
    is_active: Optional[bool] = None


class TeacherRegisterStudent(BaseModel):
    user_id: int
    class_name: str = ""


class VerifyApprove(BaseModel):
    class_name: str = ""


class PlanPerksIn(BaseModel):
    """플랜에서 켤 혜택 항목의 키 목록. reset=True 면 기본값으로 되돌린다."""
    keys: List[str] = []
    reset: bool = False


class BankInfoIn(BaseModel):
    bank_name: Optional[str] = None
    bank_account: Optional[str] = None
    bank_holder: Optional[str] = None
    payment_note: Optional[str] = None
    due_days: Optional[str] = None


# ---------- 공지 ----------
class NoticeIn(BaseModel):
    scope: str = "all"                 # all | school | teachers
    school_id: Optional[int] = None
    title: str
    body: str = ""
    image_url: str = ""
    is_popup: bool = False
    is_important: bool = False
    starts_at: Optional[datetime] = None
    ends_at: Optional[datetime] = None


class SubscriptionOrderIn(BaseModel):
    """구독 주문 생성. 금액은 서버가 정하므로 받지 않는다."""
    months: int = Field(default=1, ge=1, le=12)
    # 만 19세 미만일 때 필요한 법정대리인 동의(민법 제5조)
    minor_consent: bool = False
    guardian_contact: str = Field(default="", max_length=120)


class PaymentConfirmIn(BaseModel):
    """토스 결제창 성공 후 서버 승인 요청."""
    payment_key: str = Field(min_length=1, max_length=200)
    order_id: str = Field(min_length=1, max_length=64)
    amount: int = Field(ge=0)


class SpellCheckIn(BaseModel):
    """맞춤법 검사 요청. 항목별로 한꺼번에 보낼 수도 있다."""
    text: str = Field(default="", max_length=20000)
    fields: dict = Field(default_factory=dict)


class CoverLetterIn(BaseModel):
    """개인 자기소개서 저장."""
    title: str = Field(default="", max_length=120)
    template: str = Field(default="", max_length=40)
    content: dict = Field(default_factory=dict)


class MyAccountIn(BaseModel):
    """마이페이지에서 본인이 고칠 수 있는 항목.

    휴대폰번호는 본인확인 수단이라 여기서 바꿀 수 없다.
    ChangePhoneIn(POST /api/me/change-phone)으로만 변경한다.
    """
    name: str


class ChangePhoneIn(BaseModel):
    """등록된 휴대폰번호 변경. 현재 비밀번호 + 새 번호 SMS 인증이 모두 필요하다."""
    current_password: str
    new_phone: str = Field(min_length=10, max_length=30)
    phone_verification_token: str = Field(min_length=1)


class FloatingButtonIn(BaseModel):
    """오른쪽 아래 플로팅 버튼 설정."""
    enabled: bool = False
    url: str = ""
    label: str = "바로가기"
    roles: List[str] = ["school", "teacher"]
