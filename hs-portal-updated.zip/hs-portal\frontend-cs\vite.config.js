import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 상담 사이트. 본 사이트와 같은 백엔드(8000)를 쓴다.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5175,   // 본 사이트(5173)·기록해(5174)와 겹치지 않게
    proxy: {
      '/api': { target: 'http://localhost:8000', changeOrigin: true },
    },
  },
})
