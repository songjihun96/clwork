import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";

export default function CoverLetters() {
  const navigate = useNavigate();
  const [items, setItems] = useState(null);
  const [locked, setLocked] = useState(false);
  // 요금은 관리자가 바꿀 수 있다. 화면에 박아두면 바꿔도 예전 값이 남는다.
  const [price, setPrice] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.coverLetters()
      .then(setItems)
      .catch((e) => {
        // 402 는 구독이 필요하다는 뜻
        if (e.status === 402) {
          setLocked(true);
          api.subscription().then((s) => setPrice(s.price_per_month)).catch(() => {});
        }
        else setError(e.message);
        setItems([]);
      });
  }, []);

  if (locked) {
    return (
      <div className="wrap page" style={{ maxWidth: 620 }}>
        <span className="label">자기소개서</span>
        <h1>내 기록으로 자기소개서를 씁니다</h1>
        <p style={{ color: "var(--steel)", lineHeight: 1.8 }}>
          그동안 남긴 일지와 일기를 자기소개서 항목에 맞게 정리할 수 있습니다.
          <b> 일지 작성과 선생님께 제출은 계속 무료</b>이고, 자기소개서만 이용권이 필요합니다.
        </p>

        <div className="panel" style={{ marginTop: 18 }}>
          <CodeBox onDone={() => window.location.reload()} />
        </div>
      </div>
    );
  }

  if (error) {
    return <div className="wrap page"><div className="notice notice-error">{error}</div></div>;
  }
  if (!items) return <div className="wrap page"><p>불러오는 중…</p></div>;

  return (
    <div className="wrap page">
      <div className="row">
        <div>
          <span className="label">자기소개서</span>
          <h1 style={{ marginTop: 4 }}>내 자기소개서</h1>
        </div>
        <div className="spacer" />
        <Link to="/cover-letters/new" className="btn btn-primary">새로 쓰기</Link>
      </div>
      <p style={{ color: "var(--steel)", fontSize: 14, marginTop: 10, lineHeight: 1.8 }}>
        글을 쓸 때 그 항목에 맞는 <b>내 일지</b>가 옆에 함께 나옵니다.
        막막하면 거기서 골라 넣고 내 말로 다듬으면 됩니다.
      </p>

      <div style={{ marginTop: 20 }}>
        {items.length === 0 ? (
          <div className="empty">
            <h3>아직 작성한 자기소개서가 없습니다</h3>
            <p>일지에 남긴 경험을 항목별로 정리해보세요.</p>
          </div>
        ) : (
          items.map((it) => (
            <Link key={it.id} to={`/cover-letters/${it.id}`} className="entry">
              <h4>{it.title || "제목 없음"}</h4>
              <div className="meta">
                마지막 수정 {String(it.updated_at).slice(0, 10)}
              </div>
            </Link>
          ))
        )}
      </div>

      <p style={{ fontSize: 13, color: "var(--steel-light)", marginTop: 20 }}>
        <Link to="/subscribe">구독 상태 확인</Link>
      </p>
    </div>
  );
}

/** 학교에서 받은 등록 코드를 넣는 곳.
 *  개인이 결제하는 구조가 아니라, 학교가 나눠준 코드로 이용권을 받는다. */
function CodeBox({ onDone }) {
  const [code, setCode] = useState("");
  const [studentNo, setStudentNo] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  const submit = async () => {
    setBusy(true); setMsg(null);
    try {
      const r = await api.redeemSeatCode(code.trim(), studentNo.trim() || undefined);
      setMsg({ type: "ok", text: r.message });
      setTimeout(onDone, 900);
    } catch (e) {
      setMsg({ type: "error", text: e.message });
      setBusy(false);
    }
  };

  return (
    <div style={{ textAlign: "left", maxWidth: 380, margin: "0 auto" }}>
      <div className="label">학교에서 받은 등록 코드</div>
      <p className="meta" style={{ margin: "4px 0 8px", lineHeight: 1.7 }}>
        자기소개서 이용권은 학교가 신청합니다. 선생님께 받은 코드를 넣어주세요.
      </p>
      <div className="row" style={{ gap: 8 }}>
        <input className="input" value={code} placeholder="예: A3KD-7F2M"
          style={{ flex: 1, fontFamily: "ui-monospace, Menlo, monospace",
                   letterSpacing: "0.08em", textTransform: "uppercase" }}
          onChange={(e) => setCode(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()} />
      </div>
      <div className="field" style={{ marginTop: 8 }}>
        <label className="label" style={{ fontWeight: 400 }}>
          내 번호 <span style={{ color: "var(--steel-light)" }}>(선택 — 알고 있으면 적어주세요)</span>
        </label>
        <input className="input" type="number" min="1" max="999" value={studentNo}
          placeholder="예: 17" style={{ maxWidth: 120 }}
          onChange={(e) => setStudentNo(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()} />
      </div>
      <button className="btn btn-primary" style={{ marginTop: 10, width: "100%" }}
        onClick={submit} disabled={busy || !code.trim()}>
        {busy ? "확인 중…" : "등록"}
      </button>
      {msg && <div className={`notice notice-${msg.type}`} style={{ marginTop: 10 }}>{msg.text}</div>}
      <p className="meta" style={{ marginTop: 10, lineHeight: 1.7 }}>
        코드가 없으시면 담당 선생님께 문의해주세요.
        일지 작성과 제출은 코드 없이도 계속 무료입니다.
      </p>
    </div>
  );
}
