"""UDJ 기존 기능 회귀. 배포 전에 돌려 본다."""
import os,sys,json
os.environ["DATABASE_URL"]="sqlite:////tmp/ur.db"; os.environ["SECRET_KEY"]="x"

# 앞선 검사의 자료가 남아 있으면 결과가 달라져,
# 멀쩡한 코드가 실패한 것처럼 보인다. 먼저 지운다.
if os.path.exists("/tmp/ur.db"):
    os.remove("/tmp/ur.db")
sys.path.insert(0,".")
from fastapi.testclient import TestClient
from app.main import app
from app.database import SessionLocal
from app.models import *
from app.auth import hash_password, create_access_token
from datetime import datetime, date, timedelta
OK=[]
def chk(n,c,e=""):
    OK.append(bool(c)); print(("  OK  " if c else "  FAIL")+f"  {n}"+(f"  {e}" if not c and e else ""))

db=SessionLocal()
sc=School(name="근명고등학교",category="특성화고",region="경기",address="양주시 고암동",
          coed=Coed.coed,departments="기계과\n전기과\n소프트웨어과",
          latitude=37.79,longitude=127.05,is_visible=True,phone="031-000-0000")
db.add(sc); db.commit(); db.refresh(sc); SID=sc.id
adm=User(email="a@t.kr",password_hash=hash_password("p1234567"),name="관리자",role=Role.admin)
tea=User(email="t@t.kr",password_hash=hash_password("p1234567"),name="김선생",
         role=Role.teacher,school_id=SID,class_name="2-3")
stu=User(email="s@t.kr",password_hash=hash_password("p1234567"),name="홍길동",
         role=Role.student,school_id=SID)
sch=User(email="sc@t.kr",password_hash=hash_password("p1234567"),name="학교",
         role=Role.school,school_id=SID)
for u in (adm,tea,stu,sch): db.add(u)
db.commit(); [db.refresh(u) for u in (adm,tea,stu,sch)]
AH={"Authorization":f"Bearer {create_access_token(adm)}"}
TH={"Authorization":f"Bearer {create_access_token(tea)}"}
SH={"Authorization":f"Bearer {create_access_token(stu)}"}
CH={"Authorization":f"Bearer {create_access_token(sch)}"}
db.close()
c=TestClient(app)

print("=== 로그인·계정 ===")
r=c.post("/api/auth/login", json={"email":"s@t.kr","password":"p1234567"})
chk("로그인", r.status_code==200 and r.json().get("access_token"), str(r.json())[:80])
chk("잘못된 비밀번호 거부", c.post("/api/auth/login",
    json={"email":"s@t.kr","password":"wrong"}).status_code in (400,401))
chk("내 정보", c.get("/api/auth/me", headers=SH).status_code==200)

print("=== 학교 검색·상세 ===")
r=c.get("/api/schools", params={"page":1,"size":20})
chk("검색", r.status_code==200 and r.json()["total"]>=1, str(r.json())[:80])
chk("지역 거르기", c.get("/api/schools", params={"region":"경기"}).status_code==200)
chk("이름 검색", c.get("/api/schools", params={"q":"근명"}).json()["total"]>=1)
chk("상세", c.get(f"/api/schools/{SID}").status_code==200)
chk("조회수 셈", c.post(f"/api/schools/{SID}/view").status_code==200)
chk("없는 학교", c.get("/api/schools/99999").status_code==404)

print("=== 진로 테스트 ===")
q=c.get("/api/quiz/questions")
# 36문항 5점 척도. 6축 × 6문항으로 고르게 물어본다.
chk("문항", q.status_code==200 and len(q.json()["questions"])==36,
    str(len(q.json().get("questions",[]))))
chk("척도 있음", q.json()["questions"][0].get("scale"),
    str(q.json()["questions"][0])[:80])
chk("seed 있음", isinstance(q.json().get("seed"), int))
chk("거리 선택지 km", "km" in q.json()["time_options"][0]["label"], q.json()["time_options"][0]["label"])
# 모두 '매우 그렇다'(5) 로 답한다.
r=c.post("/api/quiz/result", json={"answers":["5"]*36,"seed":q.json()["seed"],
  "lat":37.79,"lng":127.05,"location_label":"경기도 양주시","commute_time":"any"})
chk("결과", r.status_code==200, str(r.json())[:100])
chk("학교 추천", len(r.json().get("schools",[]))>=1,
    f"{len(r.json().get('schools',[]))}곳 · 계열 "
    + str([g["label"] for g in r.json().get("departments",[])][:2]))
chk("위치 없이도", c.post("/api/quiz/result",
    json={"answers":["3"]*36,"commute_time":"any"}).status_code==200)
chk("세부 점수 있음", "sub_scores" in r.json(), str(list(r.json()))[:100])
chk("확신도 있음", r.json().get("confidence") in ("high","close"), str(r.json().get("confidence")))
chk("동일 응답 신뢰도 경고", r.json().get("quality",{}).get("reliable") is False,
    str(r.json().get("quality")))
chk("다양한 응답은 신뢰도 정상",
    c.post("/api/quiz/result", json={"answers":[str((i%5)+1) for i in range(36)],
      "commute_time":"any"}).json().get("quality",{}).get("reliable") is True)

print("=== 즐겨찾기·후기·문의 ===")
chk("즐겨찾기 추가", c.post("/api/favorites", json={"school_id":SID},
    headers=SH).status_code==200)
chk("즐겨찾기 목록", len(c.get("/api/favorites", headers=SH).json())>=1)
chk("즐겨찾기 해제", c.delete(f"/api/favorites/{SID}", headers=SH).status_code==200)
r=c.post(f"/api/schools/{SID}/inquiries", json={
  "contact_email":"q@t.kr","contact_phone":"010-1234-5678",
  "question":"기숙사 신청은 어떻게 하나요?","privacy_consent":True})
chk("문의 접수", r.status_code==200, str(r.json())[:80])
chk("연락처 없으면 거부", c.post(f"/api/schools/{SID}/inquiries", json={
  "contact_email":"q@t.kr","question":"문의합니다","privacy_consent":True}).status_code==422)

print("=== 공개 정보 ===")
for path in ("/api/home", "/api/terms", "/api/notices", "/api/articles",
             "/api/sigungu", "/api/verify-config", "/api/geo-config"):
    params = {"region": "경기"} if path.endswith("sigungu") else None
    chk(path, c.get(path, params=params).status_code in (200, 404),
        str(c.get(path, params=params).status_code))

print("=== 관리자 ===")
chk("통계", c.get("/api/admin/stats", headers=AH).status_code==200)
r=c.get("/api/admin/stats/export", headers=AH)
chk("영업 CSV", r.status_code==200 and len(r.content)>500, str(r.status_code))
txt=r.content.decode("utf-8-sig")
for want in ("우선 영업 대상","노출은 많은데","지역별 수요 대비 공급"):
    chk(f"CSV '{want}'", want in txt)
# 학교 목록은 공개 검색을 쓴다. /api/admin/schools 는 등록용(POST)이다.
chk("학교 등록 권한", c.post("/api/admin/schools", json={}, headers=AH).status_code in (400,422))
chk("계정 관리", c.get("/api/admin/users", headers=AH).status_code==200)
chk("학생은 관리자 API 못 씀", c.get("/api/admin/stats", headers=SH).status_code==403)

print("=== 학교 담당자 ===")
chk("우리 학교", c.get("/api/school-admin/school", headers=CH).status_code in (200,404))
# 학생에게는 담당 학교가 없어 404 로 막힌다. 어느 쪽이든 못 본다.
chk("학생은 못 봄", c.get("/api/school-admin/school",
    headers=SH).status_code in (403,404))

print("=== 선생님 ===")
chk("학급 목록", c.get("/api/teacher/class-options", headers=TH).status_code==200)
chk("학생은 못 씀", c.get("/api/teacher/class-options", headers=SH).status_code==403)

print("=== 계정 검색 — 다른 학교 학생은 안 보여야 한다 ===")
db=SessionLocal()
sc2=School(name="저쪽고등학교",category="특성화고",region="서울",address="b",
          coed=Coed.coed,departments="디자인과",latitude=37.5,longitude=127.0,is_visible=True)
db.add(sc2); db.commit(); db.refresh(sc2); SID2=sc2.id
other=User(email="etc-uniq@t.kr",password_hash=hash_password("p1234567"),
          name="다른학교유일이름",role=Role.student,school_id=SID2)
other_tea=User(email="etc-tea-uniq@t.kr",password_hash=hash_password("p1234567"),
          name="저쪽학교유일교사",role=Role.teacher,school_id=SID2)
db.add(other); db.add(other_tea); db.commit()
db.close()
r=c.get("/api/teacher/students/search", params={"q":"다른학교유일이름"}, headers=TH).json()
chk("선생님 검색 — 다른 학교 학생 안 나옴", all(u["name"]!="다른학교유일이름" for u in r), str(r))
r=c.get("/api/school-admin/users/search", params={"q":"다른학교유일이름"}, headers=CH).json()
chk("학교 계정 검색 — 다른 학교 학생 안 나옴", all(u["name"]!="다른학교유일이름" for u in r), str(r))
r=c.get("/api/school-admin/users/search", params={"q":"김선생"}, headers=CH).json()
chk("학교 계정 검색 — 우리 학교 선생님은 그대로 나옴", any(u["name"]=="김선생" for u in r), str(r))
r=c.get("/api/school-admin/users/search", params={"q":"저쪽학교유일교사"}, headers=CH).json()
chk("학교 계정 검색 — 다른 학교 선생님은 중복 신청 확인용으로 여전히 나옴(other_school 표시)",
    any(u["name"]=="저쪽학교유일교사" and u["other_school"] for u in r), str(r))

print("=== 계열 분류 ===")
from app import dept_fields as df
chk("기계과", "machine" in (df.to_storage("기계과") or ""))
chk("모빌리티과", "machine" in (df.to_storage("모빌리티모터스과") or ""))
chk("스마트양식과는 농림", "agri" in (df.to_storage("스마트양식과") or ""),
    df.to_storage("스마트양식과"))
chk("양식조리과는 조리", "food" in (df.to_storage("양식조리과") or ""),
    df.to_storage("양식조리과"))
print(); print(f"===== {sum(OK)}/{len(OK)} 통과 =====")
sys.exit(0 if all(OK) else 1)
