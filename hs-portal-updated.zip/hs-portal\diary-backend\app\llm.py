"""외부 AI 를 부르는 자리.

AI 호출을 코드 곳곳에 흩어 두면 실패 처리와 동시 실행 제한을 곳곳에
다시 써야 한다. 여기 한 곳에서만 부른다.

**서비스가 먼저다**

AI 가 죽어도 일지 쓰기·자소서 쓰기·로그인은 그대로 돌아야 한다.
그래서 이 파일의 모든 함수는 예외를 밖으로 던지지 않고
`LLMResult` 로 성공·실패를 알려 준다. 부르는 쪽은 실패를 보고
"AI 를 쓸 수 없습니다" 라고만 말하면 된다.

**동시에 여러 개를 부르지 않는다**

돈이 나가는 일이고, 한 학생이 버튼을 연타하면 그만큼 청구된다.
동시 실행 수를 막아 둔다.

**개인정보를 로그에 남기지 않는다**

방침에 그렇게 적었다. 로그에는 무엇을 했는지와 얼마나 걸렸는지만
남기고, 글 내용은 남기지 않는다.
"""

import json
import os
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Optional

import requests

# ── 설정 ────────────────────────────────────────────────────
# 키는 서버 .env 에만 둔다. 코드에도 화면에도 두지 않는다.
API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
API_URL = os.getenv("ANTHROPIC_API_URL", "https://api.anthropic.com/v1/messages")
MODEL = os.getenv("AI_MODEL", "claude-sonnet-4-6")
TIMEOUT = int(os.getenv("AI_TIMEOUT", "120"))
MAX_CONCURRENT = int(os.getenv("AI_MAX_CONCURRENT", "2"))
MAX_INPUT_CHARS = int(os.getenv("AI_MAX_INPUT", "12000"))
MAX_OUTPUT_TOKENS = int(os.getenv("AI_MAX_OUTPUT", "2000"))

# 동시에 도는 요청 수를 막는다. 웹 요청이 AI 때문에 밀리면 안 된다.
_gate = threading.Semaphore(MAX_CONCURRENT)


def available() -> bool:
    """AI 를 쓸 수 있는 상태인가. 키가 없으면 못 쓴다."""
    return bool(API_KEY)


def status() -> dict:
    """관리자·화면이 확인할 상태. 키 자체는 절대 내보내지 않는다."""
    return {
        "available": available(),
        "model": MODEL if available() else "",
        "max_concurrent": MAX_CONCURRENT,
    }


@dataclass
class LLMResult:
    """AI 호출 결과. 예외 대신 이것을 돌려준다."""

    ok: bool
    text: str = ""
    data: Optional[dict] = None
    error: str = ""          # 화면에 보여줄 말
    error_type: str = ""     # 로그용 갈래
    duration_ms: int = 0
    meta: dict = field(default_factory=dict)


# 화면에 보여줄 말. 내부 사정을 그대로 보이면 안 된다.
_USER_MESSAGE = {
    "no_key": "AI 기능이 아직 준비되지 않았습니다.",
    "busy": "AI 요청이 몰려 있습니다. 잠시 뒤에 다시 눌러주세요.",
    "timeout": "AI 분석이 오래 걸려 멈췄습니다. 잠시 뒤에 다시 시도해주세요.",
    "too_long": "글이 너무 깁니다. 나누어서 분석해주세요.",
    "bad_json": "AI 응답을 읽지 못했습니다. 다시 시도해주세요.",
    "empty": "AI 가 답을 주지 않았습니다. 다시 시도해주세요.",
    "http": "AI 서버에 연결하지 못했습니다. 잠시 뒤에 다시 시도해주세요.",
}


def _log(request_id: str, op: str, ok: bool, ms: int, err: str = "") -> None:
    """무엇을 얼마나 했는지만 남긴다. 글 내용은 남기지 않는다."""
    tail = f" error={err}" if err else ""
    print(f"[AI] id={request_id} op={op} ok={ok} ms={ms} model={MODEL}{tail}",
          flush=True)


def _call(prompt: str, op: str, temperature: float = 0.2,
          max_tokens: Optional[int] = None,
          image_b64: Optional[str] = None, image_media_type: str = "image/jpeg") -> LLMResult:
    """AI 를 한 번 부른다. 어떤 경우에도 예외를 던지지 않는다.

    image_b64 를 주면 사진 설명(caption) 처럼 이미지를 함께 보내는 요청이
    된다 — 사용자가 명시적으로 "사진 설명 생성" 을 눌렀을 때만 이 값이
    채워지고, 사진을 올렸다고 자동으로 불리지는 않는다(부르는 쪽 책임).
    """
    request_id = uuid.uuid4().hex[:8]

    if not available():
        _log(request_id, op, False, 0, "no_key")
        return LLMResult(False, error=_USER_MESSAGE["no_key"], error_type="no_key")

    if len(prompt) > MAX_INPUT_CHARS:
        _log(request_id, op, False, 0, "too_long")
        return LLMResult(False, error=_USER_MESSAGE["too_long"],
                         error_type="too_long")

    # 자리가 날 때까지 기다린다. 너무 오래 기다리면 포기한다.
    if not _gate.acquire(timeout=30):
        _log(request_id, op, False, 0, "busy")
        return LLMResult(False, error=_USER_MESSAGE["busy"], error_type="busy")

    if image_b64:
        content = [
            {"type": "image", "source": {"type": "base64",
             "media_type": image_media_type, "data": image_b64}},
            {"type": "text", "text": prompt},
        ]
    else:
        content = prompt

    started = time.time()
    try:
        res = requests.post(
            API_URL,
            headers={
                "x-api-key": API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": MODEL,
                "max_tokens": max_tokens or MAX_OUTPUT_TOKENS,
                "temperature": temperature,
                "messages": [{"role": "user", "content": content}],
            },
            timeout=TIMEOUT,
        )
        ms = int((time.time() - started) * 1000)

        if res.status_code != 200:
            # 응답 본문에 글 내용이 섞여 있을 수 있어 상태 코드만 남긴다.
            _log(request_id, op, False, ms, f"http_{res.status_code}")
            return LLMResult(False, error=_USER_MESSAGE["http"],
                             error_type=f"http_{res.status_code}",
                             duration_ms=ms)

        body = res.json()
        text = "".join(
            part.get("text", "")
            for part in (body.get("content") or [])
            if part.get("type") == "text"
        ).strip()

        if not text:
            _log(request_id, op, False, ms, "empty")
            return LLMResult(False, error=_USER_MESSAGE["empty"],
                             error_type="empty", duration_ms=ms)

        usage = body.get("usage") or {}
        _log(request_id, op, True, ms)
        return LLMResult(
            True, text=text, duration_ms=ms,
            meta={"in_tokens": usage.get("input_tokens"),
                  "out_tokens": usage.get("output_tokens")},
        )

    except requests.Timeout:
        ms = int((time.time() - started) * 1000)
        _log(request_id, op, False, ms, "timeout")
        return LLMResult(False, error=_USER_MESSAGE["timeout"],
                         error_type="timeout", duration_ms=ms)
    except Exception as exc:
        ms = int((time.time() - started) * 1000)
        # 예외 메시지에 글 내용이 들어갈 수 있어 갈래만 남긴다.
        _log(request_id, op, False, ms, type(exc).__name__)
        return LLMResult(False, error=_USER_MESSAGE["http"],
                         error_type=type(exc).__name__, duration_ms=ms)
    finally:
        _gate.release()


# JSON 만 달라고 해도 앞뒤에 설명을 붙여 오는 일이 있다.
_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.S)


def _extract_json(text: str) -> Optional[dict]:
    """답에서 JSON 을 꺼낸다. 앞뒤에 군더더기가 붙어 있어도 찾아낸다."""
    if not text:
        return None

    # 1) 통째로 JSON 인 경우
    try:
        out = json.loads(text)
        return out if isinstance(out, dict) else None
    except ValueError:
        pass

    # 2) ```json ... ``` 로 감싼 경우
    m = _FENCE.search(text)
    if m:
        try:
            out = json.loads(m.group(1))
            return out if isinstance(out, dict) else None
        except ValueError:
            pass

    # 3) 첫 { 부터 마지막 } 까지
    start, end = text.find("{"), text.rfind("}")
    if 0 <= start < end:
        try:
            out = json.loads(text[start:end + 1])
            return out if isinstance(out, dict) else None
        except ValueError:
            pass
    return None


def generate(prompt: str, temperature: float = 0.2,
             max_tokens: Optional[int] = None, op: str = "generate") -> LLMResult:
    """글을 받아 온다."""
    return _call(prompt, op, temperature, max_tokens)


def generate_json(prompt: str, temperature: float = 0.1,
                  max_tokens: Optional[int] = None,
                  op: str = "generate_json", retry: int = 1,
                  image_b64: Optional[str] = None,
                  image_media_type: str = "image/jpeg") -> LLMResult:
    """JSON 을 받아 온다.

    형식이 어긋나면 한 번 더 물어본다. 그 이상은 하지 않는다.
    부를 때마다 돈이 나가고, 두 번 실패하면 세 번째도 실패하기 쉽다.
    """
    for attempt in range(retry + 1):
        r = _call(prompt, op, temperature, max_tokens, image_b64, image_media_type)
        if not r.ok:
            return r

        data = _extract_json(r.text)
        if data is not None:
            r.data = data
            return r

        if attempt >= retry:
            _log("-", op, False, r.duration_ms, "bad_json")
            return LLMResult(False, text=r.text, error=_USER_MESSAGE["bad_json"],
                             error_type="bad_json", duration_ms=r.duration_ms)

        # 다시 물을 때는 형식만 짧게 다시 일러 준다.
        prompt = prompt + "\n\n반드시 JSON 만 출력하십시오. 다른 말을 붙이지 마십시오."

    return LLMResult(False, error=_USER_MESSAGE["bad_json"], error_type="bad_json")
