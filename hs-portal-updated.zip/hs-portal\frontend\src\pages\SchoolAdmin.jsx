import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import NoticeComposer from "../components/NoticeComposer";
import ClassPicker, { formatClass, parseClass } from "../components/ClassPicker";
import { api, PLAN_LABEL } from "../api";
import { ddayText } from "../components/SchoolDetailView";

const STATUS_LABEL = { pending: "승인 대기", approved: "승인됨", rejected: "반려됨" };

const DELIVERY_LABEL = {
  pending: "미발송",
  sent: "메일 발송 완료",
  failed: "메일 발송 실패",
  not_configured: "메일 서버 미설정",
};

// 주요 메일 서비스별 SMTP 접속 정보 프리셋
const MAIL_PRESETS = {
  naver: { label: "네이버", host: "smtp.naver.com", port: 587, ssl: false },
  gmail: { label: "지메일(Gmail)", host: "smtp.gmail.com", port: 587, ssl: false },
  daum: { label: "다음/카카오", host: "smtp.daum.net", port: 465, ssl: true },
  nate: { label: "네이트", host: "smtp.mail.nate.com", port: 465, ssl: true },
  outlook: { label: "아웃룩/핫메일", host: "smtp-mail.outlook.com", port: 587, ssl: false },
  custom: { label: "직접 입력", host: "", port: 587, ssl: false },
};

function detectProvider(host) {
  const entry = Object.entries(MAIL_PRESETS).find(([k, v]) => k !== "custom" && v.host === host);
  return entry ? entry[0] : "custom";
}

function MailConfigPanel() {
  const [cfg, setCfg] = useState(null);
  const [loadErr, setLoadErr] = useState("");
  const [provider, setProvider] = useState("naver");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState(false);
  const [msg, setMsg] = useState(null);
  const [open, setOpen] = useState(false);

  const load = () => {
    setLoadErr("");
    api
      .mailConfig()
      .then((c) => {
        setCfg(c);
        setProvider(c.mail_host ? detectProvider(c.mail_host) : "naver");
        if (!c.configured) setOpen(true); // 미설정이면 펼쳐서 유도
      })
      .catch((e) => setLoadErr(e.message || "메일 설정을 불러오지 못했습니다."));
  };

  useEffect(() => { load(); }, []);

  if (loadErr) {
    return (
      <div className="panel">
        <h3 style={{ border: "none", padding: 0, margin: "0 0 8px", fontSize: 15 }}>답변 발송 메일 계정</h3>
        <div className="notice notice-error">
          메일 설정을 불러오지 못했습니다: {loadErr}
          <br />서버를 다시 시작했는지 확인하고, 페이지를 새로고침해 주세요.
        </div>
        <button className="btn btn-ghost btn-sm" style={{ marginTop: 10 }} onClick={load}>다시 시도</button>
      </div>
    );
  }

  if (!cfg) {
    return (
      <div className="panel">
        <h3 style={{ border: "none", padding: 0, margin: 0, fontSize: 15 }}>답변 발송 메일 계정</h3>
        <p style={{ color: "var(--steel)", fontSize: 13, margin: "8px 0 0" }}>불러오는 중…</p>
      </div>
    );
  }

  const set = (k) => (e) => setCfg({ ...cfg, [k]: e.target.value });

  const pickProvider = (p) => {
    setProvider(p);
    const preset = MAIL_PRESETS[p];
    if (p !== "custom") {
      setCfg({ ...cfg, mail_host: preset.host, mail_port: preset.port, mail_ssl: preset.ssl });
    }
  };

  const save = async () => {
    setMsg(null);
    if (!cfg.mail_from?.trim()) return setMsg({ type: "error", text: "보내는 이메일 주소를 입력해주세요." });
    if (!cfg.mail_host?.trim()) return setMsg({ type: "error", text: "SMTP 서버 주소를 입력해주세요." });
    if (!cfg.has_password && !password) return setMsg({ type: "error", text: "메일 비밀번호(또는 앱 비밀번호)를 입력해주세요." });
    setBusy(true);
    try {
      const saved = await api.saveMailConfig({
        mail_host: cfg.mail_host.trim(),
        mail_port: Number(cfg.mail_port) || 587,
        mail_username: (cfg.mail_username || cfg.mail_from).trim(),
        mail_from: cfg.mail_from.trim(),
        mail_ssl: !!cfg.mail_ssl,
        mail_password: password || undefined,
      });
      setCfg(saved);
      setPassword("");
      setMsg({ type: "ok", text: "메일 계정을 저장했습니다. '테스트 발송'으로 정상 동작을 확인하세요." });
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const test = async () => {
    setMsg(null);
    setTesting(true);
    try {
      const res = await api.testMailConfig();
      setMsg({ type: "ok", text: `테스트 메일을 ${res.sent_to} 로 발송했습니다. 받은편지함을 확인하세요.` });
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="panel">
      <div style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer" }} onClick={() => setOpen((v) => !v)}>
        <h3 style={{ border: "none", padding: 0, margin: 0, fontSize: 15 }}>답변 발송 메일 계정</h3>
        <span className={`badge ${cfg.configured ? "badge-dorm" : ""}`}>
          {cfg.configured ? "학교 계정으로 발송" : "포털이 대신 발송"}
        </span>
        <span className="label" style={{ color: "var(--steel-light)" }}>선택 사항</span>
        <span className="label" style={{ marginLeft: "auto" }}>{open ? "접기 ▲" : "펼치기 ▼"}</span>
      </div>

      {open && (
        <div style={{ display: "grid", gap: 12, marginTop: 14 }}>
          <div className="notice notice-ok">
            <b>설정하지 않아도 답변은 정상 발송됩니다.</b><br />
            등록하지 않으면 포털이 학교 이름으로 대신 보내드리고, 학생이 답장하면
            학교 주소로 전달됩니다. 학교 메일 주소를 발신자로 직접 쓰고 싶을 때만 아래를 설정하세요.
          </div>
          <div className="notice notice-info">
            학교가 등록한 이 계정에서 문의 답변이 발송됩니다.<br />
            <b>① 메일 환경설정에서 「IMAP/SMTP 사용」을 켜세요.</b><br />
            <b>② 비밀번호는 로그인 비밀번호가 아니라 「앱(애플리케이션) 비밀번호」</b>를 발급받아 넣어야 합니다.<br />
            <b>③ 네이버는 로그인 아이디에 <code>@naver.com</code> 없이 아이디만</b> 입력하세요 (예: songjihun96).
          </div>

          <div className="field">
            <label className="label">메일 서비스</label>
            <select className="select" value={provider} onChange={(e) => pickProvider(e.target.value)}>
              {Object.entries(MAIL_PRESETS).map(([k, v]) => (
                <option key={k} value={k}>{v.label}</option>
              ))}
            </select>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div className="field">
              <label className="label">보내는 이메일 주소 (필수)</label>
              <input className="input" type="email" value={cfg.mail_from || ""} onChange={set("mail_from")}
                placeholder="school@school.hs.kr" />
            </div>
            <div className="field">
              <label className="label">로그인 아이디 (비우면 이메일과 동일)</label>
              <input className="input" value={cfg.mail_username || ""} onChange={set("mail_username")}
                placeholder="보통 이메일 주소와 같음" />
            </div>
          </div>

          <div className="field">
            <label className="label">비밀번호 / 앱 비밀번호 {cfg.has_password && "(저장됨 · 바꿀 때만 입력)"}</label>
            <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
              placeholder={cfg.has_password ? "●●●●●●●● (변경하려면 입력)" : "메일 비밀번호 또는 앱 비밀번호"} />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr", gap: 12 }}>
            <div className="field">
              <label className="label">SMTP 서버</label>
              <input className="input" value={cfg.mail_host || ""} onChange={set("mail_host")}
                disabled={provider !== "custom"} placeholder="smtp.naver.com" />
            </div>
            <div className="field">
              <label className="label">포트</label>
              <input className="input" type="number" value={cfg.mail_port || 587} onChange={set("mail_port")}
                disabled={provider !== "custom"} />
            </div>
            <div className="field">
              <label className="label">보안 연결</label>
              <select className="select" value={cfg.mail_ssl ? "ssl" : "starttls"}
                disabled={provider !== "custom"}
                onChange={(e) => setCfg({ ...cfg, mail_ssl: e.target.value === "ssl" })}>
                <option value="ssl">SSL (465)</option>
                <option value="starttls">STARTTLS (587)</option>
              </select>
            </div>
          </div>

          {msg && <div className={`notice notice-${msg.type}`}>{msg.text}</div>}

          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-signal" onClick={save} disabled={busy}>
              {busy ? "저장 중…" : "메일 계정 저장"}
            </button>
            <button className="btn btn-ghost" onClick={test} disabled={testing || !cfg.configured}>
              {testing ? "발송 중…" : "테스트 발송"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function AttachmentPicker({ id, attachments, setAttachments }) {
  const files = attachments[id] || [];
  const onPick = (e) => {
    const picked = Array.from(e.target.files || []);
    const merged = [...files, ...picked].slice(0, 5);
    setAttachments({ ...attachments, [id]: merged });
    e.target.value = ""; // 같은 파일 다시 선택 가능하게
  };
  const removeAt = (i) => {
    const next = files.filter((_, idx) => idx !== i);
    setAttachments({ ...attachments, [id]: next });
  };
  const totalMB = (files.reduce((n, f) => n + f.size, 0) / (1024 * 1024)).toFixed(1);

  return (
    <div>
      <label className="btn btn-ghost btn-sm" style={{ cursor: "pointer", display: "inline-block" }}>
        📎 파일 첨부
        <input type="file" multiple onChange={onPick} style={{ display: "none" }} />
      </label>
      {files.length > 0 && (
        <div style={{ marginTop: 6, display: "flex", flexDirection: "column", gap: 4 }}>
          {files.map((f, i) => (
            <div key={i} style={{ fontSize: 12.5, color: "var(--steel)", display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {f.name} ({(f.size / 1024).toFixed(0)}KB)
              </span>
              <button className="btn btn-ghost btn-sm" style={{ padding: "1px 7px", fontSize: 11 }} onClick={() => removeAt(i)}>×</button>
            </div>
          ))}
          <span className="label" style={{ color: totalMB > 10 ? "var(--alert)" : "var(--steel-light)" }}>
            총 {totalMB}MB · 최대 5개, 합계 10MB
          </span>
        </div>
      )}
    </div>
  );
}

function InquiriesTab({ inquiries, reload }) {
  const [drafts, setDrafts] = useState({});
  const [attachments, setAttachments] = useState({});
  const [busyId, setBusyId] = useState(null);
  const [msg, setMsg] = useState(null);

  const send = async (id) => {
    const answer = (drafts[id] || "").trim();
    if (!answer) return setMsg({ type: "error", text: "답변 내용을 입력해주세요." });
    setBusyId(id);
    setMsg(null);
    try {
      const res = await api.answerInquiry(id, answer, attachments[id] || []);
      if (res.delivery_status === "sent") {
        setMsg({ type: "ok", text: "답변을 저장하고 문의자 이메일로 발송했습니다." });
      } else {
        setMsg({
          type: "info",
          text: `답변은 저장됐지만 이메일이 발송되지 않았습니다 (${DELIVERY_LABEL[res.delivery_status] || res.delivery_status}). ${res.delivery_error || ""}`,
        });
      }
      setAttachments({ ...attachments, [id]: [] });
      reload();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusyId(null);
    }
  };

  const remove = async (id) => {
    if (!window.confirm("이 문의를 삭제할까요? 개인정보(이메일 등)가 함께 파기됩니다.")) return;
    await api.deleteInquiry(id);
    reload();
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <MailConfigPanel />

      <div className="notice notice-info">
        방문자가 남긴 문의입니다. 답변을 저장하면 문의자가 입력한 이메일로 답변이 자동 발송됩니다.
        개인정보 보호를 위해 처리가 끝난 문의는 삭제해 주세요. (접수 후 1년이 지난 문의는 자동 파기됩니다.)
      </div>

      {msg && <div className={`notice notice-${msg.type}`}>{msg.text}</div>}

      {inquiries.length === 0 ? (
        <div className="panel"><p style={{ margin: 0, color: "var(--steel)", fontSize: 13.5 }}>아직 들어온 문의가 없습니다.</p></div>
      ) : (
        inquiries.map((q) => (
          <div className="panel" key={q.id}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
              <span className={`badge ${q.status === "answered" ? "badge-dorm" : ""}`}>
                {q.status === "answered" ? "답변 완료" : "미답변"}
              </span>
              {q.status === "answered" && (
                <span className="label" style={{ color: q.delivery_status === "sent" ? "var(--verify)" : "var(--alert)" }}>
                  {DELIVERY_LABEL[q.delivery_status] || q.delivery_status}
                </span>
              )}
              <span className="label" style={{ marginLeft: "auto" }}>{q.created_at.slice(0, 16).replace("T", " ")}</span>
              <button className="btn btn-ghost btn-sm" style={{ padding: "3px 8px", fontSize: 11 }} onClick={() => remove(q.id)}>
                삭제
              </button>
            </div>

            <div style={{ fontSize: 13, color: "var(--steel)", marginBottom: 6 }}>
              {q.asker_name || "이름 미기재"} · {q.contact_email}
              {q.contact_phone ? ` · ${q.contact_phone}` : ""}
            </div>
            <p className="prose" style={{ fontSize: 14, margin: "0 0 12px" }}>{q.question}</p>

            {q.status === "answered" ? (
              <div style={{ borderTop: "1px solid var(--line)", paddingTop: 10 }}>
                <span className="label">보낸 답변</span>
                <p className="prose" style={{ fontSize: 13.5, marginTop: 4 }}>{q.answer}</p>
                {q.delivery_status !== "sent" && (
                  <div style={{ display: "grid", gap: 8, marginTop: 8 }}>
                    <textarea className="textarea" placeholder="답변을 수정해 다시 발송할 수 있습니다."
                      value={drafts[q.id] ?? q.answer} onChange={(e) => setDrafts({ ...drafts, [q.id]: e.target.value })} />
                    <AttachmentPicker id={q.id} attachments={attachments} setAttachments={setAttachments} />
                    <div>
                      <button className="btn btn-sm" onClick={() => send(q.id)} disabled={busyId === q.id}>
                        {busyId === q.id ? "발송 중…" : "다시 발송"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div style={{ display: "grid", gap: 8, borderTop: "1px solid var(--line)", paddingTop: 10 }}>
                <textarea className="textarea" placeholder="답변 내용을 입력하세요. 저장하면 문의자 이메일로 발송됩니다."
                  value={drafts[q.id] || ""} onChange={(e) => setDrafts({ ...drafts, [q.id]: e.target.value })} />
                <AttachmentPicker id={q.id} attachments={attachments} setAttachments={setAttachments} />
                <div>
                  <button className="btn btn-signal btn-sm" onClick={() => send(q.id)} disabled={busyId === q.id}>
                    {busyId === q.id ? "발송 중…" : "답변 저장 및 발송"}
                  </button>
                </div>
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
}

function ProfileTab({ profile, reload }) {
  const [form, setForm] = useState(profile);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async () => {
    setBusy(true);
    setMsg(null);
    try {
      await api.saveProfile({
        slogan: form.slogan,
        intro: form.intro,
        departments: form.departments,
        facilities: form.facilities,
        admission_info: form.admission_info,
        employment_rate: form.employment_rate === "" ? null : Number(form.employment_rate),
        student_count: form.student_count === "" ? null : Number(form.student_count),
        established_year: form.established_year === "" ? null : Number(form.established_year),
        hero_image: form.hero_image,
        phone: form.phone,
        website: form.website,
        dormitory: form.dormitory === "" ? null : form.dormitory === "true",
      });
      setMsg({ type: "ok", text: "저장했습니다. 검색 결과와 상세 페이지에 바로 반영됩니다." });
      reload();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="notice notice-info">
        학교 이름·주소·계열은 나이스에서 받아온 값이라 이곳에서 바꿀 수 없습니다.
        틀린 부분이 있으면 포털 관리자에게 알려주세요.
      </div>

      <div className="panel">
        <h3>검색 결과에 보이는 정보</h3>
        <div style={{ display: "grid", gap: 14 }}>
          <div className="field">
            <label className="label">한 줄 소개</label>
            <input className="input" value={form.slogan || ""} onChange={set("slogan")}
              placeholder="예: 반도체 장비 인재를 키우는 학교" maxLength={120} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div className="field">
              <label className="label">기숙사 운영</label>
              <select className="select" value={form.dormitory === null ? "" : String(form.dormitory)}
                onChange={(e) => setForm({ ...form, dormitory: e.target.value })}>
                <option value="">미확인</option>
                <option value="true">운영함</option>
                <option value="false">운영하지 않음</option>
              </select>
            </div>
            <div className="field">
              <label className="label">전화번호</label>
              <input className="input" value={form.phone || ""} onChange={set("phone")} />
            </div>
            <div className="field">
              <label className="label">홈페이지</label>
              <input className="input" value={form.website || ""} onChange={set("website")} />
            </div>
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>상세 페이지에만 보이는 정보</h3>
        <div style={{ display: "grid", gap: 14 }}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div className="field">
              <label className="label">학생 수</label>
              <input className="input" type="number" value={form.student_count ?? ""} onChange={set("student_count")} />
            </div>
            <div className="field">
              <label className="label">취업률 (%)</label>
              <input className="input" type="number" step="0.1" value={form.employment_rate ?? ""} onChange={set("employment_rate")} />
            </div>
            <div className="field">
              <label className="label">개교 연도</label>
              <input className="input" type="number" value={form.established_year ?? ""} onChange={set("established_year")} />
            </div>
          </div>
          <div className="field">
            <label className="label">개설 학과 (한 줄에 하나씩)</label>
            <textarea className="textarea" value={form.departments || ""} onChange={set("departments")}
              placeholder={"스마트전기과\n반도체장비과"} />
          </div>
          <div className="field">
            <label className="label">학교 소개</label>
            <textarea className="textarea" value={form.intro || ""} onChange={set("intro")} />
          </div>
          <div className="field">
            <label className="label">실습 시설</label>
            <textarea className="textarea" value={form.facilities || ""} onChange={set("facilities")} />
          </div>
          <div className="field">
            <label className="label">입학 안내</label>
            <textarea className="textarea" value={form.admission_info || ""} onChange={set("admission_info")} />
          </div>
        </div>
      </div>

      {msg && <div className={`notice notice-${msg.type}`}>{msg.text}</div>}
      <div>
        <button className="btn btn-signal" onClick={save} disabled={busy}>
          {busy ? "저장 중…" : "변경사항 저장"}
        </button>
      </div>
    </div>
  );
}

function StatsTab({ stats }) {
  const data = stats.daily_views.map((d) => ({ day: d.day.slice(5), 조회수: d.count }));
  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="stat-grid">
        <div className="stat">
          <span className="label">누적 조회수</span>
          <div className="stat-value">{stats.view_count.toLocaleString()}</div>
        </div>
        <div className="stat">
          <span className="label">즐겨찾기</span>
          <div className="stat-value">{stats.favorite_count.toLocaleString()}<small> 명</small></div>
        </div>
        <div className="stat">
          <span className="label">후기 / 평점</span>
          <div className="stat-value">
            {stats.rating_avg ? `★${stats.rating_avg}` : "—"}
            <small> ({stats.review_count})</small>
          </div>
        </div>
        <div className="stat">
          <span className="label">같은 지역·계열 내 노출 순서</span>
          <div className="stat-value">{stats.search_rank_hint}<small> 번째</small></div>
        </div>
      </div>

      <div className="panel">
        <h3>최근 14일 조회수</h3>
        <div style={{ height: 240 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
              <CartesianGrid strokeDasharray="2 4" stroke="#dbe1e6" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11, fill: "#8a99a6" }} tickLine={false} axisLine={{ stroke: "#dbe1e6" }} />
              <YAxis tick={{ fontSize: 11, fill: "#8a99a6" }} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                contentStyle={{ border: "1px solid #dbe1e6", borderRadius: 4, fontSize: 13 }}
                cursor={{ fill: "rgba(255,197,61,0.12)" }}
              />
              <Bar dataKey="조회수" fill="#ff7a59" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

const EVENT_KIND_LABEL = { admission: "입시 일정", briefing: "학교 설명회" };

function TeachersTab({ teachers, reload }) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const [cls, setCls] = useState({ grade: "", ban: "" });
  const [target, setTarget] = useState(null);

  const search = async () => {
    if (q.trim().length < 2) return setMsg({ type: "error", text: "2글자 이상 입력해주세요." });
    setBusy(true); setMsg(null);
    try { setResults(await api.searchUsersForTeacher(q.trim())); }
    catch (e) { setMsg({ type: "error", text: e.message }); }
    finally { setBusy(false); }
  };

  const openGrant = (u) => { setCls({ grade: "", ban: "" }); setTarget({ mode: "grant", user: u }); };
  const changeClass = (t) => { setCls(parseClass(t.class_name)); setTarget({ mode: "edit", user: t }); };

  const confirmGrant = async () => {
    const className = formatClass(cls.grade, cls.ban);
    try {
      if (target.mode === "grant") {
        await api.grantTeacher(target.user.id, className);
        setMsg({ type: "ok", text: `${target.user.name} 님에게 선생님 권한을 부여했습니다.` });
        setResults(null); setQ("");
      } else {
        await api.updateTeacher(target.user.id, { class_name: className });
        setMsg({ type: "ok", text: "담당 학급을 변경했습니다." });
      }
      setTarget(null); reload();
    } catch (e) { setMsg({ type: "error", text: e.message }); }
  };

  const toggle = async (t) => { await api.updateTeacher(t.id, { is_active: !t.is_active }); reload(); };

  const revoke = async (t) => {
    if (!window.confirm(`${t.name} 선생님의 권한을 해제할까요?\n계정은 삭제되지 않고 일반 사용자로 돌아갑니다.`)) return;
    await api.revokeTeacher(t.id);
    reload();
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="notice notice-info">
        선생님이 <b>먼저 일반 회원가입</b>을 한 뒤, 그 계정을 아래에서 찾아 <b>선생님 권한</b>을 부여하세요.
        비밀번호는 선생님 본인이 정한 것을 그대로 사용하므로 학교가 따로 관리할 필요가 없습니다.
      </div>

      <div className="panel">
        <h3>선생님 권한 부여</h3>
        <p style={{ fontSize: 13, color: "var(--steel)", marginTop: -4 }}>
          가입된 계정을 아이디(이메일)·이름·연락처로 검색하세요.
        </p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input className="input" style={{ flex: 1, minWidth: 220 }} value={q}
            placeholder="이메일 / 이름 / 연락처"
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && search()} />
          <button className="btn btn-primary btn-sm" onClick={search} disabled={busy}>
            {busy ? "검색 중…" : "검색"}
          </button>
        </div>
        {msg && <div className={`notice notice-${msg.type === "error" ? "error" : "ok"}`} style={{ marginTop: 10 }}>{msg.text}</div>}

        {results && (
          <div style={{ marginTop: 12, display: "grid", gap: 8 }}>
            {results.length === 0 ? (
              <p style={{ fontSize: 13.5, color: "var(--steel)", margin: 0 }}>
                검색 결과가 없습니다. 선생님이 회원가입을 했는지 확인해 주세요.
              </p>
            ) : results.map((u) => (
              <div key={u.id} className="event-row">
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>{u.name}</div>
                  <div style={{ fontSize: 12.5, color: "var(--steel)" }}>
                    {u.email}{u.phone ? ` · ${u.phone}` : ""}
                  </div>
                </div>
                {u.is_our_teacher ? (
                  <span className="badge badge-dorm">이미 우리 학교 선생님</span>
                ) : u.other_school ? (
                  <span className="badge badge-unknown">다른 학교 선생님</span>
                ) : (
                  <button className="btn btn-primary btn-sm" onClick={() => openGrant(u)}>선생님 권한 부여</button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {target && (
        <div className="panel" style={{ borderColor: "var(--signal)" }}>
          <h3>{target.mode === "grant" ? `${target.user.name} 님에게 권한 부여` : `${target.user.name} 선생님 학급 변경`}</h3>
          <ClassPicker grade={cls.grade} ban={cls.ban} onChange={setCls} />
          <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
            <button className="btn btn-primary btn-sm" onClick={confirmGrant}>
              {target.mode === "grant" ? "권한 부여" : "학급 저장"}
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => setTarget(null)}>취소</button>
          </div>
        </div>
      )}

      <div className="panel">
        <h3>우리 학교 선생님 ({teachers.length})</h3>
        {teachers.length === 0 ? (
          <p style={{ fontSize: 13.5, color: "var(--steel)", margin: 0 }}>아직 등록된 선생님이 없습니다.</p>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {teachers.map((t) => (
              <div key={t.id} className="event-row">
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14 }}>
                    {t.name} <span style={{ fontWeight: 400, fontSize: 12.5, color: "var(--steel)" }}>{t.class_name}</span>
                    {!t.is_active && <span className="badge" style={{ marginLeft: 6 }}>정지됨</span>}
                  </div>
                  <div style={{ fontSize: 12.5, color: "var(--steel)" }}>{t.email}</div>
                </div>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  <button className="btn btn-ghost btn-sm" onClick={() => changeClass(t)}>학급 변경</button>
                  <button className="btn btn-ghost btn-sm" onClick={() => toggle(t)}>{t.is_active ? "정지" : "활성화"}</button>
                  <button className="btn btn-ghost btn-sm" onClick={() => revoke(t)}>권한 해제</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function EventsTab({ plan, events, reload }) {
  const [form, setForm] = useState({ kind: "admission", title: "", start_date: "", end_date: "", description: "" });
  const [error, setError] = useState("");

  const add = async () => {
    setError("");
    try {
      await api.addEvent({
        kind: form.kind,
        title: form.title,
        start_date: form.start_date,
        end_date: form.end_date || null,
        description: form.description,
      });
      setForm({ kind: form.kind, title: "", start_date: "", end_date: "", description: "" });
      reload();
    } catch (e) {
      setError(e.message);
    }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      {plan === "free" && (
        <div className="notice notice-info">
          입시 일정·학교 설명회 등록은 베이직 플랜부터 쓸 수 있습니다. 등록하면 학생의 즐겨찾기 화면에 D-day로 뜹니다.
        </div>
      )}

      <div className="panel">
        <h3>일정 추가</h3>
        <div style={{ display: "grid", gap: 12 }}>
          <div className="field">
            <label className="label">일정 종류</label>
            <select className="input" value={form.kind}
              onChange={(e) => setForm({ ...form, kind: e.target.value })}>
              <option value="admission">입시 일정</option>
              <option value="briefing">학교 설명회</option>
            </select>
          </div>
          <div className="field">
            <label className="label">일정 이름</label>
            <input className="input" value={form.title}
              placeholder={form.kind === "briefing" ? "예: 2학기 입학 설명회" : "예: 신입생 원서접수"}
              onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div className="field">
              <label className="label">시작일</label>
              <input className="input" type="date" value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
            </div>
            <div className="field">
              <label className="label">종료일 (선택)</label>
              <input className="input" type="date" value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
            </div>
          </div>
          <div className="field">
            <label className="label">설명 (선택)</label>
            <input className="input" value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          {error && <div className="notice notice-error">{error}</div>}
          <div>
            <button className="btn" onClick={add} disabled={!form.title || !form.start_date}>
              일정 추가
            </button>
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>등록된 일정 ({events.length})</h3>
        {events.length === 0 ? (
          <p style={{ fontSize: 13.5, color: "var(--steel)", margin: 0 }}>등록된 일정이 없습니다.</p>
        ) : (
          ["admission", "briefing"].map((kind) => {
            const list = events.filter((e) => (e.kind || "admission") === kind);
            if (list.length === 0) return null;
            return (
              <div key={kind} style={{ marginBottom: 14 }}>
                <div className="label" style={{ fontWeight: 700, color: "var(--ink)", margin: "6px 0" }}>
                  {EVENT_KIND_LABEL[kind]} ({list.length})
                </div>
                {list.map((e) => (
                  <div className="event-row" key={e.id}>
                    <span className={`dday ${e.d_day < 0 ? "past" : e.d_day <= 14 ? "near" : ""}`}>{ddayText(e.d_day)}</span>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{e.title}</div>
                      <div style={{ fontSize: 12.5, color: "var(--steel)" }}>
                        {e.start_date}{e.end_date ? ` ~ ${e.end_date}` : ""}
                      </div>
                    </div>
                    <button className="btn btn-ghost btn-sm" onClick={async () => { await api.deleteEvent(e.id); reload(); }}>
                      삭제
                    </button>
                  </div>
                ))}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

function PlanTab({ profile, plans, orders, reload }) {
  const myPerks = profile.my_perks || [];
  const baseFeatures = profile.base_features || [];
  const [selected, setSelected] = useState("premium");
  const [months, setMonths] = useState(3);
  const [msg, setMsg] = useState(null);
  const [tax, setTax] = useState({ email: "", manager: "" });
  const [agreed, setAgreed] = useState(false);
  const [bank, setBank] = useState(null);

  useEffect(() => { api.schoolBankInfo().then(setBank).catch(() => {}); }, []);

  const openDoc = async (id, kind) => {
    try { await api.openOrderDoc(id, kind, false); }
    catch (e) { setMsg({ type: "error", text: e.message }); }
  };

  // 아직 입금 전인 신청 (안내를 크게 보여준다)
  const waiting = (orders || []).find((o) => o.status === "pending" || o.status === "paid");

  const request = async () => {
    setMsg(null);
    if (!agreed) {
      return setMsg({ type: "error", text: "환불 규정을 확인하고 동의해 주세요." });
    }
    try {
      await api.requestPlan(selected, Number(months), "", tax);
      setMsg({ type: "ok", text: "신청했습니다. 아래 입금 안내를 확인해 주세요." });
      reload();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    }
  };

  const price = plans.find((p) => p.plan === selected)?.price_per_month || 0;

  return (
    <div style={{ display: "grid", gap: 16 }}>

      <div className="panel" style={{ marginBottom: 16 }}>
        <h3>현재 사용 중인 기능</h3>
        <div style={{ marginTop: 8 }}>
          <span className="label">기본 제공 (모든 플랜)</span>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 4 }}>
            {baseFeatures.map((t) => (
              <span key={t} className="badge">{t}</span>
            ))}
          </div>
        </div>
        <div style={{ marginTop: 12 }}>
          <span className="label">플랜 혜택</span>
          {myPerks.length === 0 ? (
            <p style={{ fontSize: 13.5, color: "var(--steel)", margin: "4px 0 0" }}>
              현재 플랜에는 추가 혜택이 없습니다. 아래에서 플랜을 신청하면 더 많은 기능을 쓸 수 있습니다.
            </p>
          ) : (
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 4 }}>
              {myPerks.map((t) => (
                <span key={t} className="badge badge-dorm">{t}</span>
              ))}
            </div>
          )}
        </div>
      </div>
      <div className="stat" style={{ borderLeft: "4px solid var(--signal)" }}>
        <span className="label">현재 플랜</span>
        <div className="stat-value">
          {PLAN_LABEL[profile.plan]}
          {profile.plan_expires_at && <small> · {profile.plan_expires_at}까지</small>}
          {profile.plan_is_free_trial && (
            <span className="badge" style={{ marginLeft: 8, verticalAlign: "middle" }}>
              무료 체험
            </span>
          )}
        </div>
        {/* 갑자기 기능이 사라지면 곤란하므로 미리 알린다. */}
        {profile.plan_is_free_trial && (
          <p style={{ fontSize: 12.5, color: "var(--steel)", margin: "6px 0 0", lineHeight: 1.7 }}>
            무료로 제공된 플랜입니다. {profile.plan_expires_at}까지 이용하실 수 있고,
            그 뒤에는 무료 플랜으로 돌아갑니다. 계속 쓰시려면 기간이 끝나기 전에
            플랜을 신청해주세요.
          </p>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px,1fr))", gap: 10 }}>
        {plans.map((p) => (
          <button
            key={p.plan}
            onClick={() => p.plan !== "free" && setSelected(p.plan)}
            disabled={p.plan === "free"}
            className="panel"
            style={{
              textAlign: "left", cursor: p.plan === "free" ? "default" : "pointer",
              borderColor: selected === p.plan ? "var(--signal)" : "var(--line)",
              borderWidth: selected === p.plan ? 2 : 1,
              opacity: p.plan === "free" ? 0.6 : 1,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
              <h3 style={{ border: "none", padding: 0, margin: 0, fontSize: 15 }}>{p.label}</h3>
              {profile.plan === p.plan && <span className="badge badge-dorm">이용 중</span>}
            </div>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 20, marginBottom: 10 }}>
              {p.price_per_month === 0 ? "무료" : `${p.price_per_month.toLocaleString()}원`}
              <span style={{ fontSize: 12, color: "var(--steel)" }}>{p.price_per_month > 0 && " / 월"}</span>
            </div>
            <ul style={{ margin: 0, paddingLeft: 16, fontSize: 12.5, color: "var(--steel)", lineHeight: 1.8 }}>
              {p.perks.map((perk) => <li key={perk}>{perk}</li>)}
            </ul>
          </button>
        ))}
      </div>

      <div className="panel">
        <h3>플랜 신청</h3>
        <div style={{ display: "flex", gap: 12, alignItems: "end", flexWrap: "wrap" }}>
          <div className="field" style={{ minWidth: 130 }}>
            <label className="label">플랜</label>
            <select className="select" value={selected} onChange={(e) => setSelected(e.target.value)}>
              {plans.filter((p) => p.plan !== "free").map((p) => (
                <option key={p.plan} value={p.plan}>{p.label}</option>
              ))}
            </select>
          </div>
          <div className="field" style={{ minWidth: 100 }}>
            <label className="label">기간 (개월)</label>
            <input className="input" type="number" min="1" max="36" value={months}
              onChange={(e) => setMonths(e.target.value)} />
          </div>
          <div className="field">
            <span className="label">결제 예정 금액</span>
            <div style={{ fontFamily: "var(--font-display)", fontSize: 20 }}>
              {(price * Number(months || 0)).toLocaleString()}원
            </div>
          </div>
          <button className="btn btn-signal" onClick={request}>신청하기</button>
        </div>

        <div style={{ marginTop: 12, paddingTop: 12, borderTop: "1px solid var(--line)" }}>
          <label style={{ display: "flex", gap: 8, alignItems: "flex-start", cursor: "pointer" }}>
            <input type="checkbox" checked={agreed} onChange={(e) => setAgreed(e.target.checked)}
              style={{ marginTop: 3 }} />
            <span style={{ fontSize: 13.5, lineHeight: 1.6 }}>
              <b>환불 규정</b>을 확인했으며 이에 동의합니다.
              <span style={{ color: "var(--steel)" }}>
                {" "}시작 전 취소는 전액 환불, 시작 후 중도 해지는 남은 일수만큼 일할 계산해 환불됩니다.
              </span>{" "}
              <Link to="/refund" target="_blank" style={{ color: "var(--signal-deep)", fontWeight: 600 }}>
                전문 보기
              </Link>
            </span>
          </label>
        </div>

        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 12,
                      paddingTop: 12, borderTop: "1px solid var(--line)" }}>
          <div className="field" style={{ minWidth: 200 }}>
            <label className="label">세금계산서 담당자 (선택)</label>
            <input className="input" value={tax.manager} placeholder="예: 김행정"
              onChange={(e) => setTax({ ...tax, manager: e.target.value })} />
          </div>
          <div className="field" style={{ minWidth: 240 }}>
            <label className="label">세금계산서 받을 이메일 (선택)</label>
            <input className="input" type="email" value={tax.email} placeholder="office@school.kr"
              onChange={(e) => setTax({ ...tax, email: e.target.value })} />
          </div>
          <p className="label" style={{ color: "var(--steel-light)", alignSelf: "flex-end" }}>
            입력하시면 견적서에 표기되고, 입금 확인 후 이 주소로 세금계산서를 발행해 드립니다.
          </p>
        </div>
        {msg && <div className={`notice notice-${msg.type}`} style={{ marginTop: 12 }}>{msg.text}</div>}
        <p style={{ fontSize: 12.5, color: "var(--steel)", marginTop: 12, marginBottom: 0 }}>
          신청하면 관리자가 입금을 확인한 뒤 승인합니다. 승인 시점부터 기간이 시작되고,
          남은 기간이 있으면 이어붙습니다.
        </p>
      </div>

      {waiting && (
        <div className="panel" style={{ borderColor: "var(--signal)" }}>
          <h3>입금 안내</h3>
          <p style={{ fontSize: 13, color: "var(--steel)", marginTop: -4 }}>
            아래 계좌로 입금해 주세요. 입금이 확인되면 관리자가 플랜을 적용합니다.
          </p>
          <div style={{ display: "grid", gap: 8, marginTop: 8 }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <span className="label" style={{ width: 90 }}>입금 계좌</span>
              <b>{bank?.bank_name || "-"} {bank?.bank_account || "(관리자 미설정)"}</b>
              <span style={{ color: "var(--steel)" }}>예금주 {bank?.bank_holder || "-"}</span>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span className="label" style={{ width: 90 }}>입금 금액</span>
              <b style={{ fontSize: 16 }}>{waiting.amount.toLocaleString()}원</b>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span className="label" style={{ width: 90 }}>입금자명</span>
              <code style={{ fontSize: 17, fontWeight: 700, background: "var(--surface)",
                             padding: "4px 10px", borderRadius: 6, letterSpacing: 1 }}>
                {waiting.deposit_code}
              </code>
              <span style={{ fontSize: 12.5, color: "var(--alert)" }}>
                ← 이 코드를 입금자명에 꼭 포함해 주세요
              </span>
            </div>
            {waiting.due_at && (
              <div style={{ display: "flex", gap: 8 }}>
                <span className="label" style={{ width: 90 }}>입금 기한</span>
                <span>{waiting.due_at.slice(0, 10)}</span>
              </div>
            )}
          </div>
          {bank?.payment_note && (
            <p className="label" style={{ marginTop: 10, color: "var(--steel-light)" }}>{bank.payment_note}</p>
          )}
          <div style={{ display: "flex", gap: 6, marginTop: 12 }}>
            <button className="btn btn-primary btn-sm" onClick={() => openDoc(waiting.id, "quote")}>
              견적서 발행
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => openDoc(waiting.id, "contract")}>
              계약서
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => openDoc(waiting.id, "statement")}>
              거래명세서
            </button>
          </div>
        </div>
      )}

      <div className="panel">
        <h3>신청 내역</h3>
        {orders.length === 0 ? (
          <p style={{ fontSize: 13.5, color: "var(--steel)", margin: 0 }}>신청 내역이 없습니다.</p>
        ) : (
          <table className="table">
            <thead>
              <tr><th>신청일</th><th>플랜</th><th>입금 코드</th><th>금액</th><th>상태</th><th>문서</th></tr>
            </thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id}>
                  <td>{o.created_at.slice(0, 10)}</td>
                  <td>{PLAN_LABEL[o.plan]} · {o.months}개월</td>
                  <td style={{ fontFamily: "var(--font-mono)", fontWeight: 700 }}>{o.deposit_code || "-"}</td>
                  <td>{o.amount.toLocaleString()}원</td>
                  <td>
                    <span className={`badge ${o.status === "approved" ? "badge-dorm" : ""}`}>
                      {o.status_label || STATUS_LABEL[o.status]}
                    </span>
                    {o.status === "rejected" && o.note && (
                      <div style={{ fontSize: 11, color: "var(--alert)", marginTop: 3 }}>{o.note}</div>
                    )}
                  </td>
                  <td style={{ whiteSpace: "nowrap" }}>
                    <button className="btn btn-ghost btn-sm" onClick={() => openDoc(o.id, "quote")}>견적서</button>{" "}
                    <button className="btn btn-ghost btn-sm" onClick={() => openDoc(o.id, "contract")}>계약서</button>{" "}
                    <button className="btn btn-ghost btn-sm" onClick={() => openDoc(o.id, "statement")}>명세서</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default function SchoolAdmin() {
  const [tab, setTab] = useState("stats");
  const [profile, setProfile] = useState(null);
  const [stats, setStats] = useState(null);
  const [events, setEvents] = useState([]);
  const [orders, setOrders] = useState([]);
  const [plans, setPlans] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [teachers, setTeachers] = useState([]);

  const load = () => {
    api.myProfile().then(setProfile);
    api.myStats().then(setStats);
    api.myEvents().then(setEvents);
    api.myOrders().then(setOrders);
    api.meta().then((m) => setPlans(m.plans));
    api.myInquiries().then(setInquiries).catch(() => {});
    api.teachers().then(setTeachers).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  if (!profile || !stats) return <div className="wrap" style={{ padding: 60 }}><div className="empty"><p>불러오는 중…</p></div></div>;

  const unanswered = inquiries.filter((q) => q.status === "pending").length;

  return (
    <div className="wrap" style={{ padding: "34px 0 60px" }}>
      <span className="label">학교 관리</span>
      <h1 style={{ fontSize: 26, margin: "8px 0 4px" }}>{profile.name}</h1>
      <p style={{ color: "var(--steel)", fontSize: 14, marginTop: 0 }}>
        {profile.region} · {profile.category} · {profile.coed}
      </p>

      <div className="tabs" style={{ marginTop: 20 }}>
        <button className={`tab ${tab === "stats" ? "active" : ""}`} onClick={() => setTab("stats")}>통계</button>
        <button className={`tab ${tab === "profile" ? "active" : ""}`} onClick={() => setTab("profile")}>학교 정보</button>
        <button className={`tab ${tab === "inquiries" ? "active" : ""}`} onClick={() => setTab("inquiries")}>
          문의 관리{unanswered > 0 ? ` (${unanswered})` : ""}
        </button>
        <button className={`tab ${tab === "events" ? "active" : ""}`} onClick={() => setTab("events")}>입시 일정</button>
        <button className={`tab ${tab === "teachers" ? "active" : ""}`} onClick={() => setTab("teachers")}>선생님 계정 ({teachers.length})</button>
        <button className={`tab ${tab === "notices" ? "active" : ""}`} onClick={() => setTab("notices")}>선생님 공지</button>
        <button className={`tab ${tab === "plan" ? "active" : ""}`} onClick={() => setTab("plan")}>노출 플랜</button>
      </div>

      {tab === "stats" && <StatsTab stats={stats} />}
      {tab === "profile" && <ProfileTab profile={profile} reload={load} />}
      {tab === "inquiries" && <InquiriesTab inquiries={inquiries} reload={load} />}
      {tab === "events" && <EventsTab plan={profile.plan} events={events} reload={load} />}
      {tab === "teachers" && <TeachersTab teachers={teachers} reload={load} />}
      {tab === "notices" && <NoticeComposer mode="school" />}
      {tab === "plan" && <PlanTab profile={profile} plans={plans} orders={orders} reload={load} />}
    </div>
  );
}
