"""AI 작업을 뒤에서 처리하는 자리.

**왜 뒤로 미루나**

AI 는 몇 초에서 수십 초가 걸린다. 그동안 웹 요청을 붙들고 있으면
gunicorn 워커 하나가 통째로 묶인다. 워커가 두어 개인데 학생 셋이
동시에 누르면 남는 워커가 없고, 그 순간 자소서와 상관없는 다른 학생의
일지 저장까지 멈춘다. AI 기능 하나가 서비스 전체를 막는 셈이다.

그래서 요청을 표에 적어 두고 바로 응답한다. 화면은 몇 초마다
결과가 나왔는지 물어본다.

**Redis 나 Celery 를 쓰지 않는 이유**

지금 규모에는 과하다. 표 하나와 일꾼 실 하나면 된다. 나중에 사람이
늘면 이 파일만 바꿔 끼우면 되도록 갈라 두었다.

**워커가 여러 개일 때**

gunicorn 워커마다 일꾼이 하나씩 생긴다. 같은 일을 두 번 하지 않도록
작업을 집어갈 때 queued → running 으로 바꾸고, 바뀐 줄 수를 확인한다.
먼저 바꾼 쪽만 그 일을 한다.
"""

import json
import threading
import time
import traceback
from datetime import datetime, timedelta

from .database import SessionLocal
from .models import AiJob

# 일꾼이 얼마나 자주 표를 들여다볼지(초)
POLL_SECONDS = 2

# 이 시간이 지나도 안 끝난 작업은 죽은 것으로 본다(분).
# 서버가 중간에 재시작되면 running 인 채로 남는다.
STALE_MINUTES = 10

# 끝난 작업을 며칠 뒤에 치울지
KEEP_DAYS = 3

_worker = None
_stop = threading.Event()

# 작업 종류별로 실제 일을 하는 함수. main.py 가 등록한다.
# 여기서 main 을 부르면 서로 물고 물려 import 가 꼬인다.
_handlers = {}


def register(kind: str, fn) -> None:
    """작업 종류와 처리 함수를 이어 둔다."""
    _handlers[kind] = fn


def enqueue(db, user_id: int, kind: str, payload: dict, dedup_key: str = None) -> AiJob:
    """할 일을 적어 둔다. 바로 돌아온다.

    dedup_key를 주면, 같은 사람이 같은 요청(같은 kind+같은 대상)을
    연타해도 새로 만들지 않고 이미 기다리는/도는 중인 작업을 그대로
    돌려준다 — 버튼을 두 번 눌러 같은 AI 요청이 두 번 쌓이는 것을 막는다.
    """
    if dedup_key:
        existing = (db.query(AiJob)
                    .filter(AiJob.user_id == user_id, AiJob.kind == kind,
                            AiJob.dedup_key == dedup_key,
                            AiJob.status.in_(("queued", "running")))
                    .order_by(AiJob.created_at.desc()).first())
        if existing:
            return existing

    job = AiJob(
        user_id=user_id, kind=kind, status="queued", dedup_key=dedup_key,
        payload_json=json.dumps(payload, ensure_ascii=False),
    )
    db.add(job)
    db.commit()
    db.refresh(job)
    return job


def job_out(job: AiJob) -> dict:
    """화면에 내려줄 모양."""
    try:
        result = json.loads(job.result_json or "{}")
    except (ValueError, TypeError):
        result = {}
    return {
        "id": job.id,
        "kind": job.kind,
        "status": job.status,
        "result": result,
        "error": job.error or "",
        "created_at": job.created_at,
        "finished_at": job.finished_at,
    }


def _take_one(db):
    """기다리는 작업 하나를 집어 온다.

    워커가 여럿일 때 같은 작업을 두 번 하지 않도록, 상태를 바꾼
    줄 수를 확인한다. 먼저 바꾼 쪽만 가져간다.
    """
    job = (db.query(AiJob)
           .filter(AiJob.status == "queued")
           .order_by(AiJob.created_at).first())
    if job is None:
        return None

    changed = (db.query(AiJob)
               .filter(AiJob.id == job.id, AiJob.status == "queued")
               .update({"status": "running", "started_at": datetime.utcnow()},
                       synchronize_session=False))
    db.commit()
    if not changed:
        return None      # 다른 워커가 먼저 가져갔다
    db.refresh(job)
    return job


def _run_once() -> bool:
    """작업 하나를 처리한다. 처리했으면 True."""
    db = SessionLocal()
    try:
        job = _take_one(db)
        if job is None:
            return False

        handler = _handlers.get(job.kind)
        if handler is None:
            job.status = "failed"
            job.error = "처리할 수 없는 요청입니다."
            job.finished_at = datetime.utcnow()
            db.commit()
            return True

        try:
            payload = json.loads(job.payload_json or "{}")
        except (ValueError, TypeError):
            payload = {}

        try:
            result = handler(db, job.user_id, payload) or {}
            if result.get("ok"):
                job.status = "done"
                job.result_json = json.dumps(result, ensure_ascii=False,
                                             default=str)
            else:
                job.status = "failed"
                job.error = str(result.get("error") or "처리하지 못했습니다.")[:300]
        except Exception as exc:
            # 일꾼이 죽으면 다음 작업도 못 한다. 어떤 오류든 여기서 잡는다.
            # 오류 메시지에 글 내용이 섞일 수 있어 갈래만 로그에 남긴다.
            print(f"[AI작업] id={job.id} kind={job.kind} 실패: "
                  f"{type(exc).__name__}", flush=True)
            traceback.print_exc()
            job.status = "failed"
            job.error = "처리 중 문제가 생겼습니다. 다시 시도해주세요."

        job.finished_at = datetime.utcnow()
        db.commit()
        return True
    finally:
        db.close()


def _cleanup() -> None:
    """멈춰 있는 작업을 정리하고, 오래된 것을 치운다."""
    db = SessionLocal()
    try:
        now = datetime.utcnow()
        # 서버가 중간에 재시작되면 running 인 채로 남는다. 실패로 돌린다.
        db.query(AiJob).filter(
            AiJob.status == "running",
            AiJob.started_at < now - timedelta(minutes=STALE_MINUTES),
        ).update({"status": "failed",
                  "error": "처리가 중단되었습니다. 다시 시도해주세요.",
                  "finished_at": now}, synchronize_session=False)

        db.query(AiJob).filter(
            AiJob.created_at < now - timedelta(days=KEEP_DAYS)
        ).delete(synchronize_session=False)
        db.commit()
    except Exception as exc:
        db.rollback()
        print(f"[AI작업] 정리 실패: {type(exc).__name__}", flush=True)
    finally:
        db.close()


def _loop() -> None:
    last_cleanup = 0.0
    while not _stop.is_set():
        try:
            worked = _run_once()
        except Exception as exc:
            # 여기서 죽으면 일꾼이 사라진다. 무슨 일이 있어도 계속 돈다.
            print(f"[AI작업] 일꾼 오류: {type(exc).__name__}", flush=True)
            worked = False

        now = time.time()
        if now - last_cleanup > 300:
            _cleanup()
            last_cleanup = now

        if not worked:
            _stop.wait(POLL_SECONDS)


def start() -> None:
    """일꾼을 띄운다. 여러 번 불러도 하나만 돈다.

    daemon 으로 두어 서버를 내릴 때 붙잡지 않게 한다.
    """
    global _worker
    if _worker is not None and _worker.is_alive():
        return
    _stop.clear()
    _worker = threading.Thread(target=_loop, name="ai-jobs", daemon=True)
    _worker.start()
    print("[AI작업] 일꾼 시작", flush=True)


def stop() -> None:
    _stop.set()
