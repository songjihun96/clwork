import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 일지·자소서 전용 앱. 본 사이트와 같은 백엔드를 쓴다.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174,   // 본 사이트(5173)와 겹치지 않게
    proxy: {
      '/api': { target: 'http://localhost:8000', changeOrigin: true },
    },
  },
})
