import sys, os, json, time
sys.path.insert(0,".")
OK=[]
def chk(n,c,e=""):
    OK.append(bool(c)); print(("  OK  " if c else "  FAIL")+f"  {n}"+(f"  {e}" if not c and e else ""))

print("=== 1. 키가 없을 때 ===")
os.environ.pop("ANTHROPIC_API_KEY", None)
import importlib
from app import llm
importlib.reload(llm)
chk("쓸 수 없다고 알림", llm.available() is False)
st=llm.status()
chk("상태에 키 없음", st["available"] is False and st["model"]=="", str(st))
r=llm.generate("안녕")
chk("예외 대신 결과", r.ok is False and r.error_type=="no_key", r.error_type)
chk("화면 문구 있음", "준비" in r.error, r.error)

print("=== 2. JSON 꺼내기 ===")
os.environ["ANTHROPIC_API_KEY"]="test-key"
importlib.reload(llm)
cases=[
 ('{"a":1}', {"a":1}, "그냥 JSON"),
 ('```json\n{"a":2}\n```', {"a":2}, "코드블록"),
 ('설명입니다.\n{"a":3}\n끝.', {"a":3}, "앞뒤 군더더기"),
 ('아무 말', None, "JSON 아님"),
 ('[1,2]', None, "배열은 거부"),
]
for text, want, label in cases:
    chk(label, llm._extract_json(text)==want, repr(llm._extract_json(text)))

print("=== 3. 너무 긴 글 ===")
r=llm.generate("가"*20000)
chk("보내지 않고 거부", r.ok is False and r.error_type=="too_long")

print("=== 4. 서버가 실패해도 안 터진다 ===")
import requests
real=requests.post
class FakeRes:
    def __init__(self, code=200, body=None): self.status_code=code; self._b=body or {}
    def json(self): return self._b
def make(code=200, body=None, exc=None):
    def f(*a, **k):
        if exc: raise exc
        return FakeRes(code, body)
    return f

requests.post = make(exc=requests.Timeout())
r=llm.generate("x"); chk("타임아웃", r.ok is False and r.error_type=="timeout", r.error_type)
chk("친절한 안내", "다시" in r.error, r.error)

requests.post = make(code=401)
r=llm.generate("x"); chk("인증 실패", r.ok is False and r.error_type=="http_401")
chk("내부 사정 숨김", "401" not in r.error, r.error)

requests.post = make(code=529)
r=llm.generate("x"); chk("서버 과부하", r.ok is False and r.error_type=="http_529")

requests.post = make(exc=ConnectionError("no route"))
r=llm.generate("x"); chk("연결 실패", r.ok is False)
chk("에러 내용 안 새어나감", "no route" not in r.error, r.error)

requests.post = make(body={"content":[]})
r=llm.generate("x"); chk("빈 응답", r.ok is False and r.error_type=="empty")

print("=== 5. 정상 흐름 ===")
requests.post = make(body={"content":[{"type":"text","text":'{"draft":"안녕하세요"}'}],
                           "usage":{"input_tokens":10,"output_tokens":5}})
r=llm.generate_json("x")
chk("JSON 받음", r.ok and r.data=={"draft":"안녕하세요"}, str(r.data))
chk("토큰 기록", r.meta.get("in_tokens")==10, str(r.meta))

print("=== 6. 형식이 틀리면 한 번만 더 ===")
calls=[]
def bad(*a, **k):
    calls.append(1)
    return FakeRes(200, {"content":[{"type":"text","text":"JSON 아님"}]})
requests.post = bad
r=llm.generate_json("x", retry=1)
chk("실패로 끝남", r.ok is False and r.error_type=="bad_json")
chk("두 번만 부름", len(calls)==2, f"{len(calls)}번")

print("=== 7. 동시 실행 제한 ===")
requests.post = real
import threading
llm.MAX_CONCURRENT=1
llm._gate = threading.Semaphore(1)
slow_done=[]
def slow(*a, **k):
    time.sleep(0.4); slow_done.append(1)
    return FakeRes(200, {"content":[{"type":"text","text":"ok"}]})
requests.post = slow
t=threading.Thread(target=lambda: llm.generate("a")); t.start()
time.sleep(0.05)
s=time.time(); llm.generate("b"); waited=time.time()-s
t.join()
chk("뒤 요청이 기다림", waited>0.2, f"{waited:.2f}초")
requests.post = real
print(); print(f"===== {sum(OK)}/{len(OK)} 통과 =====")
sys.exit(0 if all(OK) else 1)
