import { useEffect, useState } from "react";
import {
  Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import NoticeComposer from "../components/NoticeComposer";
import { api, PLAN_LABEL, ROLE_LABEL } from "../api";

const PLAN_COLORS = { 무료: "#b6c0c8", 베이직: "#6ba3d6", 프리미엄: "#7b61c7", 플래티넘: "#ffc53d" };

function OrdersTab({ orders, reload }) {
  const [msg, setMsg] = useState(null);

  const approve = async (id) => {
    try {
      const r = await api.approveOrder(id);
      setMsg({ type: "ok", text: `승인 완료 — ${PLAN_LABEL[r.plan]} 플랜이 ${r.expires_at}까지 적용됩니다.` });
      reload();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    }
  };

  const reject = async (id) => {
    const reason = prompt("반려 사유를 적어주세요. 학교 담당자에게 그대로 보입니다.");
    if (reason === null) return;
    await api.rejectOrder(id, reason);
    reload();
  };

  const markPaid = async (id) => {
    try { await api.markOrderPaid(id); setMsg({ type: "ok", text: "입금 확인으로 표시했습니다." }); reload(); }
    catch (e) { setMsg({ type: "error", text: e.message }); }
  };

  const expire = async (id) => {
    if (!window.confirm("기한 내 미입금으로 만료 처리할까요?")) return;
    await api.expireOrder(id);
    reload();
  };

  const openDoc = async (id, kind) => {
    try { await api.openOrderDoc(id, kind, true); }
    catch (e) { setMsg({ type: "error", text: e.message }); }
  };

  // 입금 대기 + 입금 확인된 건이 처리 대상
  const pending = orders.filter((o) => o.status === "pending" || o.status === "paid");
  const isOverdue = (o) => o.status === "pending" && o.due_at && new Date(o.due_at) < new Date();

  return (
    <div style={{ display: "grid", gap: 16 }}>
      {msg && <div className={`notice notice-${msg.type}`}>{msg.text}</div>}

      <div className="panel">
        <h3>승인 대기 ({pending.length})</h3>
        {pending.length === 0 ? (
          <p style={{ fontSize: 13.5, color: "var(--steel)", margin: 0 }}>처리할 신청이 없습니다.</p>
        ) : (
          <table className="table">
            <thead>
              <tr><th>신청일</th><th>학교</th><th>플랜</th><th>입금 코드</th><th>금액</th><th>기한</th><th>상태</th><th></th></tr>
            </thead>
            <tbody>
              {pending.map((o) => (
                <tr key={o.id}>
                  <td>{o.created_at.slice(0, 10)}</td>
                  <td style={{ fontWeight: 600 }}>{o.school_name}</td>
                  <td>{PLAN_LABEL[o.plan]} · {o.months}개월</td>
                  <td style={{ fontFamily: "var(--font-mono)", fontWeight: 700 }}>{o.deposit_code}</td>
                  <td style={{ fontFamily: "var(--font-mono)" }}>{o.amount.toLocaleString()}원</td>
                  <td style={{ color: isOverdue(o) ? "var(--alert)" : undefined, fontSize: 12.5 }}>
                    {o.due_at ? o.due_at.slice(0, 10) : "-"}{isOverdue(o) ? " (초과)" : ""}
                  </td>
                  <td>
                    <span className={`badge ${o.status === "paid" ? "badge-dorm" : ""}`}>{o.status_label}</span>
                  </td>
                  <td style={{ textAlign: "right", whiteSpace: "nowrap" }}>
                    {o.status === "pending" && (
                      <><button className="btn btn-ghost btn-sm" onClick={() => markPaid(o.id)}>입금 확인</button>{" "}</>
                    )}
                    <button className="btn btn-signal btn-sm" onClick={() => approve(o.id)}>승인</button>{" "}
                    <button className="btn btn-ghost btn-sm" onClick={() => openDoc(o.id, "quote")}>견적서</button>{" "}
                    <button className="btn btn-ghost btn-sm" onClick={() => openDoc(o.id, "contract")}>계약서</button>{" "}
                    <button className="btn btn-ghost btn-sm" onClick={() => reject(o.id)}>반려</button>{" "}
                    <button className="btn btn-ghost btn-sm" onClick={() => expire(o.id)}>만료</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="panel">
        <h3>전체 신청 내역</h3>
        <table className="table">
          <thead>
            <tr><th>신청일</th><th>학교</th><th>플랜</th><th>금액</th><th>상태</th></tr>
          </thead>
          <tbody>
            {orders.map((o) => (
              <tr key={o.id}>
                <td>{o.created_at.slice(0, 10)}</td>
                <td>{o.school_name}</td>
                <td>{PLAN_LABEL[o.plan]} · {o.months}개월</td>
                <td style={{ fontFamily: "var(--font-mono)" }}>{o.amount.toLocaleString()}원</td>
                <td>
                  <span className={`badge ${o.status === "approved" ? "badge-dorm" : ""}`}>
                    {o.status_label}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function FloatingButtonPanel() {
  const [form, setForm] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.adminFloatingButton().then(setForm).catch(() => {}); }, []);
  if (!form) return null;

  const save = async (patch = {}) => {
    setBusy(true); setMsg(null);
    const next = { ...form, ...patch };
    try {
      const d = await api.saveFloatingButton(next);
      setForm(d);
      setMsg({ type: "ok", text: d.enabled ? "버튼을 켰습니다." : "설정을 저장했습니다." });
    } catch (e) {
      setMsg({ type: "error", text: e.message });
      api.adminFloatingButton().then(setForm).catch(() => {});
    } finally { setBusy(false); }
  };

  const toggleRole = (role, on) => {
    const roles = on
      ? [...new Set([...(form.roles || []), role])]
      : (form.roles || []).filter((r) => r !== role);
    setForm({ ...form, roles });
  };

  const ROLES = [["school", "학교 계정"], ["teacher", "선생님"], ["student", "학생"]];

  return (
    <div className="panel">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
        <h3 style={{ margin: 0 }}>바로가기 버튼 (오른쪽 아래)</h3>
        <label className="toggle-switch">
          <input type="checkbox" checked={form.enabled}
            onChange={(e) => save({ enabled: e.target.checked })} />
          <span className="toggle-track"><span className="toggle-thumb" /></span>
        </label>
      </div>
      <p style={{ fontSize: 13, color: "var(--steel)", margin: "6px 0 12px", lineHeight: 1.6 }}>
        켜면 화면 오른쪽 아래에 동그란 버튼이 뜨고, 누르면 등록한 주소가 <b>새 탭</b>으로 열립니다.
      </p>

      {msg && <div className={`notice notice-${msg.type}`} style={{ marginBottom: 12 }}>{msg.text}</div>}

      <div style={{ display: "grid", gap: 12, maxWidth: 480 }}>
        <div className="field">
          <label className="label">연결할 주소</label>
          <input className="input" value={form.url} placeholder="https://example.com"
            onChange={(e) => setForm({ ...form, url: e.target.value })} />
          <span className="label" style={{ color: "var(--steel-light)" }}>
            http:// 또는 https:// 로 시작해야 합니다.
          </span>
        </div>
        <div className="field">
          <label className="label">버튼 문구</label>
          <input className="input" value={form.label} maxLength={30} placeholder="예: 문의하기"
            onChange={(e) => setForm({ ...form, label: e.target.value })} />
        </div>
        <div className="field">
          <label className="label">누구에게 보일지</label>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginTop: 4 }}>
            {ROLES.map(([key, label]) => (
              <label key={key} style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13.5 }}>
                <input type="checkbox" checked={(form.roles || []).includes(key)}
                  onChange={(e) => toggleRole(key, e.target.checked)} />
                {label}
              </label>
            ))}
          </div>
        </div>
        <div>
          <button className="btn btn-primary btn-sm" onClick={() => save()} disabled={busy}>
            {busy ? "저장 중…" : "저장"}
          </button>
        </div>
      </div>
    </div>
  );
}

function BankInfoPanel() {
  const [form, setForm] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api.adminBankInfo().then(setForm).catch(() => {}); }, []);
  if (!form) return null;

  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      await api.saveBankInfo(form);
      setMsg({ type: "ok", text: "입금 계좌 정보를 저장했습니다. 견적서와 학교 안내에 바로 반영됩니다." });
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally { setBusy(false); }
  };

  const f = (k, label, ph = "") => (
    <div className="field">
      <label className="label">{label}</label>
      <input className="input" value={form[k] ?? ""} placeholder={ph}
        onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
    </div>
  );

  return (
    <div className="panel">
      <h3>입금 계좌 설정</h3>
      <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 12px", lineHeight: 1.6 }}>
        학교에 안내되는 입금 계좌입니다. 견적서·거래명세서와 학교 화면에 그대로 표시됩니다.
      </p>
      {msg && <div className={`notice notice-${msg.type}`} style={{ marginBottom: 12 }}>{msg.text}</div>}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 12 }}>
        {f("bank_name", "은행명", "예: 농협")}
        {f("bank_account", "계좌번호", "예: 301-1234-5678-91")}
        {f("bank_holder", "예금주", "특성화고신문")}
        {f("due_days", "입금 기한(일)", "14")}
      </div>
      <div className="field" style={{ marginTop: 12 }}>
        <label className="label">안내 문구</label>
        <textarea className="textarea" rows={2} value={form.payment_note ?? ""}
          onChange={(e) => setForm({ ...form, payment_note: e.target.value })} />
      </div>
      <button className="btn btn-primary btn-sm" onClick={save} disabled={busy} style={{ marginTop: 10 }}>
        {busy ? "저장 중…" : "저장"}
      </button>
    </div>
  );
}

function PlanManageTab() {
  const [prices, setPrices] = useState([]);
  const [edited, setEdited] = useState({});
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const [perkKeys, setPerkKeys] = useState({});   // { plan: [key, ...] }
  const [catalog, setCatalog] = useState([]);

  const load = () => api.adminPlanPrices().then((d) => {
    setPrices(d);
    setEdited(Object.fromEntries(d.map((p) => [p.plan, p.price_per_month])));
    setPerkKeys(Object.fromEntries(d.map((p) => [p.plan, p.perk_keys || []])));
  }).catch(() => {});

  const [baseFeatures, setBaseFeatures] = useState([]);
  useEffect(() => {
    api.perkCatalog().then((d) => {
      setCatalog(d.perks || []);
      setBaseFeatures(d.base_features || []);
    }).catch(() => {});
  }, []);
  useEffect(() => { load(); }, []);

  const save = async (plan) => {
    const price = Number(edited[plan]);
    if (!Number.isFinite(price) || price < 0) {
      return setMsg({ type: "error", text: "0 이상의 숫자를 입력하세요." });
    }
    setBusy(true); setMsg(null);
    try {
      await api.setPlanPrice(plan, price);
      setMsg({ type: "ok", text: "가격을 저장했습니다." });
      load();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  // 토글하면 바로 저장한다
  const togglePerk = async (plan, key, on) => {
    const cur = perkKeys[plan] || [];
    const next = on ? [...new Set([...cur, key])] : cur.filter((k) => k !== key);
    setPerkKeys({ ...perkKeys, [plan]: next });   // 화면 먼저 반영
    try {
      await api.setPlanPerks(plan, next);
      setMsg(null);
    } catch (e) {
      setMsg({ type: "error", text: e.message });
      load();  // 실패하면 서버 값으로 되돌린다
    }
  };

  const resetPerks = async (plan, label) => {
    if (!window.confirm(`${label} 혜택을 기본값으로 되돌릴까요?`)) return;
    setBusy(true);
    try { await api.resetPlanPerks(plan); load(); }
    finally { setBusy(false); }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
    <BankInfoPanel />
    <div className="panel">
      <h3>플랜 가격 설정</h3>
      <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 14px", lineHeight: 1.6 }}>
        학교가 신청하는 플랜의 월 가격입니다. 바꾸면 플랜 안내와 결제 금액에 바로 반영됩니다.
      </p>
      {msg && <div className={`notice notice-${msg.type}`} style={{ marginBottom: 12 }}>{msg.text}</div>}
      <div style={{ display: "grid", gap: 10 }}>
        {prices.filter((p) => p.plan !== "free").map((p) => (
          <div key={p.plan} style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ width: 90, fontWeight: 600 }}>{p.label}</span>
            <input
              className="input"
              type="number"
              min="0"
              step="1000"
              value={edited[p.plan] ?? ""}
              onChange={(e) => setEdited({ ...edited, [p.plan]: e.target.value })}
              style={{ maxWidth: 180 }}
            />
            <span style={{ color: "var(--steel)" }}>원 / 월</span>
            <button className="btn btn-ghost btn-sm" onClick={() => save(p.plan)} disabled={busy}>
              저장
            </button>
          </div>
        ))}
      </div>
    </div>

    <div className="panel">
      <h3>플랜 혜택 설정</h3>
      <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 12px", lineHeight: 1.6 }}>
        플랜별로 제공할 <b>유료 혜택</b>을 켜고 끄세요. <b>토글을 바꾸면 바로 저장</b>되고,
        학교가 보는 화면과 실제 기능에 즉시 반영됩니다.
      </p>
      <div className="notice notice-info" style={{ marginBottom: 14 }}>
        <b>모든 플랜 기본 제공(토글 대상 아님)</b> —{" "}
        {baseFeatures.map((f) => f.label).join(" · ")}
      </div>
      <div style={{ display: "grid", gap: 18 }}>
        {prices.map((pl) => (
          <div key={pl.plan} style={{ border: "1px solid var(--line)", borderRadius: "var(--radius)", padding: "12px 14px" }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 10 }}>
              <span style={{ fontWeight: 700 }}>
                {pl.label}
                <span className="label" style={{ color: "var(--steel-light)", marginLeft: 8 }}>
                  {(perkKeys[pl.plan] || []).length}개 제공
                </span>
              </span>
              <button className="btn btn-ghost btn-sm" onClick={() => resetPerks(pl.plan, pl.label)} disabled={busy}>
                기본값으로
              </button>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 4 }}>
              {catalog.map((item) => {
                const on = (perkKeys[pl.plan] || []).includes(item.key);
                return (
                  <div key={item.key}
                    style={{ display: "flex", alignItems: "center", justifyContent: "space-between",
                             gap: 8, padding: "5px 8px", borderRadius: 8,
                             background: on ? "var(--surface)" : "transparent" }}>
                    <span style={{ fontSize: 13.5, color: on ? "var(--ink)" : "var(--steel-light)" }}>
                      {item.label}
                    </span>
                    <label className="toggle-switch">
                      <input
                        type="checkbox"
                        checked={on}
                        onChange={(e) => togglePerk(pl.plan, item.key, e.target.checked)}
                      />
                      <span className="toggle-track"><span className="toggle-thumb" /></span>
                    </label>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
    </div>
  );
}

function ArticleManageTab() {
  const [articles, setArticles] = useState([]);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ url: "", title: "", summary: "", thumbnail: "", school_id: "" });

  const load = () => api.articles(30).then(setArticles).catch(() => {});
  useEffect(() => { load(); }, []);

  const runCrawl = async () => {
    setBusy(true); setMsg(null);
    try {
      const r = await api.crawlArticles();
      if (r.ok) {
        setMsg({ type: "ok", text: `수집 완료 — 스캔 ${r.scanned}건, 신규 ${r.added}건, 학교매칭 ${r.matched}건` });
        load();
      } else {
        setMsg({ type: "error", text: `수집 실패: ${r.error || "서버에서 특성화고신문 접근이 막혔을 수 있습니다."}` });
      }
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const runRematch = async () => {
    setBusy(true); setMsg(null);
    try {
      const r = await api.rematchArticles();
      if (r.ok) {
        setMsg({ type: "ok", text: `재매칭 완료 — ${r.updated}건 갱신, 총 ${r.total_matched}건 학교 연결됨` });
        load();
      } else {
        setMsg({ type: "error", text: `재매칭 실패: ${r.error}` });
      }
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const runDedupe = async () => {
    if (!confirm("제목이 같은 중복 기사를 정리합니다. 계속할까요?")) return;
    setBusy(true); setMsg(null);
    try {
      const r = await api.dedupeArticles();
      if (r.ok) {
        setMsg({ type: "ok", text: `중복 제거 완료 — ${r.removed}건 삭제` });
        load();
      } else {
        setMsg({ type: "error", text: `중복 제거 실패: ${r.error}` });
      }
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const addManual = async () => {
    if (!form.url.trim() || !form.title.trim()) {
      return setMsg({ type: "error", text: "원문 링크와 제목은 필수입니다." });
    }
    setBusy(true); setMsg(null);
    try {
      const body = { ...form, school_id: form.school_id ? Number(form.school_id) : null };
      await api.addManualArticle(body);
      setMsg({ type: "ok", text: "기사를 등록했습니다." });
      setForm({ url: "", title: "", summary: "", thumbnail: "", school_id: "" });
      load();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id) => {
    if (!confirm("이 기사를 삭제할까요?")) return;
    try {
      await api.deleteArticle(id);
      load();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="panel">
        <h3>기사 자동 수집</h3>
        <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 12px", lineHeight: 1.6 }}>
          특성화고신문에서 기사를 가져와 제목의 학교명과 자동 연결합니다.
          평소에는 6시간마다 자동 수집되며, 아래 버튼으로 지금 즉시 수집할 수도 있습니다.
        </p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button className="btn btn-signal btn-sm" onClick={runCrawl} disabled={busy}>
            {busy ? "처리 중…" : "지금 수집하기"}
          </button>
          <button className="btn btn-ghost btn-sm" onClick={runRematch} disabled={busy}>
            학교 재매칭
          </button>
          <button className="btn btn-ghost btn-sm" onClick={runDedupe} disabled={busy}>
            중복 정리
          </button>
        </div>
        <p style={{ fontSize: 12, color: "var(--steel-light)", margin: "10px 0 0", lineHeight: 1.5 }}>
          · 학교 재매칭: 줄임말·개명된 학교명을 다시 연결합니다<br />
          · 중복 정리: 제목이 같은 중복 기사를 하나만 남깁니다
        </p>
      </div>

      <div className="panel">
        <h3>기사 직접 등록</h3>
        <div style={{ display: "grid", gap: 8 }}>
          <input className="input" placeholder="원문 링크 (필수)" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
          <input className="input" placeholder="제목 (필수)" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className="input" placeholder="요약 (선택)" value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} />
          <input className="input" placeholder="썸네일 이미지 주소 (선택)" value={form.thumbnail} onChange={(e) => setForm({ ...form, thumbnail: e.target.value })} />
          <input className="input" placeholder="연결할 학교 ID (선택, 비우면 제목으로 매칭)" value={form.school_id} onChange={(e) => setForm({ ...form, school_id: e.target.value })} />
          <button className="btn btn-ghost btn-sm" onClick={addManual} disabled={busy} style={{ justifySelf: "start" }}>
            기사 등록
          </button>
        </div>
      </div>

      {msg && <div className={`notice notice-${msg.type}`}>{msg.text}</div>}

      <div className="panel">
        <h3>등록된 기사 ({articles.length})</h3>
        {articles.length === 0 ? (
          <div className="empty"><p>아직 수집된 기사가 없습니다.</p></div>
        ) : (
          <div style={{ display: "grid", gap: 8 }}>
            {articles.map((a) => (
              <div key={a.id} style={{ display: "flex", gap: 10, alignItems: "center", padding: "8px 0", borderBottom: "1px solid var(--line)", minWidth: 0 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  {/* 모바일에서는 말줄임보다 줄바꿈이 낫다. 한글 제목은 잘리면 알아볼 수 없다. */}
                  <div style={{ fontSize: 13.5, fontWeight: 600, overflowWrap: "anywhere" }}>{a.title}</div>
                  <div style={{ fontSize: 12, color: "var(--steel-light)", overflowWrap: "anywhere" }}>
                    {a.school_name ? `🏫 ${a.school_name}` : "미연결"} · {a.source === "manual" ? "직접등록" : "자동수집"}
                    {a.published_at ? ` · ${a.published_at}` : ""}
                  </div>
                </div>
                <button className="btn btn-ghost btn-sm" onClick={() => remove(a.id)} style={{ flexShrink: 0 }}>삭제</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function SchoolManageTab() {
  const [search, setSearch] = useState("");
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [detail, setDetail] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const [categories, setCategories] = useState([]);
  const [catMsg, setCatMsg] = useState(null);
  const [deptFilter, setDeptFilter] = useState(null);   // 학과 계열 필터 설정
  const [deptMsg, setDeptMsg] = useState(null);
  const [deptBusy, setDeptBusy] = useState(false);

  const loadCategories = () => api.categoryVisibility().then(setCategories).catch(() => {});
  const loadDeptFilter = () => api.deptFieldFilter().then(setDeptFilter).catch(() => {});
  useEffect(() => {
    loadCategories();
    loadDeptFilter();
  }, []);

  const toggleDeptFilter = async (enabled) => {
    setDeptMsg(null);
    try {
      await api.setDeptFieldFilter(enabled);
      await loadDeptFilter();
    } catch (e) {
      setDeptMsg({ type: "error", text: e.message });
    }
  };

  const rebuildDeptFields = async () => {
    setDeptBusy(true);
    setDeptMsg(null);
    try {
      const r = await api.rebuildDeptFields();
      await loadDeptFilter();
      setDeptMsg({ type: "ok", text: `${r.changed}개 학교의 계열을 다시 매겼습니다.` });
    } catch (e) {
      setDeptMsg({ type: "error", text: e.message });
    } finally {
      setDeptBusy(false);
    }
  };

  const toggleCategory = async (category, visible) => {
    setCatMsg(null);
    // 낙관적 업데이트: 화면을 먼저 바꾸고 서버에 반영
    setCategories((prev) =>
      prev.map((c) =>
        c.category === category
          ? { ...c, visible, shown: visible ? c.count : 0, hidden: visible ? 0 : c.count }
          : c
      )
    );
    try {
      await api.toggleCategoryVisibility(category, visible);
      await loadCategories();
    } catch (e) {
      setCatMsg({ type: "error", text: e.message });
      loadCategories();
    }
  };

  const doSearch = async () => {
    const r = await api.schools({ name: search, size: 10, include_hidden: true });
    setResults(r.items);
  };

  const pick = async (school) => {
    setSelected(school);
    setMsg(null);
    const d = await api.school(school.id);
    setDetail(d);
  };

  const refresh = async () => {
    if (selected) {
      const d = await api.school(selected.id);
      setDetail(d);
    }
  };

  const resetProfile = async () => {
    if (!confirm(`'${selected.name}'의 상세정보(소개·학과·시설·취업률·기숙사·입시일정)를 모두 비웁니다.\n\n기본정보(이름·주소·전화·좌표)와 플랜은 유지됩니다. 계속할까요?`)) return;
    setBusy(true);
    setMsg(null);
    try {
      await api.resetSchoolProfile(selected.id);
      setMsg({ type: "ok", text: "상세정보를 초기화했습니다." });
      await refresh();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const resetPlan = async () => {
    if (!confirm(`'${selected.name}'의 플랜을 무료로 되돌리고 플랜신청 내역을 지웁니다. 계속할까요?`)) return;
    setBusy(true);
    setMsg(null);
    try {
      await api.resetSchoolPlan(selected.id);
      setMsg({ type: "ok", text: "플랜을 무료로 초기화했습니다." });
      await refresh();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const toggleVisible = async () => {
    setBusy(true); setMsg(null);
    try {
      const next = !detail.is_visible;
      await api.toggleSchoolVisibility(selected.id, next);
      setMsg({ type: "ok", text: next ? "이제 사용자에게 보입니다." : "사용자에게서 숨겼습니다." });
      await refresh();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const togglePause = async () => {
    setBusy(true); setMsg(null);
    try {
      const next = !detail.plan_paused;
      await api.pausePlan(selected.id, next);
      setMsg({ type: "ok", text: next ? "플랜을 일시정지했습니다." : "플랜 정지를 해제했습니다." });
      await refresh();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="panel">
        <h3>학과 계열 필터</h3>
        <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 12px", lineHeight: 1.6 }}>
          학과명을 IT·디자인·조리 같은 계열로 자동 분류해, 검색 화면에 &lsquo;학과 계열&rsquo; 필터를
          띄웁니다. 끄면 필터가 사라집니다.
        </p>
        {deptMsg && <div className={`notice notice-${deptMsg.type}`} style={{ marginBottom: 12 }}>{deptMsg.text}</div>}
        {deptFilter && (
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderTop: "1px solid var(--line)" }}>
              <span style={{ flex: 1, minWidth: 0 }}>
                <b>검색에 학과 계열 필터 표시</b>
                <span className="label" style={{ display: "block", color: "var(--steel-light)", marginTop: 2 }}>
                  전체 {deptFilter.total}개 중 {deptFilter.tagged}개 학교에 계열이 매겨져 있습니다.
                </span>
              </span>
              <label className="toggle-switch" style={{ flexShrink: 0 }}>
                <input
                  type="checkbox"
                  checked={deptFilter.enabled}
                  onChange={(e) => toggleDeptFilter(e.target.checked)}
                />
                <span className="toggle-track"><span className="toggle-thumb" /></span>
              </label>
            </div>

            {deptFilter.fields.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
                {deptFilter.fields.map((f) => (
                  <span key={f.key} className="badge">{f.label}</span>
                ))}
              </div>
            )}

            <button
              className="btn btn-sm btn-ghost"
              style={{ marginTop: 12 }}
              disabled={deptBusy}
              onClick={rebuildDeptFields}
            >
              {deptBusy ? "다시 매기는 중…" : "계열 다시 매기기"}
            </button>
            <span className="label" style={{ display: "block", color: "var(--steel-light)", marginTop: 6 }}>
              학과 정보를 새로 수집했거나 분류가 어긋날 때 누르세요.
            </span>
          </>
        )}
      </div>

      <div className="panel">
        <h3>계열별 노출 일괄 설정</h3>
        <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 12px", lineHeight: 1.6 }}>
          계열 전체를 한 번에 켜고 끌 수 있습니다. 스위치를 끄면 그 계열 학교가 사용자 검색에서 사라집니다.
        </p>
        {catMsg && <div className={`notice notice-${catMsg.type}`} style={{ marginBottom: 12 }}>{catMsg.text}</div>}
        <div style={{ display: "grid", gap: 4 }}>
          {categories.map((c) => (
            <div
              key={c.category}
              style={{
                display: "flex", alignItems: "center", gap: 12,
                padding: "10px 4px", borderBottom: "1px solid var(--line)",
              }}
            >
              <span style={{ flex: 1, fontWeight: 500 }}>
                {c.category}
                <span style={{ color: "var(--steel-light)", fontSize: 12.5, marginLeft: 6 }}>
                  {c.visible
                    ? `${c.count}개 노출 중`
                    : c.hidden === c.count
                    ? `${c.count}개 전체 숨김`
                    : `${c.shown}개 노출 · ${c.hidden}개 숨김`}
                </span>
              </span>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={c.visible}
                  onChange={(e) => toggleCategory(c.category, e.target.checked)}
                />
                <span className="toggle-track"><span className="toggle-thumb" /></span>
              </label>
            </div>
          ))}
        </div>
      </div>

      <div className="panel">
        <h3>학교 찾기</h3>
        <div style={{ display: "flex", gap: 6 }}>
          <input
            className="input"
            placeholder="학교 이름 일부를 입력"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && doSearch()}
          />
          <button className="btn btn-ghost" onClick={doSearch}>검색</button>
        </div>
        {results.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 12 }}>
            {results.map((s) => (
              <button
                key={s.id}
                className="badge"
                style={{
                  cursor: "pointer",
                  background: selected?.id === s.id ? "var(--signal-deep)" : "var(--paper)",
                  color: selected?.id === s.id ? "#fff" : "var(--steel)",
                }}
                onClick={() => pick(s)}
              >
                {s.name} · {s.region}
              </button>
            ))}
          </div>
        )}
      </div>

      {detail && (
        <div className="panel">
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12, flexWrap: "wrap" }}>
            <h3 style={{ border: "none", padding: 0, margin: 0 }}>{detail.name}</h3>
            <span className="badge badge-cat">{detail.category}</span>
            <span className="badge">{PLAN_LABEL[detail.plan]}</span>
            {detail.is_visible === false && (
              <span className="badge" style={{ background: "var(--steel)", color: "#fff" }}>숨김</span>
            )}
            {detail.plan_paused && (
              <span className="badge" style={{ background: "var(--alert)", color: "#fff" }}>플랜 정지</span>
            )}
          </div>

          {msg && <div className={`notice notice-${msg.type}`} style={{ marginBottom: 14 }}>{msg.text}</div>}

          <div className="kv-grid" style={{ marginBottom: 18 }}>
            <div><span className="label">소개</span><dd>{detail.slogan || "—"}</dd></div>
            <div><span className="label">학과</span><dd>{detail.departments.length ? `${detail.departments.length}개` : "—"}</dd></div>
            <div><span className="label">취업률</span><dd>{detail.employment_rate != null ? `${detail.employment_rate}%` : "—"}</dd></div>
            <div><span className="label">기숙사</span><dd>{detail.dormitory === true ? "있음" : detail.dormitory === false ? "없음" : "미확인"}</dd></div>
            <div><span className="label">입시일정</span><dd>{detail.events.length}개</dd></div>
            <div><span className="label">현재 플랜</span><dd>{PLAN_LABEL[detail.plan]}</dd></div>
          </div>

          <div style={{ display: "grid", gap: 12 }}>
            <div style={{ border: "1px solid var(--line)", borderRadius: "var(--radius)", padding: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>사용자 노출</div>
                  <p style={{ fontSize: 12.5, color: "var(--steel)", margin: 0, lineHeight: 1.5 }}>
                    {detail.is_visible === false
                      ? "지금 이 학교는 사용자 검색에 나오지 않습니다."
                      : "이 학교는 사용자 검색에 노출되고 있습니다."}
                  </p>
                </div>
                <label className="toggle-switch">
                  <input
                    type="checkbox"
                    checked={detail.is_visible !== false}
                    onChange={toggleVisible}
                    disabled={busy}
                  />
                  <span className="toggle-track"><span className="toggle-thumb" /></span>
                </label>
              </div>
            </div>

            <div style={{ border: "1px solid var(--line)", borderRadius: "var(--radius)", padding: 14 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>플랜 일시정지</div>
                  <p style={{ fontSize: 12.5, color: "var(--steel)", margin: 0, lineHeight: 1.5 }}>
                    켜면 플랜 등급은 유지한 채 유료 혜택(색상 강조·기사 우선 노출)만 멈춥니다.
                    {detail.plan === "free" && " 무료 플랜은 해당 없음."}
                  </p>
                </div>
                <label className="toggle-switch">
                  <input
                    type="checkbox"
                    checked={!!detail.plan_paused}
                    onChange={togglePause}
                    disabled={busy || detail.plan === "free"}
                  />
                  <span className="toggle-track"><span className="toggle-thumb" /></span>
                </label>
              </div>
            </div>

            <div style={{ border: "1px solid var(--line)", borderRadius: "var(--radius)", padding: 14 }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>상세정보 초기화</div>
              <p style={{ fontSize: 12.5, color: "var(--steel)", margin: "0 0 10px", lineHeight: 1.5 }}>
                학교가 채운 소개·학과·시설·취업률·학생수·기숙사 여부·입시일정을 비웁니다.
                기본정보(이름·주소·전화·좌표)와 플랜은 그대로 둡니다.
              </p>
              <button className="btn btn-ghost btn-sm" onClick={resetProfile} disabled={busy}>
                상세정보 초기화
              </button>
            </div>

            <div style={{ border: "1px solid var(--line)", borderRadius: "var(--radius)", padding: 14 }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 4 }}>플랜 초기화</div>
              <p style={{ fontSize: 12.5, color: "var(--steel)", margin: "0 0 10px", lineHeight: 1.5 }}>
                이 학교를 무료 플랜으로 되돌리고 만료일·플랜신청 내역을 지웁니다.
                상세정보는 건드리지 않습니다.
              </p>
              <button className="btn btn-ghost btn-sm" onClick={resetPlan} disabled={busy || detail.plan === "free"}>
                {detail.plan === "free" ? "이미 무료 플랜" : "플랜 초기화"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AccountsTab({ users, reload }) {
  const [form, setForm] = useState({ email: "", password: "", name: "", school_id: "" });
  const [search, setSearch] = useState("");
  const [found, setFound] = useState([]);
  const [picked, setPicked] = useState(null);
  const [msg, setMsg] = useState(null);

  // 계정 검색(개인정보 보호: 검색해야만 학생·학교 계정이 보인다)
  const [acctQuery, setAcctQuery] = useState("");
  const [acctResults, setAcctResults] = useState(users);
  const [searched, setSearched] = useState(false);

  // users prop(관리자 계정만)이 바뀌면 기본 목록으로 반영
  useEffect(() => {
    if (!searched) setAcctResults(users);
  }, [users, searched]);

  const searchAccounts = async () => {
    const query = acctQuery.trim();
    if (!query) {
      setSearched(false);
      setAcctResults(users);
      return;
    }
    try {
      const r = await api.adminUsers({ q: query });
      setAcctResults(r);
      setSearched(true);
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    }
  };

  const doSearch = async () => {
    const r = await api.schools({ name: search, size: 8, include_hidden: true });
    setFound(r.items);
  };

  const create = async () => {
    setMsg(null);
    try {
      await api.createSchoolAccount({ ...form, school_id: Number(form.school_id) });
      setMsg({
        type: "ok",
        text: `${picked.name} 계정을 만들었습니다. 아이디와 비밀번호를 학교 담당자에게 전달하세요.`,
      });
      setForm({ email: "", password: "", name: "", school_id: "" });
      setPicked(null);
      setFound([]);
      setSearch("");
      reload();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div className="panel">
        <h3>학교 계정 만들기</h3>
        <div className="notice notice-info" style={{ marginBottom: 14 }}>
          학교 계정은 여기서만 만들 수 있습니다. 학교를 먼저 찾아 연결한 뒤 계정 정보를 입력하세요.
        </div>

        <div style={{ display: "grid", gap: 12 }}>
          <div className="field">
            <label className="label">1. 학교 찾기</label>
            <div style={{ display: "flex", gap: 6 }}>
              <input
                className="input" value={search} placeholder="학교 이름 일부를 입력"
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && doSearch()}
              />
              <button className="btn btn-ghost" onClick={doSearch}>검색</button>
            </div>
          </div>

          {found.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {found.map((s) => (
                <button
                  key={s.id}
                  className="badge"
                  style={{
                    cursor: "pointer",
                    background: picked?.id === s.id ? "var(--signal-deep)" : "var(--paper)",
                    color: picked?.id === s.id ? "#fff" : "var(--steel)",
                  }}
                  onClick={() => {
                    setPicked(s);
                    setForm({ ...form, school_id: s.id });
                  }}
                >
                  {s.name} · {s.region}
                </button>
              ))}
            </div>
          )}

          {picked && (
            <>
              <div className="notice notice-ok">선택된 학교: {picked.name} ({picked.address})</div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                <div className="field">
                  <label className="label">2. 담당자 이름</label>
                  <input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="field">
                  <label className="label">3. 로그인 이메일</label>
                  <input className="input" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </div>
                <div className="field">
                  <label className="label">4. 임시 비밀번호</label>
                  <input className="input" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
                </div>
              </div>
              <div>
                <button className="btn btn-signal" onClick={create}
                  disabled={!form.email || !form.password || !form.name}>
                  계정 만들기
                </button>
              </div>
            </>
          )}
          {msg && <div className={`notice notice-${msg.type}`}>{msg.text}</div>}
        </div>
      </div>

      <div className="panel">
        <h3>계정 찾기</h3>
        <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 12px", lineHeight: 1.6 }}>
          개인정보 보호를 위해 학생·학교 계정은 검색해야 표시됩니다.
          이름·이메일·연락처로 찾으세요.
        </p>
        <div style={{ display: "flex", gap: 6 }}>
          <input
            className="input"
            placeholder="이름, 이메일, 또는 연락처"
            value={acctQuery}
            onChange={(e) => setAcctQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && searchAccounts()}
          />
          <button className="btn btn-ghost btn-sm" onClick={searchAccounts}>검색</button>
          {searched && (
            <button className="btn btn-ghost btn-sm" onClick={() => { setAcctQuery(""); setSearched(false); setAcctResults(users); }}>
              초기화
            </button>
          )}
        </div>
      </div>

      <div className="panel">
        <h3>
          {searched ? `검색 결과 (${acctResults.length})` : `관리자 계정 (${acctResults.length})`}
        </h3>
        {!searched && (
          <p style={{ fontSize: 12.5, color: "var(--steel-light)", margin: "0 0 12px" }}>
            학생·학교 계정을 보려면 위에서 검색하세요.
          </p>
        )}
        {acctResults.length === 0 ? (
          <div className="empty"><p>일치하는 계정이 없습니다.</p></div>
        ) : (
        <table className="table">
          <thead>
            <tr><th>이름</th><th>이메일</th><th>연락처</th><th>구분</th><th>연결 학교</th><th>가입일</th><th></th></tr>
          </thead>
          <tbody>
            {acctResults.map((u) => (
              <tr key={u.id} style={{ opacity: u.is_active ? 1 : 0.45 }}>
                <td style={{ fontWeight: 600 }}>{u.name}</td>
                <td style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{u.email}</td>
                <td style={{ fontSize: 12.5 }}>{u.phone || "—"}</td>
                <td><span className="badge">{ROLE_LABEL[u.role]}</span></td>
                <td>{u.school_name || "—"}</td>
                <td>{u.created_at.slice(0, 10)}</td>
                <td style={{ textAlign: "right", whiteSpace: "nowrap" }}>
                  {u.role !== "admin" && (
                    <>
                      <button className="btn btn-ghost btn-sm" style={{ marginRight: 6 }}
                        onClick={async () => {
                          const np = window.prompt(`${u.name} 계정의 새 비밀번호를 입력하세요 (8자 이상).`);
                          if (np == null) return;
                          if (np.length < 8) { alert("비밀번호는 8자 이상이어야 합니다."); return; }
                          try {
                            await api.adminResetPassword(u.id, np);
                            alert("비밀번호를 초기화했습니다. 새 비밀번호를 담당자에게 전달하세요.");
                          } catch (e) { alert(e.message); }
                        }}>
                        비번 초기화
                      </button>
                      <button className="btn btn-ghost btn-sm"
                        onClick={async () => {
                          await api.toggleUser(u.id, !u.is_active);
                          // 검색 상태면 재검색, 아니면 목록 새로고침
                          if (searched) searchAccounts(); else reload();
                        }}>
                        {u.is_active ? "정지" : "해제"}
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        )}
      </div>
    </div>
  );
}

function StatsTab({ stats }) {
  const planData = Object.entries(stats.plan_distribution).map(([name, value]) => ({ name, value }));
  const regionData = Object.entries(stats.region_distribution).map(([name, 학교수]) => ({ name, 학교수 }));
  const quiz = stats.quiz_stats || {};
  const [downloading, setDownloading] = useState(false);

  const download = async () => {
    setDownloading(true);
    try { await api.downloadAdminStats(); }
    catch (e) { window.alert(e.message); }
    finally { setDownloading(false); }
  };

  return (
    <div style={{ display: "grid", gap: 16 }}>
      <div style={{ display: "flex", justifyContent: "flex-end", flexWrap: "wrap" }}>
        <button className="btn btn-ghost btn-sm" onClick={download} disabled={downloading}>
          {downloading ? "생성 중…" : "⬇ 현황 리포트 (CSV)"}
        </button>
      </div>
      <div className="stat-grid">
        <div className="stat">
          <span className="label">등록 학교</span>
          <div className="stat-value">{stats.school_count.toLocaleString()}</div>
        </div>
        <div className="stat">
          <span className="label">학생 회원</span>
          <div className="stat-value">{stats.student_count.toLocaleString()}</div>
        </div>
        <div className="stat">
          <span className="label">학교 계정</span>
          <div className="stat-value">{stats.school_account_count.toLocaleString()}</div>
        </div>
        <div className="stat" style={{ borderLeft: "4px solid var(--signal)" }}>
          <span className="label">월 반복 매출</span>
          <div className="stat-value">{stats.monthly_revenue.toLocaleString()}<small> 원</small></div>
        </div>
        <div className="stat" style={{ borderLeft: stats.pending_orders ? "4px solid var(--alert)" : undefined }}>
          <span className="label">승인 대기</span>
          <div className="stat-value">{stats.pending_orders}<small> 건</small></div>
        </div>
      </div>

      <div className="panel">
        <h3>진로 적성 테스트 참여</h3>
        <p style={{ fontSize: 13, color: "var(--steel)", marginTop: -4 }}>
          비회원 참여도 함께 집계됩니다. (기록이 시작된 시점부터 누적)
        </p>
        <div className="stat-grid">
          {[["오늘", quiz.today], ["이번 달", quiz.month], ["올해", quiz.year], ["전체", quiz.total]].map(([label, v]) => (
            <div className="stat" key={label}>
              <span className="label">{label}</span>
              <div className="stat-value">{(v || 0).toLocaleString()}<small> 명</small></div>
            </div>
          ))}
        </div>
        <p className="label" style={{ marginTop: 8, color: "var(--steel-light)" }}>
          회원 {(quiz.members || 0).toLocaleString()}명 · 비회원 {(quiz.guests || 0).toLocaleString()}명
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 12 }}>
        <div className="panel">
          <h3>플랜 분포</h3>
          <div style={{ height: 230 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={planData} dataKey="value" nameKey="name" innerRadius={48} outerRadius={78} paddingAngle={2}>
                  {planData.map((e) => <Cell key={e.name} fill={PLAN_COLORS[e.name]} />)}
                </Pie>
                <Tooltip contentStyle={{ border: "1px solid #dbe1e6", borderRadius: 4, fontSize: 13 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center" }}>
            {planData.map((p) => (
              <span key={p.name} style={{ fontSize: 11.5, display: "flex", alignItems: "center", gap: 4 }}>
                <i style={{ width: 8, height: 8, background: PLAN_COLORS[p.name], display: "inline-block" }} />
                {p.name} {p.value}
              </span>
            ))}
          </div>
        </div>

        <div className="panel">
          <h3>지역별 학교 수</h3>
          <div style={{ height: 260 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={regionData} margin={{ top: 5, right: 5, bottom: 5, left: -22 }}>
                <CartesianGrid strokeDasharray="2 4" stroke="#dbe1e6" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10.5, fill: "#8a99a6" }} tickLine={false} axisLine={{ stroke: "#dbe1e6" }} interval={0} />
                <YAxis tick={{ fontSize: 11, fill: "#8a99a6" }} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ border: "1px solid #dbe1e6", borderRadius: 4, fontSize: 13 }} cursor={{ fill: "rgba(255,197,61,0.12)" }} />
                <Bar dataKey="학교수" fill="#ff7a59" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="panel">
        <h3>조회수 상위 학교</h3>
        <table className="table">
          <thead><tr><th>순위</th><th>학교</th><th>플랜</th><th style={{ textAlign: "right" }}>조회수</th></tr></thead>
          <tbody>
            {stats.top_viewed.map((s, i) => (
              <tr key={s.name}>
                <td className="label">{String(i + 1).padStart(2, "0")}</td>
                <td style={{ fontWeight: 600 }}>{s.name}</td>
                <td><span className="badge">{s.plan}</span></td>
                <td style={{ textAlign: "right", fontFamily: "var(--font-mono)" }}>{s.views.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function AdminPanel() {
  const [tab, setTab] = useState("stats");
  const [subPending, setSubPending] = useState(0);
  const [stats, setStats] = useState(null);
  const [orders, setOrders] = useState([]);
  const [users, setUsers] = useState([]);

  const load = () => {
    api.adminStats().then(setStats);
    api.adminOrders().then(setOrders);
    api.adminUsers().then(setUsers);
  };

  useEffect(() => { load(); }, []);

  if (!stats) return <div className="wrap" style={{ padding: 60 }}><div className="empty"><p>불러오는 중…</p></div></div>;

  const pending = orders.filter((o) => o.status === "pending").length;

  return (
    <div className="wrap" style={{ padding: "34px 0 60px" }}>
      <span className="label">포털 관리</span>
      <h1 style={{ fontSize: 26, margin: "8px 0 20px" }}>관리자 대시보드</h1>

      <div className="tabs">
        <button className={`tab ${tab === "stats" ? "active" : ""}`} onClick={() => setTab("stats")}>현황</button>
        <button className={`tab ${tab === "orders" ? "active" : ""}`} onClick={() => setTab("orders")}>
          플랜 승인 {pending > 0 && <span className="badge" style={{ background: "var(--alert)", color: "#fff", borderColor: "var(--alert)", marginLeft: 4 }}>{pending}</span>}
        </button>
        <button className={`tab ${tab === "subs" ? "active" : ""}`} onClick={() => setTab("subs")}>
          구독 결제 {subPending > 0 && <span className="badge" style={{ background: "var(--alert)", color: "#fff", borderColor: "var(--alert)", marginLeft: 4 }}>{subPending}</span>}
        </button>
        <button className={`tab ${tab === "accounts" ? "active" : ""}`} onClick={() => setTab("accounts")}>계정 관리</button>
        <button className={`tab ${tab === "schools" ? "active" : ""}`} onClick={() => setTab("schools")}>학교 관리</button>
        <button className={`tab ${tab === "plans" ? "active" : ""}`} onClick={() => setTab("plans")}>플랜 관리</button>
        <button className={`tab ${tab === "articles" ? "active" : ""}`} onClick={() => setTab("articles")}>기사 관리</button>
        <button className={`tab ${tab === "notices" ? "active" : ""}`} onClick={() => setTab("notices")}>공지 관리</button>
      </div>

      {tab === "stats" && <StatsTab stats={stats} />}
      {tab === "orders" && <OrdersTab orders={orders} reload={load} />}
      {tab === "subs" && <SubscriptionTab onCount={setSubPending} />}
      {tab === "accounts" && <AccountsTab users={users} reload={load} />}
      {tab === "schools" && <SchoolManageTab />}
      {tab === "plans" && (
        <div style={{ display: "grid", gap: 16 }}>
          <PlanGrantPanel />
          <PlanManageTab />
        </div>
      )}
      {tab === "articles" && <ArticleManageTab />}
      {tab === "notices" && (
        <div style={{ display: "grid", gap: 16 }}>
          <FloatingButtonPanel />
          <NoticeComposer mode="admin" />
        </div>
      )}
    </div>
  );
}


/* ---------------- 구독 결제 (자기소개서 이용권) ---------------- */
/** 카드 결제는 자동 승인되므로, 여기서 손댈 것은 무통장 입금 건이다. */
function SubscriptionTab({ onCount }) {
  // 구독 결제는 기록해로 옮겨졌다. 이곳에서는 안내만 한다.
  useEffect(() => { if (onCount) onCount(0); }, [onCount]);
  return (
    <div className="panel">
      <h3>구독 결제</h3>
      <p style={{ fontSize: 14.5, color: "var(--steel)", lineHeight: 1.85, marginTop: 0 }}>
        자기소개서 이용권 결제는 <b>기록해</b>에서 관리합니다.
        무통장 입금 승인, 요금·계좌 설정, 이용 현황을 그곳에서 확인하실 수 있습니다.
        같은 관리자 계정으로 로그인됩니다.
      </p>
      <a className="btn btn-signal" href="https://diary.ggm.kr/admin"
         target="_blank" rel="noreferrer">
        기록해 관리자로 이동
      </a>
    </div>
  );
}

/* ---------------- 무상 플랜 지급 ---------------- */
/** 관리자가 학교에 체험용 플랜을 직접 준다.
 *  결제 없이 주는 것이라 누가 언제 줬는지 기록이 남는다. */
function PlanGrantPanel() {
  const [keyword, setKeyword] = useState("");
  const [found, setFound] = useState([]);
  const [target, setTarget] = useState(null);
  const [status, setStatus] = useState(null);   // 고른 학교의 현재 플랜 상태
  const [plan, setPlan] = useState("premium");
  const [months, setMonths] = useState(1);
  const [reason, setReason] = useState("");
  const [grants, setGrants] = useState([]);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const loadGrants = () => api.planGrants().then(setGrants).catch(() => {});
  useEffect(() => { loadGrants(); }, []);

  // 학교를 고르면 지금 어떤 플랜을 쓰는지 먼저 확인한다.
  // 결제 고객에게 상위 플랜을 주면 남은 기간이 사라지므로 미리 막아야 한다.
  useEffect(() => {
    if (!target) { setStatus(null); return; }
    setStatus(null);
    api.schoolPlanStatus(target.id).then(setStatus).catch(() => setStatus(null));
  }, [target]);

  // 결제 중이면 그 등급 이하만 고를 수 있다.
  const PLAN_RANK = { basic: 1, premium: 2, platinum: 3 };
  const allowed = ["basic", "premium", "platinum"].filter(
    (p) => !status || PLAN_RANK[p] <= status.max_rank
  );

  useEffect(() => {
    if (allowed.length > 0 && !allowed.includes(plan)) setPlan(allowed[allowed.length - 1]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  const search = async () => {
    if (!keyword.trim()) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await api.schools({ name: keyword.trim(), size: 10, include_hidden: true });
      setFound(r.items || []);
      if ((r.items || []).length === 0) setMsg({ type: "error", text: "찾은 학교가 없습니다." });
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const grant = async () => {
    if (!target) return;
    const extend = status && status.days_left > 0;
    if (!confirm(
      `${target.name}에 ${PLAN_LABEL[plan]} ${months}개월을 무상으로 지급할까요?\n\n` +
      (extend
        ? `현재 ${status.expires_at}까지 이용 중이며, 그 뒤에 ${months}개월이 더해집니다.`
        : `기간이 끝나면 자동으로 무료 플랜으로 돌아갑니다.`)
    )) return;
    setBusy(true);
    setMsg(null);
    try {
      const r = await api.grantPlan(target.id, { plan, months, reason: reason.trim() });
      setMsg({
        type: "ok",
        text: `${r.school}에 지급했습니다. ${String(r.expires_at).slice(0, 10)}까지 이용합니다.`,
      });
      setTarget(null);
      setStatus(null);
      setFound([]);
      setKeyword("");
      setReason("");
      await loadGrants();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const revoke = async (g) => {
    const why = prompt("회수 사유를 적어주세요. 기록에 남습니다.", "체험 종료");
    if (why === null) return;
    setBusy(true);
    try {
      await api.revokePlan(g.school_id, why);
      await loadGrants();
      setMsg({ type: "ok", text: `${g.school_name}의 플랜을 회수했습니다.` });
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const active = grants.filter((g) => g.active);

  return (
    <div className="panel">
      <h3>무상 플랜 지급</h3>
      <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 12px", lineHeight: 1.7 }}>
        학교에 체험용으로 플랜을 줍니다. 결제 없이 적용되며,
        <b> 기간이 끝나면 자동으로 무료 플랜으로 돌아갑니다.</b>
        이미 이용 중인 학교는 남은 기간 뒤에 이어 붙습니다.
      </p>

      {msg && <div className={`notice notice-${msg.type}`} style={{ marginBottom: 12 }}>{msg.text}</div>}

      <div className="row" style={{ gap: 6 }}>
        <input className="input" style={{ maxWidth: 220 }} value={keyword}
          placeholder="학교 이름으로 찾기"
          onKeyDown={(e) => e.key === "Enter" && search()}
          onChange={(e) => setKeyword(e.target.value)} />
        <button className="btn btn-sm" onClick={search} disabled={busy}>찾기</button>
      </div>

      {found.length > 0 && (
        <div style={{ marginTop: 10 }}>
          {found.map((s) => (
            <label key={s.id} className="row" style={{ gap: 8, padding: "7px 0",
              borderTop: "1px solid var(--line)", cursor: "pointer", alignItems: "center" }}>
              <input type="radio" name="grant-school" checked={target?.id === s.id}
                onChange={() => setTarget(s)} />
              <span style={{ flex: 1, minWidth: 0 }}>
                <b>{s.name}</b>
                <span className="label" style={{ color: "var(--steel-light)", marginLeft: 6 }}>
                  {s.region} · {s.category}
                </span>
              </span>
            </label>
          ))}
        </div>
      )}

      {target && (
        <div style={{ marginTop: 14, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
          {status && (
            <div className={`notice ${status.is_paid ? "notice-error" : ""}`}
                 style={{ marginBottom: 12, fontSize: 13.5, lineHeight: 1.75 }}>
              현재 <b>{status.plan_label}</b>
              {status.days_left > 0
                ? ` · ${status.expires_at}까지 (${status.days_left}일 남음)`
                : " · 기간 없음"}
              {status.is_free_trial && " · 무료 체험 중"}
              {status.is_paid && (
                <>
                  <br />
                  <b>결제해서 이용 중인 학교입니다.</b> 상위 플랜을 지금 주면
                  남은 {status.days_left}일이 사라지므로,
                  <b> {status.plan_label} 이하로만</b> 기간을 연장할 수 있습니다.
                </>
              )}
            </div>
          )}
          <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
            <span style={{ fontWeight: 700 }}>{target.name}</span>
            <select className="select" style={{ width: "auto" }} value={plan}
              onChange={(e) => setPlan(e.target.value)}>
              {allowed.map((p) => (
                <option key={p} value={p}>{PLAN_LABEL[p]}</option>
              ))}
            </select>
            <select className="select" style={{ width: "auto" }} value={months}
              onChange={(e) => setMonths(Number(e.target.value))}>
              {[1, 2, 3, 6, 12].map((m) => <option key={m} value={m}>{m}개월</option>)}
            </select>
            <input className="input" style={{ maxWidth: 200 }} value={reason}
              placeholder="사유 (예: 영업 체험)"
              onChange={(e) => setReason(e.target.value)} />
            <button className="btn btn-sm" onClick={grant} disabled={busy}>
              {busy ? "처리 중…" : "지급"}
            </button>
          </div>
        </div>
      )}

      <div style={{ marginTop: 18, paddingTop: 14, borderTop: "1px solid var(--line)" }}>
        <h4 style={{ fontSize: 14, margin: "0 0 8px" }}>
          지급 이력 {active.length > 0 && `(이용 중 ${active.length}곳)`}
        </h4>
        {grants.length === 0 ? (
          <p style={{ fontSize: 13.5, color: "var(--steel)" }}>아직 지급한 이력이 없습니다.</p>
        ) : grants.map((g) => (
          <div key={g.id} style={{ display: "flex", gap: 10, alignItems: "flex-start",
            padding: "9px 0", borderTop: "1px solid var(--line)", fontSize: 13.5,
            minWidth: 0, flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 160 }}>
              <b>{g.school_name}</b> · {g.plan_label} {g.months}개월
              <div style={{ fontSize: 12, color: "var(--steel-light)", marginTop: 2 }}>
                {g.starts_on} ~ {g.expires_on}
                {g.reason ? ` · ${g.reason}` : ""}
                {g.granted_by ? ` · ${g.granted_by}` : ""}
              </div>
            </div>
            {g.revoked_at ? (
              <span className="badge" style={{ flexShrink: 0 }}>회수됨</span>
            ) : g.active ? (
              <>
                <span className="badge badge-done" style={{ flexShrink: 0 }}>이용 중</span>
                <button className="btn btn-sm btn-ghost" disabled={busy}
                  onClick={() => revoke(g)}>회수</button>
              </>
            ) : (
              <span className="badge" style={{ flexShrink: 0 }}>기간 만료</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
