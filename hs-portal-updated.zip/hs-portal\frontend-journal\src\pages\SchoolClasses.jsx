import { useEffect, useState } from "react";
import { api } from "../api";
import Help from "../components/Help";

/** 학생 명단 확인과 선생님 담당 과목 배정.
 *  예전에는 '이용권' 화면의 탭 중 하나였는데, 결제·좌석과는 무관한 기능이라
 *  '이용권'이라는 이름만 보고는 여기 들어갈 생각을 못 한다는 의견이 있어
 *  따로 뺐다. */
export default function SchoolClasses() {
  const [tab, setTab] = useState("roster");
  const tabs = [["roster", "학생 명단"], ["subjects", "담당 과목"]];

  return (
    <div className="wrap page" style={{ maxWidth: 860 }}>
      <span className="label">학교 관리</span>
      <h1>학급·과목 관리</h1>
      <p style={{ color: "var(--steel)", lineHeight: 1.8, marginTop: 0 }}>
        우리 학교 학생 명단을 확인하고, 선생님별로 세특을 만들 수 있는 담당 과목을 정합니다.
      </p>

      <div className="row" style={{ gap: 6, margin: "16px 0" }}>
        {tabs.map(([k, label]) => (
          <button key={k} className={`btn btn-sm ${tab === k ? "" : "btn-ghost"}`}
            onClick={() => setTab(k)}>{label}</button>
        ))}
      </div>

      {tab === "roster" && <RosterTab />}
      {tab === "subjects" && <SubjectsTab />}
    </div>
  );
}

function RosterTab() {
  const [data, setData] = useState(null);
  const [q, setQ] = useState("");
  const [term, setTerm] = useState("");
  const [offset, setOffset] = useState(0);
  const LIMIT = 20;

  useEffect(() => {
    api.schoolStudents({ q, limit: LIMIT, offset })
      .then(setData).catch(() => setData({ total: 0, items: [] }));
  }, [q, offset]);

  useEffect(() => { setOffset(0); }, [q]);

  if (!data) return <p className="meta">불러오는 중…</p>;

  const page = Math.floor(offset / LIMIT) + 1;
  const last = Math.max(1, Math.ceil(data.total / LIMIT));

  return (
    <div className="panel">
      <div className="row" style={{ gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <b>학생 {data.total}명</b>
        <input className="input" value={term} style={{ maxWidth: 220 }}
          placeholder="이름·반으로 찾기"
          onChange={(e) => setTerm(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && setQ(term)} />
        <button className="btn btn-sm" onClick={() => setQ(term)}>찾기</button>
      </div>

      {data.items.length === 0 ? (
        <p className="meta" style={{ marginTop: 12 }}>
          {q ? "찾는 학생이 없습니다." : "등록된 학생이 없습니다."}
        </p>
      ) : (
        <>
          <table style={{ width: "100%", fontSize: 13.5, marginTop: 12 }}>
            <thead>
              <tr style={{ color: "var(--steel-light)", textAlign: "left" }}>
                <th>이름</th><th>학년·반</th>
                <th>재학생 인증<Help text="선생님이 우리동네 직업계고에서 승인하는 절차입니다. 인증돼야 학생이 일지를 선생님께 제출할 수 있습니다." /></th>
                <th>이용권</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((s) => (
                <tr key={s.user_id}>
                  <td style={{ padding: "6px 0" }}>{s.name}</td>
                  <td>{s.class_name || (s.grade ? `${s.grade}학년` : "—")}</td>
                  <td>{s.verified
                    ? <span className="badge badge-done">인증됨</span>
                    : <span className="meta">미인증</span>}</td>
                  <td>{s.has_seat
                    ? <span className="badge badge-done">이용 중</span>
                    : <span className="meta">—</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="row" style={{ gap: 10, marginTop: 14, alignItems: "center" }}>
            <button className="btn btn-sm" disabled={offset === 0}
              onClick={() => setOffset(offset - LIMIT)}>이전</button>
            <span className="meta">{page} / {last} 쪽</span>
            <button className="btn btn-sm" disabled={offset + LIMIT >= data.total}
              onClick={() => setOffset(offset + LIMIT)}>다음</button>
          </div>
        </>
      )}

      <p className="meta" style={{ marginTop: 12, lineHeight: 1.7 }}>
        재학생 인증은 <b>우리동네 직업계고</b>에서 담당 선생님이 승인합니다.
        인증되지 않은 학생도 이용권은 받을 수 있지만, 일지를 선생님께 제출하려면
        인증이 필요합니다.
      </p>
    </div>
  );
}

function SubjectsTab() {
  const [teachers, setTeachers] = useState(null);
  const [picked, setPicked] = useState(null);       // 선택한 선생님
  const [subjectList, setSubjectList] = useState([]); // 그 선생님의 담당 과목
  const [options, setOptions] = useState([]);         // 학교 전체 과목 목록
  const [addId, setAddId] = useState("");
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  const loadTeachers = () =>
    api.schoolTeachers().then(setTeachers).catch((e) => setMsg({ type: "error", text: e.message }));

  useEffect(() => {
    loadTeachers();
    api.journalSubjects().then((s) => setOptions(s?.subject_options || [])).catch(() => {});
  }, []);

  const openTeacher = (t) => {
    setPicked(t);
    setMsg(null);
    api.teacherSubjects(t.id).then(setSubjectList).catch((e) => setMsg({ type: "error", text: e.message }));
  };

  const add = async () => {
    if (!picked || !addId) return;
    setBusy(true); setMsg(null);
    try {
      await api.addTeacherSubject(picked.id, parseInt(addId, 10));
      setAddId("");
      openTeacher(picked);
      loadTeachers();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (assignmentId) => {
    setBusy(true); setMsg(null);
    try {
      await api.removeTeacherSubject(picked.id, assignmentId);
      openTeacher(picked);
      loadTeachers();
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  if (!teachers) return <p className="meta">불러오는 중…</p>;

  return (
    <div className="row" style={{ gap: 14, alignItems: "flex-start", flexWrap: "wrap" }}>
      <div className="panel" style={{ flex: "1 1 260px", minWidth: 240 }}>
        <b>선생님 {teachers.length}명</b>
        <p className="meta" style={{ marginTop: 4, lineHeight: 1.6 }}>
          담당 학급은 <b>우리동네 직업계고</b> 선생님 권한에서 정합니다. 여기서는
          과목 세특을 만들 수 있는 <b>담당 과목</b>
          <Help text="담임 학급(1명당 1개)과 별개 개념입니다. 담당 과목으로 정해두면 담임이 아니어도 그 과목 수업일지를 보고 세특 초안을 만들 수 있습니다. 한 선생님이 여러 과목을 맡을 수 있습니다." />
          만 정합니다.
        </p>
        {teachers.length === 0 ? (
          <p className="meta" style={{ marginTop: 10 }}>등록된 선생님이 없습니다.</p>
        ) : (
          <div style={{ display: "grid", gap: 6, marginTop: 10 }}>
            {teachers.map((t) => (
              <button key={t.id}
                className={`btn btn-sm ${picked?.id === t.id ? "" : "btn-ghost"}`}
                style={{ justifyContent: "space-between", display: "flex" }}
                onClick={() => openTeacher(t)}>
                <span>{t.name}{t.class_name ? ` · ${t.class_name} 담임` : ""}</span>
                <span className="meta">담당 과목 {t.subject_count}개</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="panel" style={{ flex: "1 1 300px", minWidth: 260 }}>
        {!picked ? (
          <p className="meta">왼쪽에서 선생님을 골라주세요.</p>
        ) : (
          <>
            <b>{picked.name} 선생님 담당 과목</b>
            <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: "wrap" }}>
              <select className="select" value={addId} style={{ maxWidth: 220 }}
                onChange={(e) => setAddId(e.target.value)}>
                <option value="">과목 선택</option>
                {options
                  .filter((o) => !subjectList.some((s) => s.subject_id === o.id))
                  .map((o) => (
                    <option key={o.id} value={o.id}>
                      {[o.department, o.grade ? `${o.grade}학년` : "", o.name]
                        .filter(Boolean).join(" · ")}
                    </option>
                  ))}
              </select>
              <button className="btn btn-sm btn-primary" onClick={add} disabled={busy || !addId}>
                추가
              </button>
            </div>

            {subjectList.length === 0 ? (
              <p className="meta" style={{ marginTop: 12 }}>아직 담당 과목이 없습니다.</p>
            ) : (
              <div style={{ display: "grid", gap: 6, marginTop: 12 }}>
                {subjectList.map((s) => (
                  <div key={s.id} className="row"
                    style={{ justifyContent: "space-between", alignItems: "center" }}>
                    <span>
                      {[s.department, s.grade ? `${s.grade}학년` : "", s.subject_name]
                        .filter(Boolean).join(" · ")}
                    </span>
                    <button className="btn btn-sm btn-ghost" onClick={() => remove(s.id)}
                      disabled={busy}>제거</button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
        {msg && <div className={`notice notice-${msg.type}`} style={{ marginTop: 12 }}>{msg.text}</div>}
      </div>
    </div>
  );
}
