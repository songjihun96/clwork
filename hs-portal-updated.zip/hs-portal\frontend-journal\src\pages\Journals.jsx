import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import MyClassBar from "../components/MyClassBar";

const KIND_LABEL = { lesson: "수업 일지", diary: "학교생활 일기" };

export default function Journals() {
  const [items, setItems] = useState(null);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");
  const [subject, setSubject] = useState("all");

  useEffect(() => {
    api.journals()
      .then(setItems)
      .catch((e) => { setError(e.message); setItems([]); });
  }, []);

  if (error) {
    return (
      <div className="wrap page">
        <div className="notice notice-error">{error}</div>
      </div>
    );
  }
  if (!items) {
    return <div className="wrap page"><p>불러오는 중…</p></div>;
  }

  const byKind = filter === "all" ? items : items.filter((i) => i.kind === filter);
  // 수업 일지를 볼 때만 과목별로 더 좁힐 수 있다 — 학교생활 일기는 과목이 없다.
  const subjects = [...new Set(items.filter((i) => i.kind === "lesson" && i.subject)
    .map((i) => i.subject))];
  const shown = (filter === "lesson" && subject !== "all")
    ? byKind.filter((i) => i.subject === subject) : byKind;

  return (
    <div className="wrap page">
      <div className="row" style={{ marginBottom: 6 }}>
        <div>
          <span className="label">내 기록</span>
          <h1 style={{ marginTop: 4 }}>일지와 일기</h1>
        </div>
        <div className="spacer" />
        <Link to="/journals/new" className="btn btn-primary">새로 쓰기</Link>
      </div>
      <p style={{ color: "var(--steel)", fontSize: 14, marginTop: 0 }}>
        오늘 있었던 일, 수업에서 배운 것을 편하게 남겨보세요.
      </p>

      <MyClassBar />

      <div className="row" style={{ margin: "18px 0 12px", flexWrap: "wrap" }}>
        {[["all", "전체"], ["diary", "학교생활 일기"], ["lesson", "수업 일지"]].map(([k, label]) => (
          <button
            key={k}
            className={`btn btn-sm ${filter === k ? "" : "btn-ghost"}`}
            onClick={() => { setFilter(k); setSubject("all"); }}
          >
            {label}
          </button>
        ))}
      </div>

      {filter === "lesson" && subjects.length > 0 && (
        <div className="row" style={{ margin: "0 0 12px", flexWrap: "wrap", gap: 6 }}>
          <button className={`btn btn-sm ${subject === "all" ? "" : "btn-ghost"}`}
            onClick={() => setSubject("all")}>전체 과목</button>
          {subjects.map((s) => (
            <button key={s} className={`btn btn-sm ${subject === s ? "" : "btn-ghost"}`}
              onClick={() => setSubject(s)}>
              {s}
            </button>
          ))}
        </div>
      )}

      {shown.length === 0 ? (
        <div className="empty">
          <h3>아직 기록이 없습니다</h3>
          <p>오늘 있었던 일부터 한 줄 남겨보세요.</p>
          <Link to="/journals/new" className="btn btn-primary" style={{ marginTop: 12 }}>
            첫 기록 쓰기
          </Link>
        </div>
      ) : (
        shown.map((it) => (
          <Link key={it.id} to={`/journals/${it.id}`} className="entry">
            <div className="row" style={{ gap: 6, marginBottom: 4 }}>
              <span className="badge">{KIND_LABEL[it.kind] || it.kind}</span>
              {it.sent_at && <span className="badge badge-done">선생님께 제출함</span>}
              {/* 답글이 온 것을 목록에서 바로 알아보게 한다. 안 읽은 것만 강조. */}
              {it.feedback_unread && <span className="badge badge-new">선생님 한마디 도착</span>}
              {it.has_feedback && !it.feedback_unread && (
                <span className="badge">선생님 한마디</span>
              )}
            </div>
            <h4>{it.title || it.subject || it.entry_date}</h4>
            <div className="meta">
              {it.entry_date}
              {it.subject && it.title ? ` · ${it.subject}` : ""}
              {it.teacher_name ? ` · ${it.teacher_name} 선생님` : ""}
            </div>
          </Link>
        ))
      )}
    </div>
  );
}
