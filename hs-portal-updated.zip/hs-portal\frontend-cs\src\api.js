// 상담 사이트는 본 사이트와 같은 백엔드를 쓰지만 /api/cs 아래만 부른다.
// 도메인이 다르므로 로그인 토큰도 따로 보관한다.
const TOKEN_KEY = "udj_cs_token";
const DEVICE_KEY = "udj_cs_device";

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => localStorage.setItem(TOKEN_KEY, t);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

// 기기 토큰은 서버가 발급한다. 승인을 받으면 이 기기에서 계속 쓸 수 있다.
// 로그아웃해도 지우지 않는다. 지우면 승인을 다시 받아야 한다.
export const getDevice = () => localStorage.getItem(DEVICE_KEY);
export const setDevice = (t) => localStorage.setItem(DEVICE_KEY, t);

async function request(path, { method = "GET", body, params } = {}) {
  const url = new URL(path, window.location.origin);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== "") url.searchParams.set(k, v);
    }
  }

  const headers = {};
  const token = getToken();
  const device = getDevice();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (device) headers["X-CS-Device"] = device;
  if (body) headers["Content-Type"] = "application/json";

  const res = await fetch(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return null;

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (!res.ok) {
    const err = new Error(detailOf(data) || `요청에 실패했습니다 (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

function detailOf(data) {
  if (!data) return "";
  const d = data.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d) && d.length) return d[0].msg || "";
  return "";
}

export const api = {
  // 인증
  login: (email, password, device_label = "") =>
    request("/api/cs/login", { method: "POST", body: { email, password, device_label } }),
  me: () => request("/api/cs/me"),
  summary: () => request("/api/cs/summary"),

  // 회원
  users: (params) => request("/api/cs/users", { params }),
  user: (id, reveal = false) =>
    request(`/api/cs/users/${id}`, { params: reveal ? { reveal: "true" } : null }),
  sendPasswordReset: (id, reason) =>
    request(`/api/cs/users/${id}/password-reset`, { method: "POST", body: { reason } }),

  // 학교
  schools: (params) => request("/api/cs/schools", { params }),
  school: (id) => request(`/api/cs/schools/${id}`),
  updateSchool: (id, patch) =>
    request(`/api/cs/schools/${id}`, { method: "PATCH", body: patch }),

  // 문의
  inquiries: (params) => request("/api/cs/inquiries", { params }),
  answerInquiry: (id, answer) =>
    request(`/api/cs/inquiries/${id}/answer`, { method: "POST", body: { answer } }),

  // 후기
  reviews: (params) => request("/api/cs/reviews", { params }),
  hideReview: (id, reason) =>
    request(`/api/cs/reviews/${id}/hide`, { method: "POST", body: { reason } }),
  unhideReview: (id) => request(`/api/cs/reviews/${id}/unhide`, { method: "POST" }),

  // 재학생 인증
  verifications: (params) => request("/api/cs/verifications", { params }),
  decideVerification: (id, decision, note = "") =>
    request(`/api/cs/verifications/${id}/decide`, {
      method: "POST",
      body: { decision, note },
    }),

  // 결제·구독
  orders: (params) => request("/api/cs/orders", { params }),
  confirmPaid: (id, note = "") =>
    request(`/api/cs/orders/${id}/confirm-paid`, { method: "POST", body: { note } }),
  subscriptions: (params) => request("/api/cs/subscriptions", { params }),

  // 관리자 전용
  devices: (status = "") => request("/api/cs/admin/devices", { params: { status } }),
  decideDevice: (id, decision, label = "") =>
    request(`/api/cs/admin/devices/${id}/decide`, {
      method: "POST",
      body: { decision, label },
    }),
  deleteDevice: (id) => request(`/api/cs/admin/devices/${id}`, { method: "DELETE" }),
  agents: () => request("/api/cs/admin/agents"),
  createAgent: (body) => request("/api/cs/admin/agents", { method: "POST", body }),
  updateAgent: (id, body) =>
    request(`/api/cs/admin/agents/${id}`, { method: "PATCH", body }),
  officeIps: () => request("/api/cs/admin/office-ips"),
  setOfficeIps: (ips) =>
    request("/api/cs/admin/office-ips", { method: "PUT", body: { ips } }),
  audit: (params) => request("/api/cs/admin/audit", { params }),
};
