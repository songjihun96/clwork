import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../auth";
import { DormBadge, PlanBadge, Stars } from "./SchoolCard";

function ddayClass(d) {
  if (d < 0) return "dday past";
  if (d === 0) return "dday today";
  if (d <= 14) return "dday near";
  return "dday";
}

export function ddayText(d) {
  if (d === 0) return "D-DAY";
  return d > 0 ? `D-${d}` : `D+${Math.abs(d)}`;
}

function ReviewForm({ schoolId, existing, onDone }) {
  const [rating, setRating] = useState(existing?.rating || 5);
  const [content, setContent] = useState(existing?.content || "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    if (!content.trim()) {
      setError("후기 내용을 적어주세요.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await api.writeReview(schoolId, rating, content.trim());
      onDone();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ display: "grid", gap: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span className="label">별점</span>
        <div style={{ display: "flex", gap: 2 }}>
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              onClick={() => setRating(n)}
              aria-label={`${n}점`}
              style={{
                border: "none",
                background: "none",
                fontSize: 20,
                padding: "0 1px",
                color: n <= rating ? "var(--signal-deep)" : "var(--line)",
              }}
            >
              ★
            </button>
          ))}
        </div>
      </div>
      <textarea
        className="textarea"
        placeholder="재학생·졸업생이라면 실습 환경이나 취업 지원처럼 실제로 겪은 점을 적어주세요."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        maxLength={1000}
      />
      {error && <div className="notice notice-error">{error}</div>}
      <div>
        <button className="btn btn-sm" onClick={submit} disabled={busy}>
          {existing ? "후기 수정" : "후기 등록"}
        </button>
      </div>
    </div>
  );
}

function InquiryForm({ schoolId, schoolName, canQuick }) {
  const [form, setForm] = useState({ asker_name: "", contact_email: "", contact_phone: "", question: "" });
  const [consent, setConsent] = useState(false);
  const [notice, setNotice] = useState(null);
  const [showNotice, setShowNotice] = useState(false);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    api.inquiryPrivacy().then(setNotice).catch(() => {});
  }, []);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async () => {
    setMsg(null);
    if (!form.contact_email.trim()) return setMsg({ type: "error", text: "답변받을 이메일을 입력해주세요." });
    // 메일이 안 닿을 때 학교가 연락할 길이 있어야 한다.
    if (form.contact_phone.replace(/\D/g, "").length < 9)
      return setMsg({ type: "error", text: "연락처를 정확히 입력해주세요." });
    if (form.question.trim().length < 5) return setMsg({ type: "error", text: "문의 내용을 5자 이상 적어주세요." });
    if (!consent) return setMsg({ type: "error", text: "개인정보 수집·이용에 동의해야 문의를 남길 수 있습니다." });
    setBusy(true);
    try {
      const res = await api.createInquiry(schoolId, {
        asker_name: form.asker_name.trim(),
        contact_email: form.contact_email.trim(),
        contact_phone: form.contact_phone.trim(),
        question: form.question.trim(),
        privacy_consent: consent,
      });
      setDone(true);
      setMsg({ type: "ok", text: res.message });
    } catch (e) {
      setMsg({ type: "error", text: e.message });
    } finally {
      setBusy(false);
    }
  };

  if (done) {
    return (
      <div className="panel" id="inquiry">
        <h3>학교에 문의하기</h3>
        <div className="notice notice-ok">{msg?.text}</div>
        <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }}
          onClick={() => { setDone(false); setForm({ asker_name: "", contact_email: "", contact_phone: "", question: "" }); setConsent(false); setMsg(null); }}>
          다른 문의 남기기
        </button>
      </div>
    );
  }

  return (
    <div className="panel" id="inquiry">
      <h3>학교에 문의하기</h3>
      <p style={{ fontSize: 13, color: "var(--steel)", marginTop: -4 }}>
        {schoolName}에 궁금한 점을 남기면, 학교가 확인 후 입력하신 이메일로 답변을 보내드립니다.
      </p>
      {canQuick ? (
        <div className="notice notice-ok" style={{ marginBottom: 12 }}>
          ⚡ 이 학교는 <b>빠른 문의 가능</b> 학교입니다. 학교가 답변을 등록하면 입력하신 이메일로 발송됩니다.
        </div>
      ) : (
        <div className="notice notice-info" style={{ marginBottom: 12 }}>
          이 학교는 아직 포털에 계정을 개설하지 않아, 답변이 늦거나 어려울 수 있습니다.
        </div>
      )}
      <div style={{ display: "grid", gap: 12 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <div className="field">
            <label className="label">이름 (선택)</label>
            <input className="input" value={form.asker_name} onChange={set("asker_name")} maxLength={60} />
          </div>
          <div className="field">
            <label className="label">연락처 (필수)</label>
            <input className="input" value={form.contact_phone} onChange={set("contact_phone")}
              placeholder="전화번호" maxLength={30} />
          </div>
        </div>
        <div className="field">
          <label className="label">이메일 (필수) · 답변을 받을 주소</label>
          <input className="input" type="email" value={form.contact_email} onChange={set("contact_email")}
            placeholder="example@email.com" maxLength={120} />
        </div>
        <div className="field">
          <label className="label">문의 내용 (필수)</label>
          <textarea className="textarea" value={form.question} onChange={set("question")}
            placeholder="예: 반도체장비과 실습실은 몇 개인가요? 기숙사 신청은 어떻게 하나요?" maxLength={2000} />
        </div>

        <div style={{ border: "1px solid var(--line)", borderRadius: 6, padding: 12 }}>
          <label style={{ display: "flex", alignItems: "flex-start", gap: 8, fontSize: 13, cursor: "pointer" }}>
            <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)}
              style={{ marginTop: 2 }} />
            <span>
              <strong>[필수]</strong> 개인정보 수집·이용에 동의합니다.
              <button type="button" onClick={() => setShowNotice((v) => !v)}
                style={{ marginLeft: 6, background: "none", border: "none", color: "var(--signal-deep)", cursor: "pointer", padding: 0, fontSize: 12.5, textDecoration: "underline" }}>
                {showNotice ? "접기" : "자세히 보기"}
              </button>
            </span>
          </label>
          {showNotice && notice && (
            <div style={{ marginTop: 10, fontSize: 12.5, color: "var(--steel)", lineHeight: 1.7 }}>
              <div><b>수집 항목</b> : {notice.collected.join(", ")}</div>
              <div><b>수집·이용 목적</b> : {notice.purpose}</div>
              <div><b>보유·이용 기간</b> : {notice.retention}</div>
              <div><b>열람 범위</b> : {notice.recipient}</div>
              <div style={{ color: "var(--alert)" }}>{notice.right_to_refuse}</div>
              <div style={{ marginTop: 6 }}>
                <a href="/privacy" target="_blank" rel="noreferrer" style={{ color: "var(--signal-deep)" }}>
                  전체 개인정보처리방침 보기 →
                </a>
              </div>
            </div>
          )}
        </div>

        {msg && <div className={`notice notice-${msg.type}`}>{msg.text}</div>}
        <div>
          <button className="btn btn-signal" onClick={submit} disabled={busy}>
            {busy ? "접수 중…" : "문의 남기기"}
          </button>
        </div>
      </div>
    </div>
  );
}

function VerificationGate({ schoolId, status, onDone }) {
  const [requesting, setRequesting] = useState(false);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async () => {
    setBusy(true);
    setError("");
    try {
      await api.requestVerification(schoolId, note.trim());
      setRequesting(false);
      onDone();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  if (status === "pending") {
    return (
      <div className="notice notice-info" style={{ marginBottom: 14 }}>
        재학생 인증이 <b>승인 대기 중</b>입니다. 담당 선생님이 확인하면 후기를 남길 수 있어요.
      </div>
    );
  }

  // none 또는 rejected → 신청 가능
  return (
    <div style={{ marginBottom: 14 }}>
      {status === "rejected" && (
        <div className="notice notice-error" style={{ marginBottom: 10 }}>
          재학생 인증이 거절되었습니다. 정보를 보완해 다시 신청할 수 있어요.
        </div>
      )}
      {!requesting ? (
        <>
          <p style={{ fontSize: 13, color: "var(--steel)", margin: "0 0 8px" }}>
            후기는 이 학교의 <b>재학생 인증</b>을 받은 학생만 남길 수 있습니다.
          </p>
          <button className="btn btn-ghost btn-sm" onClick={() => setRequesting(true)}>
            재학생 인증 신청
          </button>
        </>
      ) : (
        <div className="panel" style={{ background: "var(--surface)" }}>
          <label className="label">학교가 확인할 수 있도록 소개를 남겨주세요 (학년/반/학번 등)</label>
          <input
            className="input"
            value={note}
            maxLength={200}
            placeholder="예: 2학년 3반 김OO / 학번 20230123 (선생님이 확인합니다)"
            onChange={(e) => setNote(e.target.value)}
            style={{ margin: "6px 0 10px" }}
          />
          {error && <div className="notice notice-error" style={{ marginBottom: 8 }}>{error}</div>}
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-primary btn-sm" onClick={submit} disabled={busy}>
              {busy ? "신청 중…" : "신청하기"}
            </button>
            <button className="btn btn-ghost btn-sm" onClick={() => setRequesting(false)} disabled={busy}>
              취소
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function SchoolDetailView({ schoolId, embedded, onLoaded }) {
  const { user } = useAuth();
  const [school, setSchool] = useState(null);
  const [error, setError] = useState("");
  const [writing, setWriting] = useState(false);
  const [articles, setArticles] = useState([]);

  const load = () =>
    api
      .school(schoolId)
      .then((data) => {
        setSchool(data);
        if (onLoaded) onLoaded(data);
      })
      .catch((e) => setError(e.message));

  useEffect(() => {
    load();
    api.schoolArticles(schoolId).then(setArticles).catch(() => setArticles([]));
    // 조회수는 화면을 열 때 한 번만 센다. load() 안에 두면 즐겨찾기·후기 작성으로
    // 다시 불릴 때마다 중복 집계된다.
    api.countSchoolView(schoolId).catch(() => {});
  }, [schoolId]);

  if (error) return <div className="notice notice-error">{error}</div>;
  if (!school) return <div className="empty"><p>불러오는 중…</p></div>;

  const myReview = school.reviews.find((r) => r.mine);
  const isStudent = user?.role === "student";

  const toggleFav = async () => {
    if (school.is_favorite) await api.removeFavorite(school.id);
    else await api.addFavorite(school.id);
    load();
  };

  const heroActions = (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      {school.website && (
        <a className="btn btn-ghost btn-sm" href={school.website} target="_blank" rel="noreferrer">
          학교 홈페이지
        </a>
      )}
      {embedded && (
        <a className="btn btn-ghost btn-sm" href={`/schools/${school.id}`} target="_blank" rel="noreferrer">
          새 탭에서 열기
        </a>
      )}
    </div>
  );

  // 학과별 사진은 없는 데이터라, 통계 카드는 실제로 있는 값만 보여준다
  // (없는 지표를 지어내지 않는다).
  const stats = [
    school.employment_rate != null && { icon: "work", value: `${school.employment_rate}%`, label: "졸업생 취업률", tone: "accent" },
    school.student_count != null && { icon: "groups", value: `${school.student_count.toLocaleString()}명`, label: "재학생 수", tone: "neutral" },
    school.rating_avg != null && school.review_count > 0 &&
      { icon: "star", value: school.rating_avg.toFixed(1), label: `후기 ${school.review_count}건 평균`, tone: "success" },
  ].filter(Boolean);

  return (
    <>
      {school.hero_image ? (
        <div className="detail-hero-photo" style={{ backgroundImage: `url(${school.hero_image})` }}>
          <div className="detail-hero-photo-body">
            <div style={{ color: "#fff", minWidth: 0 }}>
              <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
                <span className="hero-chip"><span className="msi" style={{ fontSize: 14 }}>location_on</span>{school.region}</span>
                <span className="hero-chip on-accent">{school.category}</span>
                <PlanBadge plan={school.plan} visible={user?.role === "admin" || user?.role === "school"} />
              </div>
              <h2>{school.name}</h2>
              <p>{school.slogan || school.address}</p>
              <div style={{ marginTop: 16 }}>
                {isStudent && (
                  <button className={school.is_favorite ? "btn btn-ghost btn-sm" : "btn btn-signal btn-sm"} onClick={toggleFav}>
                    {school.is_favorite ? "★ 즐겨찾기 해제" : "☆ 즐겨찾기"}
                  </button>
                )}
              </div>
            </div>
            {isStudent ? (
              <button className="hero-fav-btn" onClick={toggleFav} aria-label="즐겨찾기">
                <span className="msi" style={{ fontVariationSettings: school.is_favorite ? "'FILL' 1" : "'FILL' 0" }}>favorite</span>
              </button>
            ) : <span />}
          </div>
        </div>
      ) : (
        <div className="detail-hero">
          <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
            <span className="badge badge-cat">{school.category}</span>
            <PlanBadge plan={school.plan} visible={user?.role === "admin" || user?.role === "school"} />
            <span className="badge">{school.region}</span>
          </div>
          <h2>{school.name}</h2>
          <p>{school.slogan || school.address}</p>
          <div style={{ marginTop: 16 }}>
            {isStudent && (
              <button className={school.is_favorite ? "btn btn-ghost btn-sm" : "btn btn-signal btn-sm"} onClick={toggleFav}>
                {school.is_favorite ? "★ 즐겨찾기 해제" : "☆ 즐겨찾기"}
              </button>
            )}
          </div>
        </div>
      )}

      <div className="detail-body" style={embedded ? undefined : { padding: "0 28px 28px" }}>
        {!embedded && <div style={{ margin: "20px 0" }}>{heroActions}</div>}

        <div className={embedded ? undefined : "detail-grid"}>
          <div className={embedded ? undefined : "detail-main"}>
        {stats.length > 0 && (
          <div className="stat-icon-grid">
            {stats.map((s) => (
              <div className="stat-icon-card" key={s.label}>
                <div className={`stat-icon-circle tone-${s.tone}`}><span className="msi">{s.icon}</span></div>
                <div className="stat-icon-value">{s.value}</div>
                <div className="stat-icon-label">{s.label}</div>
              </div>
            ))}
          </div>
        )}

        {/* 검색 목록에도 나오는 기초 정보 */}
        <div className="panel">
          <h3>기본 정보</h3>
          <div className="kv-grid">
            {embedded && (
              <>
                <div>
                  <span className="label">주소</span>
                  <dd>{school.address}</dd>
                </div>
                <div>
                  <span className="label">전화번호</span>
                  <dd>{school.phone || "—"}</dd>
                </div>
              </>
            )}
            <div>
              <span className="label">남녀공학</span>
              <dd>{school.coed}</dd>
            </div>
            {school.dormitory === true && (
              <div>
                <span className="label">기숙사</span>
                <dd><DormBadge value={school.dormitory} /></dd>
              </div>
            )}
            <div>
              <span className="label">설립</span>
              <dd>
                {school.foundation || "—"}
                {school.established_year ? ` · ${school.established_year}년` : ""}
              </dd>
            </div>
            <div>
              <span className="label">평점</span>
              <dd><Stars value={school.rating_avg} count={school.review_count} /></dd>
            </div>
          </div>
        </div>

        {school.departments.length > 0 && (
          <div className="panel">
            <h3>개설 학과</h3>
            <div className="dept-list">
              {school.departments.map((d) => (
                <span className="dept" key={d}>{d}</span>
              ))}
            </div>
          </div>
        )}

        {school.intro && (
          <div className="panel">
            <h3>학교 소개</h3>
            <p className="prose">{school.intro}</p>
          </div>
        )}

        {school.facilities && (
          <div className="panel">
            <h3>실습 시설</h3>
            <p className="prose">{school.facilities}</p>
          </div>
        )}

        {school.admission_info && (
          <div className="panel">
            <h3>입학 안내</h3>
            <p className="prose">{school.admission_info}</p>
          </div>
        )}

        {["admission", "briefing"].map((kind) => {
          const list = school.events.filter(
            (e) => (e.kind || "admission") === kind
          );
          if (list.length === 0) return null;
          const heading = kind === "briefing" ? "학교 설명회 일정" : "입시 일정";
          return (
            <div className="panel" key={kind}>
              <h3>{heading}</h3>
              {list.map((e) => (
                <div className="event-row" key={e.id}>
                  <span className={ddayClass(e.d_day)}>{ddayText(e.d_day)}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{e.title}</div>
                    <div style={{ fontSize: 12.5, color: "var(--steel)" }}>
                      {e.start_date}
                      {e.end_date ? ` ~ ${e.end_date}` : ""}
                      {e.description ? ` · ${e.description}` : ""}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          );
        })}

        {articles.length > 0 && (
          <div className="panel">
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
              <h3 style={{ border: "none", padding: 0, margin: 0 }}>특성화고신문 기사</h3>
              <span className="label" style={{ color: "var(--steel-light)" }}>특성화고신문 제공</span>
            </div>
            <div style={{ display: "grid", gap: 12 }}>
              {articles.map((a) => (
                <a
                  key={a.id}
                  href={a.url}
                  target="_blank"
                  rel="noreferrer"
                  style={{
                    display: "flex", gap: 12, textDecoration: "none", color: "inherit",
                    border: "1px solid var(--line)", borderRadius: "var(--radius-sm)",
                    padding: 10, alignItems: "flex-start",
                  }}
                >
                  {a.thumbnail ? (
                    <div style={{ width: 92, height: 68, borderRadius: 8, flexShrink: 0, background: `#f0e6de url(${a.thumbnail}) center/cover no-repeat` }} />
                  ) : (
                    <div style={{ width: 92, height: 68, borderRadius: 8, flexShrink: 0, background: "var(--signal-soft)", display: "grid", placeItems: "center", fontSize: 24 }}>📰</div>
                  )}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 600, fontSize: 14, lineHeight: 1.4, marginBottom: 3 }}>{a.title}</div>
                    {a.summary && (
                      <p style={{ fontSize: 12.5, color: "var(--steel)", margin: 0, lineHeight: 1.5, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" }}>
                        {a.summary}
                      </p>
                    )}
                    <div style={{ display: "flex", gap: 8, marginTop: 5, alignItems: "center" }}>
                      {a.published_at && <span style={{ fontSize: 11.5, color: "var(--steel-light)" }}>{a.published_at}</span>}
                      <span style={{ fontSize: 11.5, color: "var(--signal-deep)" }}>원문 보기 →</span>
                    </div>
                  </div>
                </a>
              ))}
            </div>
          </div>
        )}

        <InquiryForm schoolId={school.id} schoolName={school.name} canQuick={school.can_quick_inquiry} />

        <div className="panel">
          <h3>재학생·졸업생 후기 ({school.review_count})</h3>

          {isStudent && school.my_verification === "approved" && !writing && (
            <button className="btn btn-ghost btn-sm" onClick={() => setWriting(true)} style={{ marginBottom: 14 }}>
              {myReview ? "내 후기 수정하기" : "후기 쓰기"}
            </button>
          )}
          {isStudent && school.my_verification === "approved" && writing && (
            <div style={{ marginBottom: 16 }}>
              <ReviewForm
                schoolId={school.id}
                existing={myReview}
                onDone={() => {
                  setWriting(false);
                  load();
                }}
              />
            </div>
          )}
          {isStudent && school.my_verification !== "approved" && (
            <VerificationGate schoolId={school.id} status={school.my_verification} onDone={load} />
          )}
          {!user && <p style={{ fontSize: 13, color: "var(--steel)" }}>후기를 쓰려면 학생 계정으로 로그인하세요.</p>}

          {school.reviews.length === 0 ? (
            <p style={{ fontSize: 13.5, color: "var(--steel)", margin: 0 }}>아직 등록된 후기가 없습니다.</p>
          ) : (
            school.reviews.map((r) => (
              <div key={r.id} style={{ padding: "12px 0", borderTop: "1px solid var(--line)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 5 }}>
                  <span style={{ color: "var(--signal-deep)", fontSize: 13 }}>{"★".repeat(r.rating)}</span>
                  <span style={{ fontSize: 12.5, color: "var(--steel)" }}>{r.author}</span>
                  <span className="label">{r.created_at.slice(0, 10)}</span>
                  {(r.mine || user?.role === "admin") && (
                    <button
                      className="btn btn-ghost btn-sm"
                      style={{ marginLeft: "auto", padding: "3px 8px", fontSize: 11 }}
                      onClick={async () => {
                        await api.deleteReview(r.id);
                        load();
                      }}
                    >
                      삭제
                    </button>
                  )}
                </div>
                <p className="prose" style={{ fontSize: 13.5 }}>{r.content}</p>
              </div>
            ))
          )}
        </div>
          </div>

          {!embedded && (
            <div className="detail-sidebar">
              <div className="panel">
                <h3>위치 및 연락처</h3>
                <div className="contact-list">
                  <div className="contact-row">
                    <span className="msi icon">location_on</span>
                    <div>
                      <span className="label">주소</span>
                      <div style={{ fontSize: 14, marginTop: 2 }}>{school.address}</div>
                    </div>
                  </div>
                  <div className="contact-row">
                    <span className="msi icon">call</span>
                    <div>
                      <span className="label">전화번호</span>
                      <div style={{ fontSize: 14, marginTop: 2 }}>{school.phone || "—"}</div>
                    </div>
                  </div>
                  {school.website && (
                    <div className="contact-row">
                      <span className="msi icon">language</span>
                      <div>
                        <span className="label">홈페이지</span>
                        <a href={school.website} target="_blank" rel="noreferrer"
                          style={{ display: "block", fontSize: 14, marginTop: 2 }}>
                          {school.website.replace(/^https?:\/\//, "")}
                        </a>
                      </div>
                    </div>
                  )}
                </div>
                <a className="btn btn-signal" href="#inquiry"
                  style={{ width: "100%", justifyContent: "center", display: "flex", alignItems: "center", gap: 8 }}>
                  <span className="msi" style={{ fontSize: 18 }}>forum</span> 입학 상담 신청
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
