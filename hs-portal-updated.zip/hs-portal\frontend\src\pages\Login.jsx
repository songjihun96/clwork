import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../auth";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const user = await login(email, password);
      if (user.role === "admin") navigate("/admin");
      else if (user.role === "school") navigate("/my-school");
      else navigate("/");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="wrap" style={{ maxWidth: 400, padding: "56px 0" }}>
      <span className="label">로그인</span>
      <h1 style={{ fontSize: 26, margin: "8px 0 22px" }}>다시 오셨네요</h1>

      <form onSubmit={submit} style={{ display: "grid", gap: 14 }}>
        <div className="field">
          <label className="label" htmlFor="email">이메일</label>
          <input id="email" className="input" type="email" value={email} required
            onChange={(e) => setEmail(e.target.value)} autoComplete="username" />
        </div>
        <div className="field">
          <label className="label" htmlFor="pw">비밀번호</label>
          <input id="pw" className="input" type="password" value={password} required
            onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
        </div>
        {error && <div className="notice notice-error">{error}</div>}
        <button className="btn btn-signal" disabled={busy}>
          {busy ? "확인 중…" : "로그인"}
        </button>
      </form>

      <p style={{ fontSize: 13.5, color: "var(--steel)", marginTop: 18 }}>
        학생 계정이 없다면 <Link to="/signup" style={{ color: "var(--ink)", fontWeight: 600 }}>회원가입</Link>
        {" · "}
        <Link to="/find-account" style={{ color: "var(--ink)", fontWeight: 600 }}>아이디·비밀번호 찾기</Link>
      </p>

      <div className="notice notice-info" style={{ marginTop: 20 }}>
        학교 계정은 직접 가입할 수 없습니다. 포털 관리자가 학교를 확인한 뒤 계정을 만들어 전달합니다.
      </div>
    </div>
  );
}
