import { useEffect, useState } from "react";
import { api } from "../api";
import { useAuth } from "../auth";

/** 오른쪽 아래 동그란 버튼. 관리자가 등록한 주소를 새 탭으로 연다.
 *  켜짐 여부와 노출 대상(역할)은 서버가 판단해 내려준다. */
export default function FloatingButton() {
  const { user } = useAuth();
  const [cfg, setCfg] = useState(null);

  useEffect(() => {
    let alive = true;
    api.floatingButton()
      .then((d) => { if (alive) setCfg(d?.enabled ? d : null); })
      .catch(() => { if (alive) setCfg(null); });
    return () => { alive = false; };
  }, [user?.id, user?.role]);   // 로그인 상태가 바뀌면 다시 확인

  if (!cfg) return null;

  return (
    <a className="fab" href={cfg.url} target="_blank" rel="noopener noreferrer" title={cfg.label}>
      <span className="fab-label">{cfg.label}</span>
      <span className="fab-circle" aria-hidden="true">↗</span>
    </a>
  );
}
