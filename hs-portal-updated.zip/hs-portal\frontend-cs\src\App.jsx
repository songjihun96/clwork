import { useEffect, useState } from "react";
import { NavLink, Navigate, Route, Routes, useLocation } from "react-router-dom";
import { api } from "./api";
import { useAuth } from "./auth";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Users from "./pages/Users";
import Schools from "./pages/Schools";
import Inquiries from "./pages/Inquiries";
import Reviews from "./pages/Reviews";
import Verifications from "./pages/Verifications";
import Orders from "./pages/Orders";
import Subscriptions from "./pages/Subscriptions";
import Manage from "./pages/Manage";

/** 어떤 경로로 들어왔는지 늘 보여준다.
 *  상담원이 지금 사무실인지 등록 기기인지 알고 있어야, 밖에서 열었을 때
 *  스스로 조심하게 된다. */
function AccessTag({ me }) {
  if (!me) return null;
  const title = me.ip ? `접속 IP ${me.ip}` : undefined;
  if (me.is_admin) {
    return (
      <span className="access admin" title={title}>
        <span className="dot" />
        관리자
      </span>
    );
  }
  if (me.how === "device") {
    return (
      <span className="access device" title={title}>
        <span className="dot" />
        등록 기기
      </span>
    );
  }
  return (
    <span className="access" title={title}>
      <span className="dot" />
      사무실 접속
    </span>
  );
}

export default function App() {
  const { user, loading, logout } = useAuth();
  const [counts, setCounts] = useState(null);
  const location = useLocation();

  // 대기 건수는 화면을 옮길 때마다 새로 읽는다. 처리하면 바로 줄어야 한다.
  useEffect(() => {
    if (!user) return;
    api.summary().then(setCounts).catch(() => {});
  }, [user, location.pathname]);

  if (loading) {
    return <div className="empty" style={{ paddingTop: 80 }}>불러오는 중…</div>;
  }
  if (!user) return <Login />;

  const item = (to, label, n) => (
    <NavLink to={to} className={({ isActive }) => (isActive ? "on" : "")} end={to === "/"}>
      <span>{label}</span>
      {n > 0 && <span className="count">{n}</span>}
    </NavLink>
  );

  return (
    <>
      <div className="statusbar">
        <span className="brand">
          <span>ㅇㅈ</span> 상담 지원
        </span>
        <AccessTag me={user} />
        <span className="spacer" />
        <span className="who">{user.name}</span>
        <button onClick={logout}>로그아웃</button>
      </div>

      <div className="shell">
        <aside className="rail">
          <nav>
            {item("/", "할 일")}
            <div className="group">상담</div>
            {item("/inquiries", "문의", counts?.inquiries_pending)}
            {item("/verifications", "재학생 인증", counts?.verifications_pending)}
            {item("/reviews", "후기", counts?.reviews_held)}
            <div className="group">자료</div>
            {item("/users", "회원")}
            {item("/schools", "학교")}
            <div className="group">결제</div>
            {item("/orders", "학교 주문", counts?.orders_pending)}
            {item("/subscriptions", "개인 구독")}
            {user.is_admin && (
              <>
                <div className="group">관리자</div>
                {item("/manage", "기기·상담원")}
              </>
            )}
          </nav>
        </aside>

        <main className="main">
          <Routes>
            <Route path="/" element={<Dashboard counts={counts} />} />
            <Route path="/inquiries" element={<Inquiries />} />
            <Route path="/verifications" element={<Verifications />} />
            <Route path="/reviews" element={<Reviews />} />
            <Route path="/users" element={<Users />} />
            <Route path="/schools" element={<Schools />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/subscriptions" element={<Subscriptions />} />
            <Route
              path="/manage"
              element={user.is_admin ? <Manage /> : <Navigate to="/" replace />}
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </>
  );
}
